package com.zxspeed.zxcrates.util;

import com.zxspeed.zxcrates.model.Crate;
import com.zxspeed.zxcrates.placeholder.PlaceholderService;
import com.zxspeed.zxcrates.model.Reward;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.text.format.TextDecoration;

import java.util.ArrayList;
import java.util.List;

/** Adds crate-only lore to preview/animation items without mutating stored rewards. */
public final class ItemLoreUtil {
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacySection();

    private ItemLoreUtil() {}

    public static ItemStack withCrateLore(ItemStack base, Crate crate) {
        return withCrateLore(base, crate, null, null);
    }

    public static ItemStack withCrateLore(ItemStack base, Crate crate, Player player, PlaceholderService placeholders) {
        return withCrateLore(base, crate, null, player, placeholders);
    }

    public static ItemStack withCrateLore(ItemStack base, Crate crate, Reward reward, Player player, PlaceholderService placeholders) {
        if (base == null || base.getType().isAir() || crate == null || crate.itemLore().isEmpty()) {
            return base == null ? null : base.clone();
        }
        ItemStack clone = base.clone();
        ItemMeta meta = clone.getItemMeta();
        if (meta == null) return clone;

        List<net.kyori.adventure.text.Component> lore = new ArrayList<>();
        List<net.kyori.adventure.text.Component> existing = meta.lore();
        if (existing != null) lore.addAll(existing);
        for (String rawLine : crate.itemLore()) {
            String line = rawLine;
            if (placeholders != null) line = placeholders.parse(player, line, crate, reward);
            else line = line.replace("{crate}", crate.displayName()).replace("{crate_id}", crate.id());
            lore.add(LEGACY.deserialize(ColorUtil.colorize(line)).decoration(TextDecoration.ITALIC, false));
        }
        meta.lore(lore);
        clone.setItemMeta(meta);
        return clone;
    }
}
