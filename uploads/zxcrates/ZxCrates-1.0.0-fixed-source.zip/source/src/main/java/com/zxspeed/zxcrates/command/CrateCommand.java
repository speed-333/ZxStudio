package com.zxspeed.zxcrates.command;

import com.zxspeed.zxcrates.ZxCratesPlugin;
import com.zxspeed.zxcrates.gui.CrateMenu;
import com.zxspeed.zxcrates.model.Crate;
import com.zxspeed.zxcrates.util.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.NamespacedKey;

import java.util.*;
import java.util.stream.Collectors;

public final class CrateCommand implements CommandExecutor, TabCompleter {
    private final ZxCratesPlugin plugin;

    public CrateCommand(ZxCratesPlugin plugin) { this.plugin = plugin; }

    private void send(CommandSender sender, String text) { sender.sendMessage(ColorUtil.colorize(text)); }

    private boolean perm(CommandSender sender, String permission) {
        if (sender.hasPermission("ZxCrates.admin") || sender.hasPermission(permission)) return true;
        sender.sendMessage(ColorUtil.colorize("&#FF5555You do not have permission to do that."));
        return false;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String sub = args.length == 0 ? "editor" : args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "editor", "edit" -> {
                if (!(sender instanceof Player player) || !perm(sender, "ZxCrates.edit")) return true;
                if (args.length >= 2) plugin.service().get(args[1]).ifPresentOrElse(crate -> new com.zxspeed.zxcrates.gui.CrateEditorMenu(plugin, player, crate).open(), () -> send(player, "&cCrate not found."));
                else new CrateMenu(plugin, player).open();
            }
            case "create" -> {
                if (!perm(sender, "ZxCrates.create") || args.length < 2) { send(sender, "&eUsage: /zxcrates create <id>"); return true; }
                String id = args[1].toLowerCase(Locale.ROOT);
                if (!id.matches("[a-z0-9_-]{1,32}")) { send(sender, "&cCrate ID must use letters, numbers, underscore or hyphen only."); return true; }
                if (plugin.service().get(id).isPresent()) { send(sender, "&cCrate already exists."); return true; }
                plugin.service().create(id).whenComplete((ignored, error) -> com.zxspeed.zxcrates.util.Tasks.global(plugin, () ->
                        send(sender, error == null ? "&aCrate &f" + id + "&a created." : "&cFailed to create crate.")));
            }
            case "delete" -> {
                if (!perm(sender, "ZxCrates.delete") || args.length < 2) { send(sender, "&eUsage: /zxcrates delete <id>"); return true; }
                String id = args[1].toLowerCase(Locale.ROOT);
                if (plugin.service().get(id).isEmpty()) { send(sender, "&cCrate not found."); return true; }
                plugin.service().get(id).ifPresent(crate -> { if (plugin.holograms() != null) plugin.holograms().remove(crate); });
                plugin.service().delete(id).whenComplete((ignored, error) -> com.zxspeed.zxcrates.util.Tasks.global(plugin, () ->
                        send(sender, error == null ? "&aCrate deleted." : "&cFailed to delete crate.")));
            }
            case "preview" -> {
                if (!(sender instanceof Player player)) { send(sender, "&cThis command can only be used by a player."); return true; }
                if (!perm(sender, "ZxCrates.open") || args.length < 2) { send(sender, "&eUsage: /crate preview <crate>"); return true; }
                plugin.service().get(args[1]).ifPresentOrElse(crate -> com.zxspeed.zxcrates.gui.CratePreviewMenu.open(plugin, player, crate), () -> send(player, "&cCrate not found."));
            }
            case "givecrate" -> {
                if (!(sender instanceof Player player)) { send(sender, "&cThis command can only be used by a player."); return true; }
                if (!perm(sender, "ZxCrates.givecrate") || args.length < 2) { send(sender, "&eUsage: /crate givecrate <crate>"); return true; }
                plugin.service().get(args[1]).ifPresentOrElse(crate -> {
                    ItemStack item = new ItemStack(crate.blockMaterial() == null ? org.bukkit.Material.CHEST : crate.blockMaterial(), 1);
                    ItemMeta meta = item.getItemMeta();
                    meta.displayName(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacySection().deserialize(ColorUtil.colorize(crate.displayName())).decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false));
                    meta.getPersistentDataContainer().set(new NamespacedKey(plugin, "crate-item"), PersistentDataType.STRING, crate.id());
                    meta.getPersistentDataContainer().set(new NamespacedKey(plugin, "crate-item-slots"), PersistentDataType.INTEGER, crate.slots());
                    item.setItemMeta(meta);
                    Map<Integer, ItemStack> overflow = player.getInventory().addItem(item);
                    overflow.values().forEach(drop -> player.getWorld().dropItemNaturally(player.getLocation(), drop));
                    send(player, "&aYou received crate &f" + crate.id() + "&a.");
                }, () -> send(sender, "&cCrate not found."));
            }
            case "givekey" -> {
                if (!perm(sender, "ZxCrates.givekey") || args.length < 3) { send(sender, "&eUsage: /zxcrates givekey <player> <crate> [amount]"); return true; }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) { send(sender, "&cPlayer not found."); return true; }
                int amount;
                try { amount = args.length >= 4 ? Integer.parseInt(args[3]) : 1; } catch (NumberFormatException ex) { send(sender, "&cAmount must be a positive integer."); return true; }
                if (amount < 1 || amount > 1_000_000) { send(sender, "&cAmount must be between 1 and 1000000."); return true; }
                plugin.service().get(args[2]).ifPresentOrElse(crate ->
                        plugin.service().giveKeys(target, crate, amount).whenComplete((ignored, error) -> com.zxspeed.zxcrates.util.Tasks.player(target, plugin, () -> {
                                if (error == null && plugin.holograms() != null) plugin.holograms().refreshPlayer(target);
                                send(target, error == null ? "&aYou received &f" + amount + "&a key(s) for &f" + crate.id() + "&a." : "&cFailed to save keys.");
                        })),
                        () -> send(sender, "&cCrate not found."));
            }
            case "bind" -> {
                if (!(sender instanceof Player player) || !perm(sender, "ZxCrates.edit") || args.length < 2) return true;
                if (plugin.service().get(args[1]).isEmpty()) { send(sender, "&cCrate not found."); return true; }
                plugin.bindRequests().put(player.getUniqueId(), args[1].toLowerCase(Locale.ROOT));
                send(sender, "&eRight-click a block to bind it to this crate.");
            }
            case "reload" -> {
                if (!perm(sender, "ZxCrates.reload")) return true;
                plugin.reloadConfig();
                plugin.keyAll().reload();
                plugin.service().load().whenComplete((ignored, error) -> com.zxspeed.zxcrates.util.Tasks.global(plugin, () -> {
                    if (error == null && plugin.holograms() != null) plugin.holograms().refreshAll(plugin.service().all());
                    send(sender, error == null ? "&aConfiguration, crate files and keyall.yml reloaded." : "&cFailed to reload crate files.");
                }));
            }
            case "keyall" -> {
                plugin.keyAll().execute(sender, java.util.Arrays.copyOfRange(args, 1, args.length));
            }
            case "hologram" -> {
                handleHologram(sender, args);
            }
            case "info" -> {
                if (!perm(sender, "ZxCrates.info") || args.length < 2) { send(sender, "&eUsage: /zxcrates info <id>"); return true; }
                plugin.service().get(args[1]).ifPresentOrElse(
                        crate -> send(sender, "&b" + crate.id() + " &7type=&f" + crate.type() + " &7rewards=&f" + crate.rewards().size()),
                        () -> send(sender, "&cCrate not found."));
            }
            default -> send(sender, "&cUsage: /zxcrates <editor|create|delete|givecrate|givekey|keyall|bind|reload|hologram|info>");
        }
        return true;
    }

    private void handleHologram(CommandSender sender, String[] args) {
        if (!perm(sender, "ZxCrates.edit")) return;
        if (args.length < 3) {
            send(sender, "&eUsage: /crate hologram <crateid> <background|view_distance> ...");
            return;
        }

        Crate crate = plugin.service().get(args[1]).orElse(null);
        if (crate == null) {
            send(sender, "&cCrate &f" + args[1] + "&c not found.");
            return;
        }

        String option = args[2].toLowerCase(Locale.ROOT);
        switch (option) {
            case "background" -> handleHologramBackground(sender, args, crate);
            case "view_distance", "view-distance" -> handleHologramViewDistance(sender, args, crate);
            default -> send(sender, "&eUsage: /crate hologram <crateid> <background|view_distance> ...");
        }
    }

    private void handleHologramBackground(CommandSender sender, String[] args, Crate crate) {
        if (args.length != 4) {
            send(sender, "&eUsage: /crate hologram <crateid> background <default|transparent>");
            return;
        }
        String mode = args[3].toLowerCase(Locale.ROOT);
        if (!mode.equals("default") && !mode.equals("transparent")) {
            send(sender, "&cBackground mode must be &fdefault &cor &ftransparent&c.");
            return;
        }
        boolean defaultBackground = mode.equals("default");
        crate.hologramBackground(defaultBackground);
        plugin.service().save(crate).whenComplete((ignored, error) ->
                com.zxspeed.zxcrates.util.Tasks.global(plugin, () -> {
                    if (error != null) {
                        send(sender, "&cFailed to save hologram background for &f" + crate.id() + "&c: &f" + error.getMessage());
                        return;
                    }
                    if (plugin.holograms() != null) {
                        plugin.holograms().refreshBackground(crate);
                        plugin.holograms().refreshPlayerVisibilities();
                    }
                    send(sender, defaultBackground
                            ? "&aHologram background for &f" + crate.id() + "&a is now &fdefault&a."
                            : "&aHologram background for &f" + crate.id() + "&a is now &ftransparent&a.");
                }));
    }

    private void handleHologramViewDistance(CommandSender sender, String[] args, Crate crate) {
        if (!sender.hasPermission("ZxCrates.admin")
                && !sender.hasPermission("crates.view_distance.set")
                && !sender.hasPermission("crate.view_distance.set")) {
            send(sender, "&cYou do not have permission to change crate hologram view-distance.");
            return;
        }

        // The crate id is intentionally repeated in this syntax so the command is explicit and
        // safe when copied/generated by server management tools:
        // /crate hologram <crateid> view_distance <crateid> <value>
        if (args.length != 5) {
            send(sender, "&eUsage: /crate hologram <crateid> view_distance <crateid> <value>");
            return;
        }
        if (!args[3].equalsIgnoreCase(crate.id())) {
            send(sender, "&cThe second crate ID must match &f" + crate.id() + "&c.");
            return;
        }

        final double value;
        try {
            value = Double.parseDouble(args[4]);
        } catch (NumberFormatException ex) {
            send(sender, "&cView distance must be a number between &f0&c and &f128&c.");
            return;
        }
        if (!Double.isFinite(value) || value < 0.0D || value > 128.0D) {
            send(sender, "&cView distance must be between &f0&c and &f128&c.");
            return;
        }

        crate.hologramViewDistance(value);
        plugin.service().save(crate).whenComplete((ignored, error) ->
                com.zxspeed.zxcrates.util.Tasks.global(plugin, () -> {
                    if (error != null) {
                        send(sender, "&cFailed to save view distance for &f" + crate.id() + "&c: &f" + error.getMessage());
                        return;
                    }
                    if (plugin.holograms() != null) {
                        // Reconcile the existing displays without leaving stale per-player state.
                        plugin.holograms().refresh(crate);
                        plugin.holograms().refreshPlayerVisibilities();
                    }
                    send(sender, "&aHologram view-distance for &f" + crate.id() + "&a is now &f" + value
                            + "&a blocks. &7Saved and applied immediately.");
                }));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (command.getName().equalsIgnoreCase("keyall")) {
            if (args.length <= 1) {
                String prefix = args.length == 0 ? "" : args[0].toLowerCase(Locale.ROOT);
                return plugin.keyAll().keyAllIds().stream().filter(x -> x.startsWith(prefix)).toList();
            }
            return List.of();
        }
        List<String> subs = List.of("editor", "edit", "preview", "create", "delete", "givekey", "givecrate", "bind", "reload", "info", "keyall", "hologram");
        if (args.length == 1) return subs.stream().filter(x -> x.startsWith(args[0].toLowerCase(Locale.ROOT))).collect(Collectors.toList());
        String sub = args[0].toLowerCase(Locale.ROOT);
        if (args.length == 2 && sub.equals("keyall")) {
            String prefix = args[1].toLowerCase(Locale.ROOT);
            return plugin.keyAll().keyAllIds().stream().filter(x -> x.startsWith(prefix)).toList();
        }
        if (args.length == 2 && sub.equals("givekey")) {
            String prefix = args[1].toLowerCase(Locale.ROOT);
            return Bukkit.getOnlinePlayers().stream()
                    .map(Player::getName)
                    .filter(name -> name.toLowerCase(Locale.ROOT).startsWith(prefix))
                    .sorted(String.CASE_INSENSITIVE_ORDER)
                    .toList();
        }
        if (args.length == 2 && Set.of("edit", "preview", "delete", "info", "bind", "givecrate", "hologram").contains(sub))
            return plugin.service().all().stream().map(Crate::id).filter(x -> x.startsWith(args[1].toLowerCase(Locale.ROOT))).sorted().toList();
        if (args.length == 3 && sub.equals("givekey")) {
            String prefix = args[2].toLowerCase(Locale.ROOT);
            return plugin.service().all().stream().map(Crate::id)
                    .filter(x -> x.toLowerCase(Locale.ROOT).startsWith(prefix))
                    .sorted().toList();
        }
        if (args.length == 3 && sub.equals("hologram")) return List.of("background", "view_distance").stream().filter(x -> x.startsWith(args[2].toLowerCase(Locale.ROOT))).toList();
        if (args.length == 4 && sub.equals("hologram") && args[2].equalsIgnoreCase("background")) return List.of("default", "transparent").stream().filter(x -> x.startsWith(args[3].toLowerCase(Locale.ROOT))).toList();
        if (args.length == 4 && sub.equals("hologram") && Set.of("view_distance", "view-distance").contains(args[2].toLowerCase(Locale.ROOT)))
            return plugin.service().all().stream().map(Crate::id).filter(x -> x.startsWith(args[3].toLowerCase(Locale.ROOT))).sorted().toList();
        if (args.length == 5 && sub.equals("hologram") && Set.of("view_distance", "view-distance").contains(args[2].toLowerCase(Locale.ROOT)))
            return List.of("0", "16", "32", "48", "64", "96", "128").stream().filter(x -> x.startsWith(args[4])).toList();
        return List.of();
    }
}
