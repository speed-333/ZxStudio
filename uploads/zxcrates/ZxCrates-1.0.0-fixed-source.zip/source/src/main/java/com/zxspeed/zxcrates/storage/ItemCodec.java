package com.zxspeed.zxcrates.storage;

import org.bukkit.inventory.ItemStack;
import java.util.Base64;

public final class ItemCodec {
    private ItemCodec() {}
    public static String encode(ItemStack item) {
        if (item == null) return "";
        return Base64.getEncoder().encodeToString(item.serializeAsBytes());
    }
    public static ItemStack decode(String value) {
        if (value == null || value.isBlank()) return null;
        return ItemStack.deserializeBytes(Base64.getDecoder().decode(value));
    }
}
