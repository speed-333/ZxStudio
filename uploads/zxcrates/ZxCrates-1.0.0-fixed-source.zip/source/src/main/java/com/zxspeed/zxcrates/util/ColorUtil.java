package com.zxspeed.zxcrates.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class ColorUtil {
    private static final Pattern HEX = Pattern.compile("&#([A-Fa-f0-9]{6})");
    private ColorUtil() {}

    public static String colorize(String input) {
        if (input == null) return "";
        Matcher m = HEX.matcher(input);
        StringBuffer out = new StringBuffer();
        while (m.find()) {
            String hex = m.group(1);
            StringBuilder replacement = new StringBuilder("§x");
            for (char c : hex.toCharArray()) replacement.append('§').append(c);
            m.appendReplacement(out, Matcher.quoteReplacement(replacement.toString()));
        }
        m.appendTail(out);
        String text = out.toString();
        return text.replaceAll("&([0-9a-fk-orA-FK-OR])", "§$1");
    }
}
