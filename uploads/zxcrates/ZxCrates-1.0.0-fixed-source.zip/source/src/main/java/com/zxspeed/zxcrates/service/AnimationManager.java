package com.zxspeed.zxcrates.service;

import com.zxspeed.zxcrates.ZxCratesPlugin;
import com.zxspeed.zxcrates.model.AnimationType;
import com.zxspeed.zxcrates.model.Crate;
import com.zxspeed.zxcrates.model.Reward;
import com.zxspeed.zxcrates.util.ColorUtil;
import com.zxspeed.zxcrates.util.ItemLoreUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

public final class AnimationManager {
    public static final String PREFIX = "§8Open Crate";
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacySection();
    private static final long HARD_TIMEOUT_TICKS = 20L * 20L;
    private final ZxCratesPlugin plugin;
    private final Map<Material, ItemStack> cachedIcons = new ConcurrentHashMap<>();

    public AnimationManager(ZxCratesPlugin plugin) { this.plugin = plugin; }

    public void play(Player player, Crate crate, Reward reward, Runnable finish) {
        if(player==null||crate==null||reward==null){safeFinish(finish);return;}
        Session s=new Session(player,crate,reward,finish);
        s.open();
        player.getScheduler().runDelayed(plugin,task->s.finishOnce(),null,HARD_TIMEOUT_TICKS);
        tick(s,0);
    }

    private void tick(Session s,int frame){
        if(!s.active()) return;
        try{
            if(frame==0){s.clear();s.actionbar();}
            else if(frame%5==0) s.actionbar();
            draw(s,frame);
            if(s.effectsEnabled() && frame%3==0) particles(s,frame);
            if(frame%5==0) sound(s,frame);
            if(frame>=38){s.clear();s.showReward();soundFinal(s);s.actionbar();delay(s, s::finishOnce, 8);return;}
            long delay=(frame<12?1L:(frame<28?2L:3L));
            delay(s,()->tick(s,frame+1),delay);
        }catch(Throwable t){fail(s,t);}
    }

    private void draw(Session s,int frame){
        int size=s.inventory.getSize(), center=size/2, rows=size/9;
        AnimationType type=s.crate.animation();
        clearTouched(s);
        List<Reward> rewards=s.rewards;
        int rewardCount=Math.min(Math.max(5,rewards.size()),size-1);
        int speed=s.speed(type);
        for(int i=0;i<rewardCount;i++){
            int slot=motionSlot(type,i,frame,speed,size,rows,center);
            if(slot<0||slot>=size||slot==center) continue;
            ItemStack icon=iconFor(s,rewards.isEmpty()?null:rewards.get(Math.floorMod(i+frame*speed,Math.max(1,rewards.size()))));
            s.put(slot,icon);
        }
        int burst=Math.min(18,size-1);
        for(int i=0;i<burst;i++){
            int slot=accentSlot(type,i,frame,size,rows,center);
            if(slot>=0&&slot<size&&slot!=center) s.put(slot,s.materialIcon(accentMaterial(type,frame+i)));
        }
        if(frame>28){
            int radius=Math.max(1,Math.min(4,(frame-28)/2));
            for(int y=0;y<rows;y++) for(int x=0;x<9;x++){
                int slot=y*9+x;
                if(slot>=size||slot==center) continue;
                if(Math.max(Math.abs(x-4),Math.abs(y-rows/2))==radius+(frame%2)) s.put(slot,s.materialIcon(loopMaterial(type,x+y+frame)));
            }
        }
        if(frame>=34) s.put(center,iconFor(s,s.reward));
    }

    private int motionSlot(AnimationType type,int i,int frame,int speed,int size,int rows,int center){
        int x,y;
        switch(type){
            case GALAXY -> { int ring=Math.floorMod(i+frame*speed,size); return Math.floorMod(center+ring-(i%5)*9,size); }
            case CELESTIAL_RUSH -> { x=Math.floorMod(i+frame*speed,9); y=Math.floorMod(i/3+frame/2,rows); return y*9+x; }
            case NEBULA_SPIRAL -> { int r=1+Math.floorMod(frame+i,4); x=Math.floorMod(4+(i-frame),9); y=Math.floorMod(rows/2+(i%5),rows); return y*9+x; }
            case INFERNO_BLOOM -> { x=Math.floorMod(4+(i%7)-frame*speed,9); y=Math.floorMod(rows/2+(i%3),rows); return y*9+x; }
            case FROST_NOVA -> { int angle=frame*speed+i*23; x=Math.floorMod(4+(int)Math.round(3*Math.cos(Math.toRadians(angle))),9); y=Math.floorMod(rows/2+(int)Math.round(2*Math.sin(Math.toRadians(angle))),rows); return y*9+x; }
            case THUNDERSTORM -> { x=Math.floorMod(frame/2+i,9); y=Math.floorMod(rows-1-(i%rows)+frame%3,rows); return y*9+x; }
            case OCEAN_TIDE -> { x=Math.floorMod(i+frame,9); y=Math.floorMod((x+frame)%Math.max(1,rows),rows); return y*9+x; }
            case MATRIX_PULSE -> { x=Math.floorMod(i*2+frame,9); y=Math.floorMod(i+frame/2,rows); return y*9+x; }
            case ROYAL_CROWN -> { y=Math.min(rows-1,Math.max(0,rows/2-(frame/5)%Math.max(1,rows/2))); x=Math.floorMod(2+i+frame,5)+2; return y*9+x; }
            case DIMENSION_BREAK -> { int d=(i+frame)%7; x=Math.floorMod(4+d-(frame%2),9); y=Math.floorMod(rows/2+(i%5)-d/2,rows); return y*9+x; }
            case LEGENDARY_ASCENT -> { int rise=Math.min(rows-1,frame/5); y=Math.max(0,rows-1-rise+(i%2)); x=Math.floorMod(4+i+(frame/2),9); return y*9+x; }
        }
        return center;
    }

    private int accentSlot(AnimationType type,int i,int frame,int size,int rows,int center){
        int x,y;
        int n=Math.max(1,rows);
        switch(type){
            case GALAXY -> { int r=Math.min(3,1+(frame%8)/3); x=Math.floorMod(4+(i%2==0?r:-r),9); y=Math.floorMod(rows/2+(i%3==0?r:-r),n); }
            case CELESTIAL_RUSH -> { x=Math.floorMod(frame+i,9); y=(i%2==0?0:rows-1); }
            case NEBULA_SPIRAL -> { int r=1+i%4; x=Math.floorMod(4+(i%2==0?r:-r),9); y=Math.floorMod(rows/2+(i%3==0?r:-r),n); }
            case INFERNO_BLOOM -> { x=Math.floorMod(4+(i%5)-2,9); y=Math.floorMod(frame/2+i,n); }
            case FROST_NOVA -> { int a=frame*8+i*31; x=Math.floorMod(4+(int)Math.round(4*Math.cos(Math.toRadians(a))),9); y=Math.floorMod(rows/2+(int)Math.round(2*Math.sin(Math.toRadians(a))),n); }
            case THUNDERSTORM -> { x=Math.floorMod(frame/2+i,9); y=Math.floorMod(i*2+frame,n); }
            case OCEAN_TIDE -> { x=Math.floorMod(i+frame,9); y=Math.floorMod((x+frame)/3,n); }
            case MATRIX_PULSE -> { x=Math.floorMod(i*3+frame,9); y=Math.floorMod(frame+i,n); }
            case ROYAL_CROWN -> { x=Math.floorMod(2+i+frame,5)+2; y=Math.max(0,rows-1-(i%3)); }
            case DIMENSION_BREAK -> { x=Math.floorMod(4+(i%2==0?frame%5:-(frame%5)),9); y=Math.floorMod(rows/2+i,n); }
            case LEGENDARY_ASCENT -> { int spread=Math.max(0,3-(frame/10)); x=Math.floorMod(4+(i%Math.max(1,spread+1))-spread/2,9); y=Math.max(0,rows-1-frame/6); }
        }
        int slot=y*9+x; return slot<size?slot:Math.floorMod(slot,size);
    }

    private Material accentMaterial(AnimationType type,int value){
        return switch(type){
            case GALAXY -> (value&1)==0?Material.AMETHYST_SHARD:Material.GLOW_INK_SAC;
            case CELESTIAL_RUSH -> (value&1)==0?Material.GLOWSTONE_DUST:Material.FIREWORK_STAR;
            case NEBULA_SPIRAL -> (value&1)==0?Material.PURPLE_DYE:Material.ENDER_PEARL;
            case INFERNO_BLOOM -> (value&1)==0?Material.BLAZE_POWDER:Material.MAGMA_CREAM;
            case FROST_NOVA -> (value&1)==0?Material.SNOWBALL:Material.PRISMARINE_CRYSTALS;
            case THUNDERSTORM -> (value&1)==0?Material.LIGHTNING_ROD:Material.GLOWSTONE_DUST;
            case OCEAN_TIDE -> (value&1)==0?Material.PRISMARINE_SHARD:Material.HEART_OF_THE_SEA;
            case MATRIX_PULSE -> (value&1)==0?Material.LIME_DYE:Material.REDSTONE;
            case ROYAL_CROWN -> (value&1)==0?Material.GOLD_NUGGET:Material.EMERALD;
            case DIMENSION_BREAK -> (value&1)==0?Material.ENDER_PEARL:Material.OBSIDIAN;
            case LEGENDARY_ASCENT -> (value&1)==0?Material.EMERALD:Material.GOLD_NUGGET;
        };
    }

    private Material loopMaterial(AnimationType type,int value){return accentMaterial(type,value+7);}

    private ItemStack iconFor(Session s,Reward reward){
        if(reward==null||reward.item()==null) return s.materialIcon(Material.NETHER_STAR);
        ItemStack cached=s.rewardIcons.get(reward.id());
        if(cached!=null) return cached;
        ItemStack item=ItemLoreUtil.withCrateLore(reward.item(),s.crate,reward,s.player,plugin.placeholders());
        item.setAmount(Math.min(Math.max(1,reward.amount()),item.getMaxStackSize()));
        s.rewardIcons.put(reward.id(), item);
        return item;
    }

    private void particles(Session s,int frame){
        Particle p=s.particle(); s.player.getWorld().spawnParticle(p,s.player.getLocation().add(0,1,0),6,0.22,0.3,0.22,0.01);
    }

    private void sound(Session s,int frame){
        Sound sound=s.sound(); float pitch=(float)(0.75+((frame%7)*0.06)); s.player.playSound(s.player.getLocation(),sound,0.32f,pitch);
    }

    private void soundFinal(Session s){s.player.playSound(s.player.getLocation(),Sound.ENTITY_PLAYER_LEVELUP,0.6f,1.18f);}

    private void delay(Session s,Runnable next,long ticks){if(!s.active())return;s.player.getScheduler().runDelayed(plugin,task->{if(!s.active())return;try{next.run();}catch(Throwable t){fail(s,t);}},null,Math.max(1,ticks));}
    private void clearTouched(Session s){s.clearTouched();}
    private void fail(Session s,Throwable t){plugin.getLogger().warning("Crate animation failed for "+s.crate.id()+": "+t.getClass().getSimpleName()+": "+t.getMessage());s.finishOnce();}
    private void safeFinish(Runnable r){try{if(r!=null)r.run();}catch(Throwable ignored){}}

    private final class Session{
        private final Player player; private final Crate crate; private final Reward reward; private final Runnable finish; private final AtomicBoolean done=new AtomicBoolean(false);
        private Inventory inventory; private final IntArray touched=new IntArray(64); private final List<Reward> rewards; private final Map<Integer,ItemStack> rewardIcons=new HashMap<>(); private boolean cosmeticsPaused;
        private Session(Player player,Crate crate,Reward reward,Runnable finish){this.player=player;this.crate=crate;this.reward=reward;this.finish=finish;this.rewards=crate.rewards();}
        private void open(){inventory=Bukkit.createInventory(null,crate.slots(),PREFIX);player.openInventory(inventory);setCosmeticsPaused();actionbar();}
        private boolean active(){return !done.get()&&player.isOnline()&&plugin.service().isOpening(player.getUniqueId());}
        private boolean effectsEnabled(){return plugin.getConfig().getBoolean("opening.effects",true);}
        private void actionbar(){player.sendActionBar(LEGACY.deserialize(ColorUtil.colorize("&eOpen Crate")).decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false));}
        private Particle particle(){return switch(crate.animation()){case GALAXY->Particle.END_ROD;case CELESTIAL_RUSH->Particle.FIREWORK;case NEBULA_SPIRAL->Particle.PORTAL;case INFERNO_BLOOM->Particle.FLAME;case FROST_NOVA->Particle.SNOWFLAKE;case THUNDERSTORM->Particle.ELECTRIC_SPARK;case OCEAN_TIDE->Particle.BUBBLE;case MATRIX_PULSE->Particle.COMPOSTER;case ROYAL_CROWN->Particle.TOTEM_OF_UNDYING;case DIMENSION_BREAK->Particle.REVERSE_PORTAL;case LEGENDARY_ASCENT->Particle.END_ROD;};}
        private Sound sound(){return switch(crate.animation()){case GALAXY->Sound.BLOCK_AMETHYST_BLOCK_CHIME;case CELESTIAL_RUSH->Sound.ENTITY_FIREWORK_ROCKET_TWINKLE;case NEBULA_SPIRAL->Sound.BLOCK_BEACON_AMBIENT;case INFERNO_BLOOM->Sound.BLOCK_FIRE_AMBIENT;case FROST_NOVA->Sound.BLOCK_AMETHYST_BLOCK_CHIME;case THUNDERSTORM->Sound.ENTITY_LIGHTNING_BOLT_THUNDER;case OCEAN_TIDE->Sound.ENTITY_FISH_SWIM;case MATRIX_PULSE->Sound.BLOCK_NOTE_BLOCK_HAT;case ROYAL_CROWN->Sound.BLOCK_NOTE_BLOCK_CHIME;case DIMENSION_BREAK->Sound.BLOCK_RESPAWN_ANCHOR_CHARGE;case LEGENDARY_ASCENT->Sound.BLOCK_NOTE_BLOCK_PLING;};}
        private int speed(AnimationType t){return switch(t){case GALAXY->2;case CELESTIAL_RUSH->3;case NEBULA_SPIRAL->2;case INFERNO_BLOOM->3;case FROST_NOVA->2;case THUNDERSTORM->3;case OCEAN_TIDE->2;case MATRIX_PULSE->4;case ROYAL_CROWN->2;case DIMENSION_BREAK->3;case LEGENDARY_ASCENT->2;};}
        private void setCosmeticsPaused(){if(!plugin.getConfig().getBoolean("opening.pause-cosmetics",true))return;cosmeticsPaused=true;player.setMetadata("zxcrates.cosmetics-paused",new org.bukkit.metadata.FixedMetadataValue(plugin,true));}
        private void clearCosmeticsPaused(){if(cosmeticsPaused){player.removeMetadata("zxcrates.cosmetics-paused",plugin);cosmeticsPaused=false;}}
        private void put(int slot,ItemStack item){if(slot<0||slot>=inventory.getSize())return;inventory.setItem(slot,item);touched.add(slot);}
        private ItemStack materialIcon(Material material){return cachedIcons.computeIfAbsent(material,m->new ItemStack(m));}
        private void clearTouched(){for(int i=0;i<touched.size();i++){int slot=touched.get(i);if(slot>=0&&slot<inventory.getSize())inventory.setItem(slot,null);}touched.clear();}
        private void clear(){for(int i=0;i<inventory.getSize();i++)inventory.setItem(i,null);touched.clear();}
        private void showReward(){inventory.setItem(crate.slots()/2,iconFor(this,reward));}
        private void finishOnce(){if(!done.compareAndSet(false,true))return;try{if(finish!=null)finish.run();}catch(Throwable t){plugin.getLogger().warning("Could not finish crate opening for "+crate.id()+": "+t.getMessage());}finally{clearCosmeticsPaused();player.sendActionBar(Component.empty());plugin.service().endOpening(player.getUniqueId());if(player.isOnline()&&plugin.holograms()!=null)plugin.holograms().refreshPlayer(player);}}
    }

    private static final class IntArray{
        private int[] data; private int size;
        IntArray(int cap){data=new int[cap];}
        void add(int v){if(size==data.length)data=Arrays.copyOf(data,data.length*2);data[size++]=v;}
        int size(){return size;}
        int get(int i){return data[i];}
        void clear(){size=0;}
    }
}
