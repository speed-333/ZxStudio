package com.zxspeed.zxcrates.storage;

import com.zxspeed.zxcrates.model.*;
import com.zxspeed.zxcrates.service.CrateRepository;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.ConcurrentHashMap;

public final class FlatFileRepository implements CrateRepository {
    private final File dataFolder;
    private final File cratesFolder;
    private final File keysFile;
    private final Executor executor;
    private final Map<String, Crate> cache = new ConcurrentHashMap<>();
    private final Map<String, Integer> keys = new ConcurrentHashMap<>();

    public FlatFileRepository(File dataFolder, Executor executor) {
        this.dataFolder = dataFolder;
        this.cratesFolder = new File(dataFolder, "crates");
        this.keysFile = new File(dataFolder, "keys.yml");
        this.executor = executor;
    }

    private String key(UUID player, String crate) { return player + ":" + crate.toLowerCase(Locale.ROOT); }

    @Override
    public CompletableFuture<Collection<Crate>> loadAll() {
        return CompletableFuture.supplyAsync(() -> {
            dataFolder.mkdirs();
            cratesFolder.mkdirs();
            cache.clear();
            keys.clear();
            loadLegacyCratesIfPresent();
            File[] files = cratesFolder.listFiles((dir, name) -> name.toLowerCase(Locale.ROOT).endsWith(".yml"));
            if (files != null) {
                Arrays.sort(files, Comparator.comparing(File::getName, String.CASE_INSENSITIVE_ORDER));
                for (File file : files) {
                    try {
                        Crate crate = readCrate(file);
                        if (crate != null) cache.put(crate.id().toLowerCase(Locale.ROOT), crate);
                    } catch (Throwable ignored) {
                        // Ignore one broken crate file so a single bad file cannot stop the plugin.
                    }
                }
            }
            if (keysFile.exists()) {
                YamlConfiguration y = YamlConfiguration.loadConfiguration(keysFile);
                ConfigurationSection section = y.getConfigurationSection("keys");
                if (section != null) for (String k : section.getKeys(false)) keys.put(k, Math.max(0, y.getInt("keys." + k)));
            }
            return List.copyOf(cache.values());
        }, executor);
    }

    private void loadLegacyCratesIfPresent() {
        File legacy = new File(dataFolder, "data.yml");
        if (!legacy.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(legacy);
        ConfigurationSection section = y.getConfigurationSection("crates");
        if (section == null) return;
        for (String id : section.getKeys(false)) {
            File target = crateFile(id);
            if (target.exists()) continue;
            Crate crate = readCrateFromSection(y, "crates." + id, id);
            if (crate == null) continue;
            try { writeCrate(crate); } catch (IOException ignored) { }
            cache.put(crate.id().toLowerCase(Locale.ROOT), crate);
        }
        ConfigurationSection keySection = y.getConfigurationSection("keys");
        if (keySection != null) for (String k : keySection.getKeys(false)) keys.putIfAbsent(k, Math.max(0, y.getInt("keys." + k)));
    }

    private Crate readCrate(File file) {
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        String id = file.getName().substring(0, file.getName().length() - 4);
        return readCrateFromSection(y, "", id);
    }

    private Crate readCrateFromSection(YamlConfiguration y, String p, String id) {
        Crate c = new Crate(id);
        c.displayName(y.getString(path(p, "display-name"), id));
        c.type(parseEnum(CrateType.class, y.getString(path(p, "type"), "random"), CrateType.RANDOM));
        Material material = Material.matchMaterial(y.getString(path(p, "block-material"), "CHEST"));
        c.blockMaterial(material == null ? Material.CHEST : material);
        c.animation(parseEnum(AnimationType.class, y.getString(path(p, "animation"), "galaxy"), AnimationType.GALAXY));
        c.createKey(y.getBoolean(path(p, "key.create"), true));
        c.keyDelivery(y.getString(path(p, "key.delivery"), "cloud"));
        c.keyDisplayName(y.getString(path(p, "key.display-name"), "&#FFD54AZxCrates Key"));
        String keyItemRaw = y.getString(path(p, "key.item"), "");
        if (!keyItemRaw.isBlank()) c.keyItem(ItemCodec.decode(keyItemRaw));
        c.keyStacked(y.getBoolean(path(p, "key.stacked"), true));
        c.openPermission(y.getString(path(p, "open-permission"), ""));
        long cooldownSeconds = y.contains(path(p, "cooldown-seconds")) ? y.getLong(path(p, "cooldown-seconds"), 0L) : Math.max(0L, (y.getLong(path(p, "cooldown-ms"), 0L) + 999L) / 1000L);
        c.cooldownSeconds(cooldownSeconds);
        c.broadcastWin(y.getBoolean(path(p, "broadcast-win"), false));
        c.slots(y.getInt(path(p, "slots"), 45));
        c.hologramEnabled(y.getBoolean(path(p, "hologram.enabled"), true));
        c.hologramText(y.getString(path(p, "hologram.text"), "&a%zxcrates_crate% Crate\n&r\n&a▶ &fHit To &aPreview &a!\n&a▶ &fUse Key To &aOpen &a!\n&fYou Have &a%zxcrates_crate_keys_crateid%\n&f%zxcrates_crate% &aKey!\n&r\n&fSelector Type: &aRandom\n&fBuy Keys! &a/Store"));
        c.hologramOffsetY(y.getDouble(path(p, "hologram.offset-y"), 1.2D));
        c.hologramViewDistance(y.getDouble(path(p, "hologram.view-distance"), 32.0D));
        c.hologramBackground(y.getBoolean(path(p, "hologram.background"), false));
        java.util.List<String> defaultLore = java.util.List.of(
                "",
                "&8&m----------------",
                "&fᴄʜᴀɴᴄᴇ: &a%reward_chance%",
                "&fʏᴏᴜʀ ᴋᴇʏѕ: &a%zxcrates_crate_keys_crateid%",
                "&8&m----------------"
        );
        c.itemLore(y.contains(path(p, "item-lore")) ? y.getStringList(path(p, "item-lore")) : defaultLore);
        for (String location : y.getStringList(path(p, "locations"))) c.addLocationKey(location);

        ConfigurationSection rewards = y.getConfigurationSection(path(p, "rewards"));
        if (rewards != null) {
            int fallbackSlot = 0;
            for (String rewardKey : rewards.getKeys(false)) {
                String rp = path(path(p, "rewards"), rewardKey);
                int savedSlot = y.contains(path(rp, "slot")) ? y.getInt(path(rp, "slot"), -1) : fallbackSlot;
                Reward reward = new Reward(
                        y.getInt(path(rp, "id"), parseRewardId(rewardKey)),
                        savedSlot,
                        y.getDouble(path(rp, "chance"), 0.0D),
                        y.getBoolean(path(rp, "chance-manual"), false),
                        parseEnum(RewardType.class, y.getString(path(rp, "type"), "give_item"), RewardType.GIVE_ITEM),
                        ItemCodec.decode(y.getString(path(rp, "item"), "")),
                        y.getInt(path(rp, "amount"), 1),
                        y.getStringList(path(rp, "commands"))
                );
                c.addReward(reward);
                fallbackSlot++;
            }
        }
        return c;
    }

    private static String path(String base, String child) { return base == null || base.isBlank() ? child : base + "." + child; }
    private static int parseRewardId(String raw) { try { return Integer.parseInt(raw); } catch (Exception ignored) { return 1; } }

    @Override
    public CompletableFuture<Void> save(Crate crate) {
        Crate snapshot = crate.snapshot();
        return CompletableFuture.runAsync(() -> {
            cache.put(snapshot.id().toLowerCase(Locale.ROOT), snapshot);
            try { writeCrate(snapshot); } catch (IOException ex) { throw new CompletionException(ex); }
        }, executor);
    }

    private void writeCrate(Crate crate) throws IOException {
        cratesFolder.mkdirs();
        YamlConfiguration y = new YamlConfiguration();
        y.set("id", crate.id());
        y.set("display-name", crate.displayName());
        y.set("type", crate.type().name().toLowerCase(Locale.ROOT));
        y.set("block-material", crate.blockMaterial().name());
        y.set("animation", crate.animation().name().toLowerCase(Locale.ROOT));
        y.set("slots", crate.slots());
        y.set("key.create", crate.createKey());
        y.set("key.delivery", crate.keyDelivery());
        y.set("key.display-name", crate.keyDisplayName());
        y.set("key.item", ItemCodec.encode(crate.keyItem()));
        y.set("key.stacked", crate.keyStacked());
        y.set("open-permission", crate.openPermission());
        y.set("cooldown-seconds", crate.cooldownSeconds());
        y.set("cooldown-ms", null);
        y.set("broadcast-win", crate.broadcastWin());
        y.set("locations", new ArrayList<>(crate.locations()));
        y.set("hologram.enabled", crate.hologramEnabled());
        y.set("hologram.offset-y", crate.hologramOffsetY());
        y.set("hologram.view-distance", crate.hologramViewDistance());
        y.set("hologram.background", crate.hologramBackground());
        y.set("hologram.text", crate.hologramText());
        y.set("item-lore", new ArrayList<>(crate.itemLore()));
        int i = 0;
        for (Reward r : crate.rewards()) {
            String rp = "rewards." + i++;
            y.set(rp + ".id", r.id());
            y.set(rp + ".slot", r.slot());
            y.set(rp + ".chance", r.chance());
            y.set(rp + ".chance-manual", r.chanceManual());
            y.set(rp + ".type", r.type().name().toLowerCase(Locale.ROOT));
            y.set(rp + ".item", ItemCodec.encode(r.item()));
            y.set(rp + ".amount", r.amount());
            y.set(rp + ".commands", r.commands());
        }
        File file = crateFile(crate.id());
        File tmp = new File(cratesFolder, file.getName() + ".tmp");
        File backup = new File(cratesFolder, file.getName() + ".bak");
        y.save(tmp);
        if (file.exists()) java.nio.file.Files.copy(file.toPath(), backup.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        try { java.nio.file.Files.move(tmp.toPath(), file.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING, java.nio.file.StandardCopyOption.ATOMIC_MOVE); }
        catch (java.nio.file.AtomicMoveNotSupportedException ignored) { java.nio.file.Files.move(tmp.toPath(), file.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING); }
    }

    private File crateFile(String id) { return new File(cratesFolder, id.toLowerCase(Locale.ROOT) + ".yml"); }

    @Override
    public CompletableFuture<Void> delete(String id) {
        String normalized = id.toLowerCase(Locale.ROOT);
        return CompletableFuture.runAsync(() -> {
            cache.remove(normalized);
            try { java.nio.file.Files.deleteIfExists(crateFile(normalized).toPath()); java.nio.file.Files.deleteIfExists(new File(cratesFolder, normalized + ".yml.bak").toPath()); }
            catch (IOException ex) { throw new CompletionException(ex); }
        }, executor);
    }

    @Override public CompletableFuture<Integer> getKeys(UUID player, String crateId) { return CompletableFuture.completedFuture(keys.getOrDefault(key(player, crateId), 0)); }

    @Override
    public CompletableFuture<Void> setKeys(UUID player, String crateId, int amount) {
        return CompletableFuture.runAsync(() -> { String k = key(player, crateId); if (amount <= 0) keys.remove(k); else keys.put(k, amount); persistKeys(); }, executor);
    }

    @Override
    public CompletableFuture<Boolean> takeKey(UUID player, String crateId) {
        return CompletableFuture.supplyAsync(() -> {
            synchronized (keys) {
                String k = key(player, crateId);
                int current = keys.getOrDefault(k, 0);
                if (current <= 0) return false;
                if (current == 1) keys.remove(k); else keys.put(k, current - 1);
                persistKeys();
                return true;
            }
        }, executor);
    }

    private synchronized void persistKeys() {
        dataFolder.mkdirs();
        YamlConfiguration y = new YamlConfiguration();
        for (Map.Entry<String, Integer> entry : keys.entrySet()) y.set("keys." + entry.getKey(), entry.getValue());
        File tmp = new File(dataFolder, "keys.yml.tmp");
        File backup = new File(dataFolder, "keys.yml.bak");
        try {
            y.save(tmp);
            if (keysFile.exists()) java.nio.file.Files.copy(keysFile.toPath(), backup.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            try { java.nio.file.Files.move(tmp.toPath(), keysFile.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING, java.nio.file.StandardCopyOption.ATOMIC_MOVE); }
            catch (java.nio.file.AtomicMoveNotSupportedException ignored) { java.nio.file.Files.move(tmp.toPath(), keysFile.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING); }
        } catch (IOException ex) { throw new CompletionException(ex); }
    }

    private static <E extends Enum<E>> E parseEnum(Class<E> type, String raw, E fallback) {
        try { return Enum.valueOf(type, raw.toUpperCase(Locale.ROOT)); }
        catch (Exception ignored) { return fallback; }
    }
}
