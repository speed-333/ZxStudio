package com.zxspeed.zxcrates.db;

import com.zxspeed.zxcrates.model.*;
import com.zxspeed.zxcrates.service.CrateRepository;
import com.zxspeed.zxcrates.storage.ItemCodec;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.sql.*;
import java.util.*;
import java.util.concurrent.*;

public final class MySqlRepository implements CrateRepository {
    private final HikariDataSource ds;
    private final Executor executor;

    public MySqlRepository(String host, int port, String database, String username, String password,
                           int poolSize, long connectionTimeout, Executor executor) {
        HikariConfig config = new HikariConfig();
        config.setJdbcUrl("jdbc:mysql://" + host + ":" + port + "/" + database +
                "?useSSL=false&characterEncoding=utf8&serverTimezone=UTC&useUnicode=true");
        config.setUsername(username);
        config.setPassword(password);
        config.setMaximumPoolSize(Math.max(2, poolSize));
        config.setMinimumIdle(Math.min(2, Math.max(1, poolSize)));
        config.setConnectionTimeout(Math.max(1000, connectionTimeout));
        config.setPoolName("ZxCrates-MySQL");
        config.addDataSourceProperty("cachePrepStmts", "true");
        config.addDataSourceProperty("prepStmtCacheSize", "250");
        config.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");
        this.ds = new HikariDataSource(config);
        this.executor = executor;
    }

    public void migrate() {
        try (Connection c = ds.getConnection(); Statement s = c.createStatement()) {
            s.executeUpdate("CREATE TABLE IF NOT EXISTS crates (" +
                    "id VARCHAR(64) PRIMARY KEY," +
                    "display_name VARCHAR(256) NOT NULL," +
                    "type VARCHAR(16) NOT NULL," +
                    "block_material VARCHAR(64) NOT NULL," +
                    "animation VARCHAR(32) NOT NULL," +
                    "config TEXT NULL," +
                    "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP," +
                    "updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)");
            s.executeUpdate("CREATE TABLE IF NOT EXISTS rewards (" +
                    "id INT AUTO_INCREMENT PRIMARY KEY," +
                    "crate_id VARCHAR(64) NOT NULL," +
                    "item_json LONGTEXT NULL," +
                    "chance DOUBLE NOT NULL," +
                    "reward_type VARCHAR(32) NOT NULL," +
                    "command_text LONGTEXT NULL," +
                    "amount INT NOT NULL DEFAULT 1," +
                    "position INT NOT NULL," +
                    "INDEX idx_rewards_crate(crate_id))");
            try { s.executeUpdate("ALTER TABLE rewards ADD COLUMN amount INT NOT NULL DEFAULT 1"); } catch (SQLException ignored) { }
            try { s.executeUpdate("ALTER TABLE rewards ADD COLUMN position INT NOT NULL DEFAULT 0"); } catch (SQLException ignored) { }
            try { s.executeUpdate("ALTER TABLE rewards ADD COLUMN chance_manual BOOLEAN NOT NULL DEFAULT FALSE"); } catch (SQLException ignored) { }
            s.executeUpdate("CREATE TABLE IF NOT EXISTS player_keys (" +
                    "player_uuid CHAR(36) NOT NULL," +
                    "crate_id VARCHAR(64) NOT NULL," +
                    "amount INT NOT NULL," +
                    "PRIMARY KEY(player_uuid, crate_id)," +
                    "INDEX idx_keys_crate(crate_id))");
            s.executeUpdate("CREATE TABLE IF NOT EXISTS logs (" +
                    "id BIGINT AUTO_INCREMENT PRIMARY KEY," +
                    "player_uuid CHAR(36) NOT NULL," +
                    "crate_id VARCHAR(64) NOT NULL," +
                    "reward_id INT NULL," +
                    "timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP," +
                    "INDEX idx_logs_crate(crate_id)," +
                    "INDEX idx_logs_player(player_uuid))");
        } catch (SQLException ex) {
            throw new IllegalStateException("Database migration failed", ex);
        }
    }

    @Override
    public CompletableFuture<Collection<Crate>> loadAll() {
        return CompletableFuture.supplyAsync(() -> {
            Map<String, Crate> result = new LinkedHashMap<>();
            try (Connection c = ds.getConnection()) {
                try (PreparedStatement ps = c.prepareStatement("SELECT id,display_name,type,block_material,animation,config FROM crates ORDER BY id")) {
                    try (ResultSet rs = ps.executeQuery()) {
                        while (rs.next()) {
                            Crate crate = new Crate(rs.getString("id"));
                            crate.displayName(rs.getString("display_name"));
                            crate.type(parseEnum(CrateType.class, rs.getString("type"), CrateType.RANDOM));
                            MaterialSafe.setBlockMaterial(crate, rs.getString("block_material"));
                            crate.animation(parseEnum(AnimationType.class, rs.getString("animation"), AnimationType.GALAXY));
                            String configJson = rs.getString("config");
                            applyConfig(crate, configJson);
                            result.put(crate.id().toLowerCase(Locale.ROOT), crate);
                        }
                    }
                }
                loadRewards(c, result);
                loadConfigs(c, result);
            } catch (SQLException ex) {
                throw new CompletionException(ex);
            }
            return List.copyOf(result.values());
        }, executor);
    }

    private void loadRewards(Connection c, Map<String, Crate> crates) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement("SELECT id,crate_id,item_json,chance,chance_manual,reward_type,command_text,amount,position FROM rewards ORDER BY crate_id,position,id");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Crate crate = crates.get(rs.getString("crate_id").toLowerCase(Locale.ROOT));
                if (crate == null) continue;
                List<String> commands = new ArrayList<>();
                String commandText = rs.getString("command_text");
                if (commandText != null && !commandText.isBlank()) commands.addAll(Arrays.asList(commandText.split("\\n", -1)));
                crate.addReward(new Reward(
                        rs.getInt("id"), rs.getInt("position"), rs.getDouble("chance"), rs.getBoolean("chance_manual"),
                        parseEnum(RewardType.class, rs.getString("reward_type"), RewardType.GIVE_ITEM),
                        ItemCodec.decode(Optional.ofNullable(rs.getString("item_json")).orElse("")),
                        rs.getInt("amount"), commands));
            }
        }
    }

    private void loadConfigs(Connection c, Map<String, Crate> crates) { }

    private static void applyConfig(Crate crate, String configJson) {
        if (configJson == null || configJson.isBlank()) return;
        try {
            JsonObject json = JsonParser.parseString(configJson).getAsJsonObject();
            crate.createKey(getBoolean(json, "createKey", true));
            crate.keyDelivery(getString(json, "keyDelivery", "cloud"));
            crate.keyDisplayName(getString(json, "keyDisplayName", "&#FFD54AZxCrates Key"));
            if (json.has("keyItem") && json.get("keyItem").isJsonPrimitive()) crate.keyItem(ItemCodec.decode(json.get("keyItem").getAsString()));
            crate.keyStacked(getBoolean(json, "keyStacked", true));
            crate.openPermission(getString(json, "openPermission", ""));
            long cooldownSeconds = json.has("cooldownSeconds") ? getLong(json, "cooldownSeconds", 0L) : Math.max(0L, (getLong(json, "cooldownMs", 0L) + 999L) / 1000L);
            crate.cooldownSeconds(cooldownSeconds);
            crate.broadcastWin(getBoolean(json, "broadcastWin", false));
            crate.slots((int) getLong(json, "slots", 45L));
            crate.hologramEnabled(getBoolean(json, "hologramEnabled", true));
            crate.hologramText(getString(json, "hologramText", "&a%zxcrates_crate% Crate\n&r\n&a▶ &fHit To &aPreview &a!\n&a▶ &fUse Key To &aOpen &a!\n&fYou Have &a%zxcrates_crate_keys_crateid%\n&f%zxcrates_crate% &aKey!\n&r\n&fSelector Type: &aRandom\n&fBuy Keys! &a/Store"));
            crate.hologramOffsetY(getDouble(json, "hologramOffsetY", 1.2D));
            crate.hologramViewDistance(getDouble(json, "hologramViewDistance", 32.0D));
            crate.hologramBackground(getBoolean(json, "hologramBackground", false));
            if (json.has("itemLore") && json.get("itemLore").isJsonArray()) {
                List<String> lore = new ArrayList<>();
                json.getAsJsonArray("itemLore").forEach(value -> { if (value.isJsonPrimitive()) lore.add(value.getAsString()); });
                crate.itemLore(lore);
            }
            if (json.has("locations") && json.get("locations").isJsonArray()) {
                json.getAsJsonArray("locations").forEach(value -> { if (value.isJsonPrimitive()) crate.addLocationKey(value.getAsString()); });
            }
        } catch (Exception ignored) { }
    }

    private static String buildConfig(Crate crate) {
        JsonObject json = new JsonObject();
        json.addProperty("createKey", crate.createKey());
        json.addProperty("keyDelivery", crate.keyDelivery());
        json.addProperty("keyDisplayName", crate.keyDisplayName());
        json.addProperty("keyItem", ItemCodec.encode(crate.keyItem()));
        json.addProperty("keyStacked", crate.keyStacked());
        json.addProperty("openPermission", crate.openPermission());
        json.addProperty("cooldownSeconds", crate.cooldownSeconds());
        json.addProperty("broadcastWin", crate.broadcastWin());
        json.addProperty("slots", crate.slots());
        json.addProperty("hologramEnabled", crate.hologramEnabled());
        json.addProperty("hologramText", crate.hologramText());
        json.addProperty("hologramOffsetY", crate.hologramOffsetY());
        json.addProperty("hologramViewDistance", crate.hologramViewDistance());
        json.addProperty("hologramBackground", crate.hologramBackground());
        var itemLore = new com.google.gson.JsonArray();
        crate.itemLore().forEach(itemLore::add);
        json.add("itemLore", itemLore);
        var locations = new com.google.gson.JsonArray();
        crate.locations().forEach(locations::add);
        json.add("locations", locations);
        return json.toString();
    }

    private static String getString(JsonObject json, String key, String fallback) { return json.has(key) ? json.get(key).getAsString() : fallback; }
    private static boolean getBoolean(JsonObject json, String key, boolean fallback) { return json.has(key) ? json.get(key).getAsBoolean() : fallback; }
    private static long getLong(JsonObject json, String key, long fallback) { try { return json.has(key) ? json.get(key).getAsLong() : fallback; } catch (Exception ignored) { return fallback; } }
    private static double getDouble(JsonObject json, String key, double fallback) { try { return json.has(key) ? json.get(key).getAsDouble() : fallback; } catch (Exception ignored) { return fallback; } }

    @Override
    public CompletableFuture<Void> save(Crate crate) {
        return CompletableFuture.runAsync(() -> {
            try (Connection c = ds.getConnection()) {
                c.setAutoCommit(false);
                try {
                    try (PreparedStatement ps = c.prepareStatement(
                            "INSERT INTO crates(id,display_name,type,block_material,animation) VALUES(?,?,?,?,?) " +
                                    "ON DUPLICATE KEY UPDATE display_name=VALUES(display_name),type=VALUES(type)," +
                                    "block_material=VALUES(block_material),animation=VALUES(animation)")) {
                        ps.setString(1, crate.id());
                        ps.setString(2, crate.displayName());
                        ps.setString(3, crate.type().name());
                        ps.setString(4, crate.blockMaterial().name());
                        ps.setString(5, crate.animation().name());
                        ps.executeUpdate();
                    }
                    try (PreparedStatement config = c.prepareStatement("UPDATE crates SET config=? WHERE id=?")) {
                        config.setString(1, buildConfig(crate));
                        config.setString(2, crate.id());
                        config.executeUpdate();
                    }
                    try (PreparedStatement delete = c.prepareStatement("DELETE FROM rewards WHERE crate_id=?")) {
                        delete.setString(1, crate.id());
                        delete.executeUpdate();
                    }
                    try (PreparedStatement insert = c.prepareStatement(
                            "INSERT INTO rewards(crate_id,item_json,chance,chance_manual,reward_type,command_text,amount,position) VALUES(?,?,?,?,?,?,?,?)")) {
                        int position = 0;
                        for (Reward reward : crate.rewards()) {
                            insert.setString(1, crate.id());
                            insert.setString(2, ItemCodec.encode(reward.item()));
                            insert.setDouble(3, reward.chance());
                            insert.setBoolean(4, reward.chanceManual());
                            insert.setString(5, reward.type().name());
                            insert.setString(6, String.join("\n", reward.commands()));
                            insert.setInt(7, reward.amount());
                            insert.setInt(8, reward.slot() >= 0 ? reward.slot() : position);
                            position++;
                            insert.addBatch();
                        }
                        insert.executeBatch();
                    }
                    c.commit();
                } catch (Exception exception) {
                    try { c.rollback(); } catch (SQLException ignored) { }
                    throw exception;
                }
            } catch (Exception ex) {
                throw new CompletionException(ex);
            }
        }, executor);
    }

    @Override
    public CompletableFuture<Void> delete(String id) {
        return CompletableFuture.runAsync(() -> {
            try (Connection c = ds.getConnection()) {
                c.setAutoCommit(false);
                try (PreparedStatement reward = c.prepareStatement("DELETE FROM rewards WHERE crate_id=?")) {
                    reward.setString(1, id);
                    reward.executeUpdate();
                }
                try (PreparedStatement crate = c.prepareStatement("DELETE FROM crates WHERE id=?")) {
                    crate.setString(1, id);
                    crate.executeUpdate();
                }
                c.commit();
            } catch (Exception ex) {
                throw new CompletionException(ex);
            }
        }, executor);
    }

    @Override
    public CompletableFuture<Integer> getKeys(UUID player, String crateId) {
        return CompletableFuture.supplyAsync(() -> {
            try (Connection c = ds.getConnection(); PreparedStatement ps = c.prepareStatement(
                    "SELECT amount FROM player_keys WHERE player_uuid=? AND crate_id=?")) {
                ps.setString(1, player.toString());
                ps.setString(2, crateId.toLowerCase(Locale.ROOT));
                try (ResultSet rs = ps.executeQuery()) { return rs.next() ? Math.max(0, rs.getInt(1)) : 0; }
            } catch (SQLException ex) {
                throw new CompletionException(ex);
            }
        }, executor);
    }

    @Override
    public CompletableFuture<Void> setKeys(UUID player, String crateId, int amount) {
        return CompletableFuture.runAsync(() -> {
            try (Connection c = ds.getConnection(); PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO player_keys(player_uuid,crate_id,amount) VALUES(?,?,?) " +
                            "ON DUPLICATE KEY UPDATE amount=VALUES(amount)")) {
                ps.setString(1, player.toString());
                ps.setString(2, crateId.toLowerCase(Locale.ROOT));
                ps.setInt(3, Math.max(0, amount));
                ps.executeUpdate();
            } catch (SQLException ex) {
                throw new CompletionException(ex);
            }
        }, executor);
    }

    @Override
    public CompletableFuture<Boolean> takeKey(UUID player, String crateId) {
        return CompletableFuture.supplyAsync(() -> {
            try (Connection c = ds.getConnection(); PreparedStatement ps = c.prepareStatement(
                    "UPDATE player_keys SET amount=amount-1 WHERE player_uuid=? AND crate_id=? AND amount>0")) {
                ps.setString(1, player.toString());
                ps.setString(2, crateId.toLowerCase(Locale.ROOT));
                return ps.executeUpdate() == 1;
            } catch (SQLException ex) {
                throw new CompletionException(ex);
            }
        }, executor);
    }

    public void logWin(UUID player, String crateId, int rewardId) {
        CompletableFuture.runAsync(() -> {
            try (Connection c = ds.getConnection(); PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO logs(player_uuid,crate_id,reward_id) VALUES(?,?,?)")) {
                ps.setString(1, player.toString());
                ps.setString(2, crateId);
                ps.setInt(3, rewardId);
                ps.executeUpdate();
            } catch (SQLException ex) {
                throw new CompletionException(ex);
            }
        }, executor);
    }

    public void close() { ds.close(); }

    private static <E extends Enum<E>> E parseEnum(Class<E> type, String raw, E fallback) {
        try { return Enum.valueOf(type, raw.toUpperCase(Locale.ROOT)); }
        catch (Exception ignored) { return fallback; }
    }

    private static final class MaterialSafe {
        private static void setBlockMaterial(Crate crate, String name) {
            org.bukkit.Material material = org.bukkit.Material.matchMaterial(name == null ? "CHEST" : name);
            crate.blockMaterial(material == null ? org.bukkit.Material.CHEST : material);
        }
    }
}
