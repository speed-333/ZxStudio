# Changelog

## 1.0.0
- Added `/crate hologram <crateid> background default|transparent`.
- Transparent holograms now explicitly clear both the default and custom TextDisplay background.
- Optimized hologram visibility for Paper/Folia using player movement events and chunk indexing.

ZxCrates 1.0.0

## Latest changes
- Added configurable `crate-defaults.hologram.background` and an editor toggle for TextDisplay background visibility.
- Display Block can now be selected directly from a block item in the player inventory, cursor, or main hand without placing/consuming the item.
- Reward Chance now supports automatic distribution: automatic rewards split the unused percentage equally. Example: 3 automatic rewards = 33.33% each; one manual 10% reward leaves 45% + 45% for two automatic rewards.
- Manual Chance is persisted with `chance-manual` (flat file) / `chance_manual` (MySQL). Existing rewards without the manual flag default to automatic distribution.

## 1.0.0 - Direct Reward Chance

- Reward chance is now exposed with reward-aware context.
- `%reward_chance%` shows the effective probability for the displayed reward, including the bare `%reward_chance%` form used by the default lore.
- `%zxcrates_reward_chance_<crate_id>_<reward_id>%` is available through PlaceholderAPI.
- Reward editor shows configured weight and effective probability.

# ZxCrates 1.0.0

- Updated default crate hologram text to the requested Common Crate layout.
- Added the requested default reward item lore and applied it to newly created crates.
- Kept explicit per-crate `hologram.text` and `item-lore` values intact.


- Fixed duplicate dynamic holograms by reusing TextDisplay entities in place.
- Added queued-spawn de-duplication for per-player holograms.
- Refreshing player-specific placeholders now updates existing holograms instead of rebuilding them.

# ZxCrates 1.1.4

- Rebuilt placeholder resolution for internal text, Holograms, and PlaceholderAPI.
- Removed the global hologram view-distance setting from config.yml; per-crate hologram view distance remains supported.
- Changed crate cooldown storage and editor input from milliseconds to seconds, with legacy migration support.
- Added reset-named black glass panes to Crate Preview empty slots.

# 1.1.3
- Updated the default crate hologram format.
- Added configurable hologram view distance with per-crate persistence.
- Added configurable KeyAll distribution sound.
- Added literal `crateid` hologram placeholder expansion for crate key counts.

# Changelog

## 1.1.2
- Restored and stabilized the opening action bar.
- Kept animation sounds active when visual effects are disabled.
- Added cached physical-key counts for thread-safe, low-cost hologram placeholders.
- Optimized opening animation updates and icon caching.
- Improved inventory reward importing and direct inventory-to-reward placement.
- Fixed hologram placeholder rendering and default key placeholder text.
- Added direct `/crate keyall <keyid>` support alongside configured KeyAll IDs.

## 1.1.1
- Reworked all opening animations with faster multi-motion GUI patterns and no glass fill.
- Import From Inventory now copies the main inventory and hotbar in the same visual layout, excluding armor and off-hand.
- Direct click and drag from player inventory to reward slots are supported without an import mode.
- Added `opening.pause-cosmetics` metadata signaling during crate opening.
- Reworked hologram color parsing for legacy and hex colors and improved dynamic placeholder refresh.

## 1.0.9

- Rebuilt the animation set around Galaxy plus ten new animations.
- Added a green confirmation step for select crates.
- Added nameless black stained glass panes for unused crate GUI slots.
- Reworked placeholders for crate keys, player-specific holograms, and KeyAll countdowns.
- Reworked holograms to support player-specific dynamic text safely.
- Rebuilt KeyAll with multiple definitions, minute-based automatic schedules, `MM:SS` countdown placeholders, configurable completion commands, and immediate manual distribution.
- Added `/crate keyall <keyid>` and `/crates keyall <keyid>` with KeyAll-id tab completion.
- Bumped plugin version to 1.0.9 in the previous release notes.
- Added a new 1.0.9 regression suite.

## 1.1.0
- Removed animation glass background.
- Added exact reward GUI slot editing and direct inventory import workflow.
- Fixed hologram color rendering and crate hologram cleanup.
- Simplified KeyAll configuration and messaging.
- Added keyall countdown placeholders.

## Unreleased - crate hologram view-distance fix
- Fixed per-player hologram visibility so `hologram.view-distance` is enforced as an exact squared-distance check.
- Kept `TextDisplay#setViewRange` as an additional native rendering guard.
- Added `/crate(s) view_distance <crateid> <value>` with `0..128` validation and permissions `crate.view_distance.set` / `crates.view_distance.set`.
- The command persists the crate through the active repository and refreshes only the affected crate after successful save.
- Added focused visibility tests and regression invariants.

## Latest 1.0.0 view-distance stability fix
- Removed the top-level `/crate(s) view_distance` command.
- Added `/crate hologram <crateid> view_distance <crateid> <value>`.
- Reworked player visibility reconciliation to coalesce stale show/hide requests and prevent out-of-order visibility updates.
- Added per-world chunk-radius indexing and per-player dynamic-hologram indexing to reduce Folia/Paper hot-path work.
- Exact squared-distance checks remain authoritative for visibility.
