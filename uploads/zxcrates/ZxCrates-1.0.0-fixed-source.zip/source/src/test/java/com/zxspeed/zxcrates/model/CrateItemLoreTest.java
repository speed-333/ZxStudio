package com.zxspeed.zxcrates.model;

import org.junit.jupiter.api.Test;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

final class CrateItemLoreTest {
    @Test
    void itemLoreIsStoredAndCopiedWithSnapshot() {
        Crate crate = new Crate("legend");
        crate.itemLore(List.of("&7Line 1", "&#FF0000Line 2"));

        assertEquals(List.of("&7Line 1", "&#FF0000Line 2"), crate.itemLore());
        Crate snapshot = crate.snapshot();
        assertEquals(crate.itemLore(), snapshot.itemLore());

        crate.itemLore(List.of("&aChanged"));
        assertEquals(List.of("&7Line 1", "&#FF0000Line 2"), snapshot.itemLore());
    }
    @Test
    void defaultValuesMatchRequested() {
        Crate crate = new Crate("common");
        assertEquals(45, crate.slots());
        assertEquals("&a%zxcrates_crate% Crate\n&r\n&a▶ &fHit To &aPreview &a!\n&a▶ &fUse Key To &aOpen &a!\n&fYou Have &a%zxcrates_crate_keys_crateid%\n&f%zxcrates_crate% &aKey!\n&r\n&fSelector Type: &aRandom\n&fBuy Keys! &a/Store", crate.hologramText());
        assertEquals(List.of("", "&8&m----------------", "&fᴄʜᴀɴᴄᴇ: &e%reward_chance%", "&fʏᴏᴜʀ ᴋᴇʏѕ: &e%zxcrates_crate_keys_crateid%", "&8&m----------------"), crate.itemLore());
    }
}
