from pathlib import Path
import re, zipfile, tempfile, shutil, subprocess, sys

ROOT = Path(__file__).resolve().parent
SRC = ROOT / 'src'
failures = []

# Config checks
config = (SRC / 'main/resources/config.yml').read_text(encoding='utf-8')
if 'view-distance: 32.0' in config:
    failures.append('global hologram view-distance still exists')
if 'hologram:' not in config or '%zxcrates_crate_keys_crateid%' not in config:
    failures.append('default hologram configuration is missing')

# Placeholder checks
ph = (SRC / 'main/java/com/zxspeed/zxcrates/placeholder/PlaceholderService.java').read_text(encoding='utf-8')
for token in ['crate_keys_', 'crate_keys_crateid', 'crate_keys_total', 'keyall_time', 'crate_name_', 'crate_type_']:
    if token not in ph:
        failures.append(f'placeholder support missing: {token}')

# Cooldown checks
for path in SRC.glob('main/java/**/*.java'):
    text = path.read_text(encoding='utf-8')
    if 'cooldownMs()' in text or 'cooldownMs(' in text:
        failures.append(f'old cooldown API remains: {path}')
if 'cooldown-seconds' not in (SRC/'main/java/com/zxspeed/zxcrates/storage/FlatFileRepository.java').read_text(encoding='utf-8'):
    failures.append('flatfile cooldown-seconds missing')
if 'cooldownSeconds' not in (SRC/'main/java/com/zxspeed/zxcrates/db/MySqlRepository.java').read_text(encoding='utf-8'):
    failures.append('mysql cooldownSeconds missing')

# Preview pane
preview = (SRC/'main/java/com/zxspeed/zxcrates/gui/CratePreviewMenu.java').read_text(encoding='utf-8')
items = (SRC/'main/java/com/zxspeed/zxcrates/gui/GuiItems.java').read_text(encoding='utf-8')
if 'resetNamePane()' not in preview or 'resetNamePane()' not in items or '"&r"' not in items:
    failures.append('preview glass reset-name pane missing')

# No Arabic in Java source
for path in (SRC/'main/java').rglob('*.java'):
    text = path.read_text(encoding='utf-8')
    if re.search(r'[\u0600-\u06FF]', text):
        failures.append(f'Arabic text found in Java source: {path}')

# Version
pom = (ROOT/'pom.xml').read_text(encoding='utf-8')
plugin = (SRC/'main/resources/plugin.yml').read_text(encoding='utf-8')
if '<version>1.1.4</version>' not in pom or 'version: 1.1.4' not in plugin:
    failures.append('version 1.1.4 missing')

# Basic balanced delimiters after stripping strings/comments approximately

def check_balance(text, label):
    stack=[]
    pairs={')':'(',']':'[','}':'{'}
    in_str=False; esc=False; line_comment=False; block=False; i=0
    while i < len(text):
        c=text[i]; n=text[i+1] if i+1<len(text) else ''
        if line_comment:
            if c=='\n': line_comment=False
            i+=1; continue
        if block:
            if c=='*' and n=='/': block=False; i+=2; continue
            i+=1; continue
        if not in_str and c=='/' and n=='/': line_comment=True; i+=2; continue
        if not in_str and c=='/' and n=='*': block=True; i+=2; continue
        if c=='"' and not esc:
            in_str=not in_str; i+=1; continue
        if not in_str:
            if c in '([{': stack.append(c)
            elif c in ')]}':
                if not stack or stack[-1]!=pairs[c]: failures.append(f'unbalanced {label}: {c}'); return
                stack.pop()
        esc = (c=='\\' and not esc) if in_str else False
        i+=1
    if stack or in_str or block:
        failures.append(f'unbalanced {label}')

for path in (SRC/'main/java').rglob('*.java'):
    check_balance(path.read_text(encoding='utf-8'), str(path))

# YAML load
try:
    import yaml
    for path in (SRC/'main/resources').rglob('*.yml'):
        yaml.safe_load(path.read_text(encoding='utf-8'))
except Exception as exc:
    failures.append(f'yaml validation error: {exc}')

if failures:
    print('FAIL')
    for f in failures:
        print('-', f)
    sys.exit(1)
print('PASS')
