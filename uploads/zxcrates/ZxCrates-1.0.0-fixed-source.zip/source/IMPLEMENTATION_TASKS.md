# ZxCrates 1.0.1 – Implementation Status

## تم إصلاحه
- [x] إصلاح استيراد ItemStack من Inventory اللاعب.
- [x] منع فقدان العنصر عند فشل الحفظ.
- [x] دعم Cursor import.
- [x] دعم Drag import داخل Rewards.
- [x] منع Shift-Click/Drag من سرقة عناصر GUI.
- [x] Reward Editor.
- [x] Chat input لـ chance/amount/command.
- [x] Pagination للCrates والRewards.
- [x] Block binding من GUI والأمر.
- [x] Shift + Right Click للكسر مع permission.
- [x] FlatFile snapshot + backup.
- [x] MySQL CRUD أساسي + atomic key decrement.
- [x] snapshot قبل Async save لمنع ConcurrentModificationException.
- [x] rate limit + one-at-a-time opening.
- [x] key cache warm-up عند دخول اللاعب.
- [x] validation لحجم ItemStack وLore.

## يحتاج اختبار تشغيل فعلي
- [ ] اختبار Paper 1.20.x.
- [ ] اختبار Paper 1.21.11.
- [ ] اختبار Folia على عدة Regions.
- [ ] اختبار MySQL مع فقد اتصال أثناء الحفظ.
- [ ] اختبار PlaceholderAPI مع scoreboard plugin.
- [ ] اختبار ضغط عالي مع مئات اللاعبين.

## تحسينات النسخة التالية
- [ ] physical key item باستخدام PersistentDataContainer مع مزامنة كاملة مع player_keys.
- [ ] animations مستقلة لكل strategy بدل progress fallback.
- [ ] broadcast/sounds/particles configurable بالكامل من GUI.
- [ ] Web/Admin REST اختياري.
- [ ] statistics dashboard.


## Added in 1.0.2
- [x] Per-crate YAML files under `plugins/ZxCrates/crates/`.
- [x] Configurable crate opening inventory slots (9/18/27/36/45/54).
- [x] Crate Item with PDC and `/crate givecrate <crate>`.
- [x] Automatic TextDisplay hologram when a crate Item is placed or a location is bound.
- [x] Hologram settings editable in each crate YAML.
- [x] Crate-file reload through `/zxcrates reload`.
