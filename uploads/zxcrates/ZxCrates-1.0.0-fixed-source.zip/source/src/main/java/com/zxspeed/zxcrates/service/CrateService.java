package com.zxspeed.zxcrates.service;

import com.zxspeed.zxcrates.ZxCratesPlugin;
import com.zxspeed.zxcrates.model.*;
import com.zxspeed.zxcrates.util.ColorUtil;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.ConcurrentHashMap;

public final class CrateService {
    public record Win(Crate crate, Reward reward) {}
    private final ZxCratesPlugin plugin;
    private final CrateRepository repo;
    private final Map<String, Crate> crates = new ConcurrentHashMap<>();
    private final Map<String, Integer> keyCache = new ConcurrentHashMap<>();
    private final Map<String, Integer> physicalKeyCache = new ConcurrentHashMap<>();
    private final Map<UUID, Long> rate = new ConcurrentHashMap<>();
    private final Map<String, Long> crateRate = new ConcurrentHashMap<>();
    private final Map<String, CompletableFuture<Void>> saveChains = new ConcurrentHashMap<>();
    private final Map<String, CompletableFuture<Void>> keyMutationChains = new ConcurrentHashMap<>();
    private final Map<UUID, AtomicBoolean> opening = new ConcurrentHashMap<>();
    private final Map<UUID, String> lastWin = new ConcurrentHashMap<>();
    private final Map<UUID, String> lastWinCrate = new ConcurrentHashMap<>();
    private final Map<UUID, Integer> lastWinAmount = new ConcurrentHashMap<>();
    private final Map<UUID, Long> opensTotal = new ConcurrentHashMap<>();
    private final Map<String, Long> opensByCrate = new ConcurrentHashMap<>();
    private final Map<UUID, String> openingCrate = new ConcurrentHashMap<>();
    private final long rateLimitMs;
    private final NamespacedKey keyItemId;

    public CrateService(ZxCratesPlugin plugin, CrateRepository repo, long rateLimitMs) {
        this.plugin = plugin;
        this.repo = repo;
        this.rateLimitMs = Math.max(0, rateLimitMs);
        this.keyItemId = new NamespacedKey(plugin, "key-id");
    }

    public CompletableFuture<Void> load() { return repo.loadAll().thenAccept(all -> { crates.clear(); all.forEach(c -> crates.put(c.id().toLowerCase(Locale.ROOT), c)); }); }
    public Collection<Crate> all() { return List.copyOf(crates.values()); }
    public Optional<Crate> get(String id) { return id == null ? Optional.empty() : Optional.ofNullable(crates.get(id.toLowerCase(Locale.ROOT))); }

    public CompletableFuture<Void> create(String id) {
        String normalized = normalizeId(id);
        if (crates.containsKey(normalized)) return CompletableFuture.failedFuture(new IllegalArgumentException("Crate already exists"));
        Crate c = new Crate(normalized);
        c.keyDelivery(plugin.getConfig().getString("keys.default-delivery", "cloud"));
        c.keyDisplayName(plugin.getConfig().getString("keys.display-name", "&#FFD54AZxCrates Key"));
        c.keyStacked(plugin.getConfig().getBoolean("keys.stacked", true));
        c.slots(plugin.getConfig().getInt("crate-defaults.slots", 45));
        c.hologramText(plugin.getConfig().getString("crate-defaults.hologram.text", c.hologramText()));
        c.hologramOffsetY(plugin.getConfig().getDouble("crate-defaults.hologram.offset-y", c.hologramOffsetY()));
        c.hologramEnabled(plugin.getConfig().getBoolean("crate-defaults.hologram.enabled", c.hologramEnabled()));
        c.hologramViewDistance(32.0D);
        c.hologramBackground(plugin.getConfig().getBoolean("crate-defaults.hologram.background", false));
        java.util.List<String> configuredLore = plugin.getConfig().getStringList("crate-defaults.item-lore");
        if (!configuredLore.isEmpty()) c.itemLore(configuredLore);
        crates.put(normalized, c); return enqueueSave(c);
    }

    public CompletableFuture<Void> save(Crate crate) {
        if (crate == null) return CompletableFuture.failedFuture(new IllegalArgumentException("crate is null"));
        crates.put(crate.id().toLowerCase(Locale.ROOT), crate); return enqueueSave(crate);
    }

    private CompletableFuture<Void> enqueueSave(Crate crate) {
        String id = crate.id().toLowerCase(Locale.ROOT); Crate snapshot = crate.snapshot();
        CompletableFuture<Void> result = saveChains.compute(id, (key, previous) -> {
            CompletableFuture<Void> base = previous == null ? CompletableFuture.completedFuture(null) : previous.handle((ignored, error) -> null);
            return base.thenCompose(ignored -> repo.save(snapshot));
        });
        result.whenComplete((ignored, error) -> saveChains.remove(id, result));
        return result;
    }

    public CompletableFuture<Void> delete(String id) {
        String key = id.toLowerCase(Locale.ROOT); crates.remove(key);
        CompletableFuture<Void> result = saveChains.compute(key, (ignored, previous) -> {
            CompletableFuture<Void> base = previous == null ? CompletableFuture.completedFuture(null) : previous.handle((v, e) -> null);
            return base.thenCompose(v -> repo.delete(key));
        });
        result.whenComplete((ignored, error) -> saveChains.remove(key, result));
        return result;
    }

    private String k(UUID uuid, String crateId) { return uuid + ":" + crateId.toLowerCase(Locale.ROOT); }
    public int cachedKeys(UUID uuid, String crateId) { return keyCache.getOrDefault(k(uuid, crateId), 0); }
    public int cachedTotalKeys(UUID uuid) {
        if (uuid == null) return 0;
        return crates.values().stream().mapToInt(c -> c.isCloudKey()
                ? cachedKeys(uuid, c.id())
                : cachedPhysicalKeys(uuid, c.id())).sum();
    }

    public int cachedPhysicalKeys(UUID uuid, String crateId) {
        return uuid == null || crateId == null ? 0 : physicalKeyCache.getOrDefault(k(uuid, crateId), 0);
    }

    /** Refreshes physical key counts. Call from the player's own scheduler. */
    public void refreshPhysicalKeys(Player player) {
        refreshPhysicalKeysNow(player);
    }

    private void refreshPhysicalKeysNow(Player player) {
        if (player == null || !player.isOnline()) return;
        Map<String, Integer> counts = new HashMap<>();
        for (ItemStack item : player.getInventory().getStorageContents()) {
            if (item == null || item.getType().isAir()) continue;
            ItemMeta meta = item.getItemMeta();
            if (meta == null) continue;
            String crateId = meta.getPersistentDataContainer().get(keyItemId, PersistentDataType.STRING);
            if (crateId == null || crateId.isBlank()) continue;
            counts.merge(crateId.toLowerCase(Locale.ROOT), item.getAmount(), Integer::sum);
        }
        String prefix = player.getUniqueId() + ":";
        physicalKeyCache.keySet().removeIf(key -> key.startsWith(prefix));
        counts.forEach((crateId, count) -> physicalKeyCache.put(prefix + crateId, Math.max(0, count)));
    }

    public CompletableFuture<Void> warmKeys(UUID uuid) {
        if (uuid == null) return CompletableFuture.completedFuture(null);
        List<CompletableFuture<Integer>> loads = all().stream().filter(Crate::isCloudKey).map(crate -> keys(uuid, crate.id())).toList();
        return CompletableFuture.allOf(loads.toArray(CompletableFuture[]::new));
    }

    public CompletableFuture<Integer> keys(UUID uuid, String crateId) {
        String key = k(uuid, crateId); Integer cached = keyCache.get(key);
        if (cached != null) return CompletableFuture.completedFuture(cached);
        return repo.getKeys(uuid, crateId).thenApply(value -> { int safe = Math.max(0, value); keyCache.put(key, safe); return safe; });
    }

    public CompletableFuture<Void> addKeys(UUID uuid, String crateId, int amount) {
        if (uuid == null || crateId == null || amount <= 0) return CompletableFuture.completedFuture(null);
        String key = k(uuid, crateId);
        return enqueueKeyMutation(key, () -> keys(uuid, crateId).thenCompose(current -> { int next = Math.max(0, current + amount); keyCache.put(key, next); return repo.setKeys(uuid, crateId, next); }));
    }

    public CompletableFuture<Boolean> takeKey(UUID uuid, String crateId) {
        if (uuid == null || crateId == null) return CompletableFuture.completedFuture(false);
        String key = k(uuid, crateId); AtomicBoolean result = new AtomicBoolean(false);
        return enqueueKeyMutation(key, () -> keys(uuid, crateId).thenCompose(current -> {
            if (current <= 0) return CompletableFuture.completedFuture(null);
            return repo.takeKey(uuid, crateId).thenAccept(ok -> { result.set(ok); if (ok) keyCache.put(key, Math.max(0, current - 1)); });
        })).thenApply(ignored -> result.get());
    }

    public CompletableFuture<Boolean> takeKey(Player player, Crate crate) {
        if (player == null || crate == null) return CompletableFuture.completedFuture(false);
        return crate.isItemKey() ? CompletableFuture.completedFuture(removePhysicalKey(player, crate)) : takeKey(player.getUniqueId(), crate.id());
    }

    public CompletableFuture<Void> giveKeys(Player player, Crate crate, int amount) {
        if (player == null || crate == null || amount <= 0) return CompletableFuture.completedFuture(null);
        if (crate.isCloudKey()) return addKeys(player.getUniqueId(), crate.id(), amount);
        CompletableFuture<Void> result = new CompletableFuture<>();
        player.getScheduler().run(plugin, task -> {
            try {
                ItemStack base = buildKeyItem(crate);
                int remaining = amount;
                int max = Math.max(1, base.getMaxStackSize());
                while (remaining > 0) {
                    int give = crate.keyStacked() ? Math.min(remaining, max) : 1;
                    ItemStack item = base.clone();
                    item.setAmount(give);
                    Map<Integer, ItemStack> overflow = player.getInventory().addItem(item);
                    overflow.values().forEach(drop -> player.getWorld().dropItemNaturally(player.getLocation(), drop));
                    remaining -= give;
                }
                refreshPhysicalKeysNow(player);
                result.complete(null);
            } catch (Throwable throwable) {
                result.completeExceptionally(throwable);
            }
        }, null);
        return result;
    }

    public int keyCount(Player player, Crate crate) {
        if (player == null || crate == null) return 0;
        return crate.isCloudKey()
                ? cachedKeys(player.getUniqueId(), crate.id())
                : cachedPhysicalKeys(player.getUniqueId(), crate.id());
    }

    private ItemStack buildKeyItem(Crate crate) {
        ItemStack base = crate.keyItem() == null ? new ItemStack(org.bukkit.Material.TRIPWIRE_HOOK) : crate.keyItem();
        ItemMeta meta = base.getItemMeta();
        if (meta != null) {
            meta.displayName(net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer.legacySection().deserialize(ColorUtil.colorize(crate.keyDisplayName())).decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false));
            meta.getPersistentDataContainer().set(keyItemId, PersistentDataType.STRING, crate.id());
            if (!crate.keyStacked()) meta.setMaxStackSize(1);
            base.setItemMeta(meta);
        }
        base.setAmount(1); return base;
    }

    private boolean removePhysicalKey(Player player, Crate crate) {
        ItemStack[] contents = player.getInventory().getStorageContents();
        for (int i = 0; i < contents.length; i++) {
            ItemStack item = contents[i]; if (item == null || item.getType().isAir()) continue;
            ItemMeta meta = item.getItemMeta(); if (meta == null) continue;
            if (!crate.id().equalsIgnoreCase(meta.getPersistentDataContainer().get(keyItemId, PersistentDataType.STRING))) continue;
            if (item.getAmount() <= 1) contents[i] = null; else item.setAmount(item.getAmount() - 1);
            player.getInventory().setStorageContents(contents);
            physicalKeyCache.put(k(player.getUniqueId(), crate.id()), Math.max(0, cachedPhysicalKeys(player.getUniqueId(), crate.id()) - 1));
            return true;
        }
        return false;
    }

    private CompletableFuture<Void> enqueueKeyMutation(String key, java.util.function.Supplier<CompletableFuture<Void>> action) {
        CompletableFuture<Void> result = keyMutationChains.compute(key, (ignored, previous) -> {
            CompletableFuture<Void> base = previous == null ? CompletableFuture.completedFuture(null) : previous.handle((ignoredValue, error) -> null);
            return base.thenCompose(ignoredValue -> action.get());
        });
        result.whenComplete((ignored, error) -> keyMutationChains.remove(key, result));
        return result;
    }

    public void setOpeningCrate(UUID uuid, String crateId) { if (uuid != null && crateId != null) openingCrate.put(uuid, crateId); }

    public boolean tryBeginOpening(UUID uuid) { if (uuid == null) return false; return opening.computeIfAbsent(uuid, ignored -> new AtomicBoolean()).compareAndSet(false, true); }
    public boolean isOpening(UUID uuid) { AtomicBoolean flag = uuid == null ? null : opening.get(uuid); return flag != null && flag.get(); }
    public void endOpening(UUID uuid) { AtomicBoolean flag = uuid == null ? null : opening.get(uuid); if (flag != null) { flag.set(false); opening.remove(uuid, flag); } if (uuid != null) openingCrate.remove(uuid); }
    public boolean rateLimited(Player player) { long now = System.currentTimeMillis(); long last = rate.getOrDefault(player.getUniqueId(), 0L); if (now - last < rateLimitMs) return true; rate.put(player.getUniqueId(), now); return false; }
    public boolean rateLimitedNow(Player player) { long now = System.currentTimeMillis(); long last = rate.getOrDefault(player.getUniqueId(), 0L); return now - last < rateLimitMs; }
    public boolean cooldownActive(Player player, Crate crate) { long cooldownSeconds = crate.cooldownSeconds(); if (cooldownSeconds <= 0) return false; String key = player.getUniqueId()+":"+crate.id().toLowerCase(Locale.ROOT); long elapsed = System.currentTimeMillis()-crateRate.getOrDefault(key,0L); return elapsed < cooldownSeconds * 1000L; }
    public void markOpened(Player player, Crate crate) { long now=System.currentTimeMillis(); rate.put(player.getUniqueId(),now); crateRate.put(player.getUniqueId()+":"+crate.id().toLowerCase(Locale.ROOT),now); openingCrate.put(player.getUniqueId(),crate.id()); }

    public void rebalanceRewardChances(Crate crate) { if (crate != null) crate.rebalanceRewardChances(); }

    public Optional<Win> roll(Crate crate) {
        if (crate.rewards().isEmpty() || crate.type()==CrateType.SELECT) return Optional.empty();
        List<Double> chances=crate.rewards().stream().map(Reward::chance).toList();
        if (!ChanceCalculator.validDistribution(chances)) return Optional.empty();
        int index=ChanceCalculator.pickIndex(chances);
        return index<0?Optional.empty():Optional.of(new Win(crate,crate.rewards().get(index)));
    }
    public void recordWin(Player player, Crate crate, Reward reward) { UUID uuid=player.getUniqueId(); lastWin.put(uuid,reward==null||reward.item()==null?"Command Reward":reward.item().getType().name()); if(crate!=null){lastWinCrate.put(uuid,crate.id());opensByCrate.merge(uuid+":"+crate.id().toLowerCase(Locale.ROOT),1L,Long::sum);} lastWinAmount.put(uuid,reward==null?0:Math.max(0,reward.amount())); opensTotal.merge(uuid,1L,Long::sum); }
    public String lastWin(Player player) { return lastWin.getOrDefault(player.getUniqueId(),""); }
    public String lastWinCrate(Player player) { return lastWinCrate.getOrDefault(player.getUniqueId(),""); }
    public int lastWinAmount(Player player) { return lastWinAmount.getOrDefault(player.getUniqueId(),0); }
    public long opensTotal(Player player) { return opensTotal.getOrDefault(player.getUniqueId(),0L); }
    public long opens(Player player,String crateId){return opensByCrate.getOrDefault(player.getUniqueId()+":"+crateId.toLowerCase(Locale.ROOT),0L);}
    public String openingCrate(UUID uuid){return openingCrate.getOrDefault(uuid,"");}

    public void giveItem(Player player, ItemStack base, int amount) { if(base==null||base.getType().isAir())return; ItemStack remaining=base.clone(); remaining.setAmount(Math.max(1,amount)); Map<Integer,ItemStack> overflow=player.getInventory().addItem(remaining); overflow.values().forEach(drop->player.getWorld().dropItemNaturally(player.getLocation(),drop)); }
    public Optional<Crate> findAt(org.bukkit.Location location){for(Crate crate:crates.values())if(crate.isAt(location))return Optional.of(crate);return Optional.empty();}
    private static String normalizeId(String id){if(id==null||!id.matches("[A-Za-z0-9_-]{1,32}"))throw new IllegalArgumentException("Invalid crate id");return id.toLowerCase(Locale.ROOT);}
}
