package com.zxspeed.zxcrates.service;

import com.zxspeed.zxcrates.ZxCratesPlugin;
import com.zxspeed.zxcrates.model.Crate;
import com.zxspeed.zxcrates.util.ColorUtil;
import com.zxspeed.zxcrates.util.Tasks;
import io.papermc.paper.threadedregions.scheduler.ScheduledTask;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

public final class KeyAllManager {
    private final ZxCratesPlugin plugin;
    private final File file;
    private final Map<String,ScheduledTask> schedules=new ConcurrentHashMap<>();
    private final Map<String,Long> nextRunAt=new ConcurrentHashMap<>();
    private volatile YamlConfiguration config;
    private volatile String defaultId="default";
    public KeyAllManager(ZxCratesPlugin plugin){this.plugin=plugin;this.file=new File(plugin.getDataFolder(),"keyall.yml");}
    public void loadAndStart(){loadConfig();startSchedules();}
    public void reload(){stop();loadConfig();startSchedules();}
    public void stop(){for(ScheduledTask task:schedules.values())if(task!=null)task.cancel();schedules.clear();nextRunAt.clear();}
    public YamlConfiguration config(){if(config==null)loadConfig();return config;}
    public String defaultId(){return defaultId;}
    public List<String> keyAllIds(){ConfigurationSection s=config().getConfigurationSection("keyalls");return s==null?List.of():s.getKeys(false).stream().sorted(String.CASE_INSENSITIVE_ORDER).toList();}
    public String timeRemainingDefault(){return timeRemaining(defaultId);}
    public String timeRemaining(String id){long target=nextRunAt.getOrDefault(normalize(id),-1L);if(target<0)return"00:00";long sec=Math.max(0,(target-System.currentTimeMillis()+999)/1000);return String.format(Locale.ROOT,"%02d:%02d",sec/60,sec%60);}

    public void execute(CommandSender sender,String[] args){
        if(!hasPermission(sender))return;
        if(args.length!=1||args[0].isBlank()){sender.sendMessage(ColorUtil.colorize("&eUsage: /crate keyall <keyid>"));return;}
        if(section(args[0])!=null){run(args[0],true,sender);return;}
        Crate crate=plugin.service().get(args[0]).orElse(null);
        if(crate==null){sender.sendMessage(ColorUtil.colorize("&cUnknown key or KeyAll ID: &f"+args[0]));return;}
        directGive(crate);
    }

    private void directGive(Crate crate){
        int amount=1;
        for(Player target:new ArrayList<>(Bukkit.getOnlinePlayers())){
            CompletableFuture<Void> op=plugin.service().giveKeys(target,crate,amount);
            op.whenComplete((ignored,error)->Tasks.player(target,plugin,()->{
                if(error!=null){plugin.getLogger().warning("Manual key distribution failed for "+target.getName()+": "+error.getMessage());return;}
                if(plugin.holograms()!=null)plugin.holograms().refreshPlayer(target);
            }));
        }
    }

    public CompletableFuture<Integer> run(String id,boolean manual,CommandSender initiator){
        String keyAllId=normalize(id);ConfigurationSection section=section(keyAllId);if(section==null)return CompletableFuture.completedFuture(0);
        String keyId=section.getString("key-id","").trim();Crate crate=plugin.service().get(keyId).orElse(null);
        if(crate==null){if(initiator!=null)initiator.sendMessage(ColorUtil.colorize("&cKey does not exist: &f"+keyId));return CompletableFuture.completedFuture(0);}
        int amount=Math.max(1,section.getInt("amount",1));List<Player> targets=new ArrayList<>(Bukkit.getOnlinePlayers());
        AtomicInteger success=new AtomicInteger();List<CompletableFuture<Void>> ops=new ArrayList<>(targets.size());
        for(Player target:targets){CompletableFuture<Void> op=plugin.service().giveKeys(target,crate,amount);op.whenComplete((ignored,error)->Tasks.player(target,plugin,()->{if(error!=null){plugin.getLogger().warning("KeyAll "+keyAllId+" failed for "+target.getName()+": "+error.getMessage());return;}success.incrementAndGet();if(plugin.holograms()!=null)plugin.holograms().refreshPlayer(target);sendMessages(target,section,keyAllId,crate,amount);}));ops.add(op.handle((ignored,error)->null));}
        return CompletableFuture.allOf(ops.toArray(CompletableFuture[]::new)).thenApply(ignored->{if(!manual){for(String raw:section.getStringList("commands")){String command=apply(raw,keyAllId,crate,amount,targets.size(),success.get());if(command.startsWith("/"))command=command.substring(1);String finalCommand=command.trim();if(!finalCommand.isEmpty())Tasks.global(plugin,()->Bukkit.dispatchCommand(Bukkit.getConsoleSender(),finalCommand));}}return success.get();});
    }

    private void sendMessages(Player player,ConfigurationSection section,String keyAllId,Crate crate,int amount){
        player.sendTitle(ColorUtil.colorize(apply(section.getString("messages.title","&aKEYALL"),keyAllId,crate,amount,0,0)),ColorUtil.colorize(apply(section.getString("messages.subtitle","&f+{amount} key(s)"),keyAllId,crate,amount,0,0)),5,35,10);
        player.sendMessage(ColorUtil.colorize(apply(section.getString("messages.chat","&aYou received &f{amount} &akey(s)."),keyAllId,crate,amount,0,0)));
        String rawSound = section.getString("messages.sound", "ENTITY_PLAYER_LEVELUP");
        try {
            Sound sound = Sound.valueOf(rawSound.toUpperCase(Locale.ROOT));
            player.playSound(player.getLocation(), sound, 1.0F, 1.0F);
        } catch (IllegalArgumentException ignored) {
            plugin.getLogger().warning("Invalid KeyAll sound: " + rawSound);
        }
    }

    private void loadConfig(){
        if(!file.exists())plugin.saveResource("keyall.yml",false);config=YamlConfiguration.loadConfiguration(file);
        if(config.getConfigurationSection("keyalls")==null){try{file.delete();}catch(Exception ignored){}if(!file.exists())plugin.saveResource("keyall.yml",false);config=YamlConfiguration.loadConfiguration(file);}
        defaultId=normalize(config.getString("default-keyall","default"));if(section(defaultId)==null){List<String> ids=keyAllIds();defaultId=ids.isEmpty()?"default":ids.get(0).toLowerCase(Locale.ROOT);}
    }
    private void startSchedules(){for(String id:keyAllIds())scheduleOne(id);}
    private void scheduleOne(String rawId){String id=normalize(rawId);ConfigurationSection s=section(id);if(s==null||!s.getBoolean("enabled",true))return;int minutes=Math.max(1,s.getInt("interval-minutes",60));long ticks=minutes*60L*20L;nextRunAt.put(id,System.currentTimeMillis()+minutes*60_000L);ScheduledTask task=plugin.getServer().getGlobalRegionScheduler().runAtFixedRate(plugin,t->{nextRunAt.put(id,System.currentTimeMillis()+minutes*60_000L);run(id,false,null);},ticks,ticks);schedules.put(id,task);}
    private ConfigurationSection section(String id){ConfigurationSection root=config().getConfigurationSection("keyalls");if(root==null||id==null)return null;for(String key:root.getKeys(false))if(key.equalsIgnoreCase(id))return root.getConfigurationSection(key);return null;}
    private boolean hasPermission(CommandSender sender){if(sender.hasPermission("ZxCrates.admin")||sender.hasPermission("ZxCrates.keyall"))return true;sender.sendMessage(ColorUtil.colorize("&cYou do not have permission to use KeyAll."));return false;}
    private String normalize(String id){return id==null||id.isBlank()?"default":id.toLowerCase(Locale.ROOT);}
    private String apply(String raw,String keyAllId,Crate crate,int amount,int online,int count){if(raw==null)return"";return raw.replace("{keyall_id}",keyAllId).replace("{key_id}",crate==null?"":crate.id()).replace("{crate}",crate==null?"":crate.displayName()).replace("{crate_id}",crate==null?"":crate.id()).replace("{amount}",String.valueOf(amount)).replace("{online}",String.valueOf(online)).replace("{count}",String.valueOf(count));}
}
