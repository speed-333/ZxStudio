# ZxCrates 1.0.0

ZxCrates is a Paper/Folia crate plugin with configurable random and select crates, motion-heavy animated openings, per-player keys, placeholders, holograms, and simple KeyAll scheduling.

## 1.1.2 highlights

- Galaxy plus ten motion-heavy animations.
- Opening GUI title is exactly `Open Crate` with the `§8` prefix. The opening ActionBar is restored and cleared safely when the opening ends.
- `opening.effects: false` disables only visual particles around the player; animation sounds remain active.
- Opening updates are optimized with cached reward icons, cached material icons, sparse slot updates, and reduced ActionBar updates.
- Select crates use a green confirmation button after a reward is selected, with click/confirm sounds and no reward title.
- Rewards can be imported from the complete main inventory + hotbar in visual order, excluding armor and off-hand.
- Rewards can also be copied directly from the player inventory by click/drag into a selected reward slot. Changes save automatically.
- Unused reward slots use nameless `BLACK_STAINED_GLASS_PANE`.
- Key settings GUI supports `item` or `cloud` delivery, key display name, custom key item, and stacked/separate delivery.
- Key placeholders are cached for physical and cloud keys so holograms do not read inventories from the global scheduler.
- Holograms support internal placeholders, PlaceholderAPI placeholders, legacy colors, hex colors, per-player rendering, and orphan cleanup when a crate is broken.
- Dynamic holograms only update a TextDisplay when the rendered text actually changes.
- All GUI titles use the `§8` prefix. The editor title is `§8ZxCrates Editor`; the preview title is `§8Crate Preview`.
- Save buttons were removed. Editor changes are saved automatically.

## Commands

- `/crates`
- `/crate`
- `/crates editor <crate-id>`
- `/crate editor <crate-id>`
- `/crates keyall <id>`
- `/crate keyall <id>`
- `/zxcrates keyall <id>`

`keyall <id>` accepts either a configured KeyAll ID or an existing crate ID. When a crate ID is supplied, one key is distributed directly to all online players without waiting for the automatic timer.

## KeyAll

`src/main/resources/keyall.yml` contains one default KeyAll and can contain additional independent definitions. Each definition supports an interval in minutes, a key/crate ID, amount, console commands after automatic completion, and only three player messages: title, subtitle, and chat.

KeyAll countdown placeholders use `MM:SS`:

- `%zxcrates_keyall_time%` or `{keyall_time}`
- `%zxcrates_keyall_time_<id>%` or `{keyall_time_<id>}`
- `%zxcrates_keyall_default%` or `{keyall_default}`

## Source layout

- `src/main/java`: plugin source
- `src/main/resources/config.yml`: main plugin configuration
- `src/main/resources/keyall.yml`: KeyAll configuration
- `src/main/resources/placeholder.yml`: placeholder reference
- `src/main/resources/lang/en.yml`: runtime language messages
- `regression-check-1.1.2.py`: static verification

## Verification

The 1.1.2 source package includes a regression check for animation inventory behavior, ActionBar, effect/sound separation, hologram placeholder rendering and caching, reward importing, direct inventory placement, key settings, KeyAll behavior, title formatting, YAML parsing, Java lexical balance, and Arabic-source leakage. Full Paper/Paper API compilation still requires a build environment with the required server API dependencies.


## Reward Chance

Each reward has a direct `chance` value from `0` to `100`. A value such as `4.5` means exactly `4.5%`, not a weight. The selector rolls directly on `0..100`; any unused percentage means no reward. The total reward chance must not exceed `100%`.

Inside reward lore, use `%reward_chance%` to display the configured direct chance:

```yaml
- '&fᴄʜᴀɴᴄᴇ: &e%reward_chance%'
```

For external PlaceholderAPI usage, use `%zxcrates_reward_chance_<crate_id>_<reward_id>%`.

In the Rewards GUI, click a reward to open its editor, then click **Chance** and enter a value from `0` to `100`. Values such as `4.5` are saved exactly as `4.5%`.

## Cosmetic pause integration

When `opening.pause-cosmetics: true`, ZxCrates sets player metadata `zxcrates.cosmetics-paused=true` for the duration of the crate animation and removes it when the opening ends. A cosmetics plugin must explicitly support this marker to pause its own visual effects.

## Default crate layout

New crates use `crate-defaults` from `config.yml`: 45 slots, the requested hologram text, and the requested five-line reward lore. Plugin-generated GUI/lore text is explicitly non-italic.

## Per-crate hologram view distance
Each crate YAML supports an independent hard visibility range:

```yaml
hologram:
  enabled: true
  view-distance: 32
```

`view-distance` is measured in blocks from the hologram's `TextDisplay` location. The plugin keeps the native Display `viewRange` as an additional client/server rendering guard and also performs explicit per-player show/hide checks using squared distance. A value of `0` disables visibility for that crate hologram; accepted command values are `0..128`.

### Commands
- `/crate hologram <crateid> view_distance <crateid> <value>`
- `/crates hologram <crateid> view_distance <crateid> <value>`

The legacy top-level `view_distance` command has been removed. Permissions:
- `crate.view_distance.set`
- `crates.view_distance.set`
- `ZxCrates.admin` bypasses the per-command permission check.

The command saves the crate immediately through the active repository and refreshes only that crate's holograms after a successful save. Other crates and running crate animations are not reloaded.

## ZxCrates 1.0.0 feature notes

### Hologram background
Set `crate-defaults.hologram.background: false` to hide the TextDisplay background. The same setting can be toggled from the Crate Editor.

### Display Block
Open the Crate Editor and use **Display Block**. You can click a block item in your player inventory, use a block from the cursor, or hold a block in your main hand. The item is not consumed.

### Automatic Reward Chance
Rewards are automatic by default. The remaining percentage is split equally between all automatic rewards. For example, three automatic rewards become 33.33% each. Setting one reward manually to 10% leaves 90% and automatically assigns 45% to each of two remaining automatic rewards.

In the Reward Editor, click **Chance** and enter a value from 0 to 100 to make that reward manual. Use **Shift + Right Click** on Chance to return that reward to automatic distribution.

