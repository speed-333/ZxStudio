from pathlib import Path
import re, sys, zipfile, subprocess, tempfile, os, yaml

ROOT = Path(__file__).parent
SRC = ROOT / 'src/main/java'
RES = ROOT / 'src/main/resources'
errors=[]

def read(rel):
    p=ROOT/rel
    if not p.exists(): errors.append(f'missing: {rel}'); return ''
    return p.read_text(encoding='utf-8')

def need(cond,msg):
    if not cond: errors.append(msg)

pom=read('pom.xml'); plugin=read('src/main/resources/plugin.yml')
an=read('src/main/java/com/zxspeed/zxcrates/model/AnimationType.java')
am=read('src/main/java/com/zxspeed/zxcrates/service/AnimationManager.java')
cs=read('src/main/java/com/zxspeed/zxcrates/service/CrateService.java')
cl=read('src/main/java/com/zxspeed/zxcrates/listener/CrateListener.java')
el=read('src/main/java/com/zxspeed/zxcrates/gui/EditorListener.java')
hm=read('src/main/java/com/zxspeed/zxcrates/service/HologramManager.java')
ps=read('src/main/java/com/zxspeed/zxcrates/placeholder/PlaceholderService.java')
ka=read('src/main/java/com/zxspeed/zxcrates/service/KeyAllManager.java')
conf=read('src/main/resources/config.yml')
keyall=read('src/main/resources/keyall.yml')
repo=read('src/main/java/com/zxspeed/zxcrates/storage/FlatFileRepository.java')

need('1.1.2' in pom and '1.1.2' in plugin,'version 1.1.2 missing')
anim_names=re.findall(r'^    ([A-Z][A-Z0-9_]+),?$', an, re.M)
need(len(anim_names)==11,'expected 11 animations')
need(anim_names[0]=='GALAXY' and 'GALAXY' in anim_names,'Galaxy missing/not first')
need('§8Open Crate' in am,'Open Crate title is not dark gray')
need('s.actionbar();' in am and 'player.sendActionBar(Component.empty())' in am,'opening actionbar not restored/cleared')
need('if(s.effectsEnabled() && frame%3==0) particles' in am and 'if(frame%5==0) sound' in am,'effects flag must affect particles only while sounds remain')
need('ConcurrentHashMap' in am,'animation icon cache should be thread-safe')
need('cachedIcons.computeIfAbsent' in am,'animation icon cache missing')
need('pause-cosmetics' in conf and '\n  effects:' in conf,'opening config options missing')
need('effects: true' in conf and 'pause-cosmetics: true' in conf,'opening config defaults missing')
need('&#FFFF55Keys: &#FFFFFF{crate_keys_<crate_id>}' in conf,'default hologram key placeholder missing')
need('crate_keys_<crate_id>' in repo,'crate repository placeholder fallback missing')
need('lastRendered' in hm and 'rendered.equals(lastRendered.get(key))' in hm,'dynamic hologram value-change cache missing')
need('LegacyComponentSerializer' in hm and 'hexColors' in hm,'hologram color parser missing')
need('replace("{crate_keys_<crate_id>}", "{crate_keys_" + id + "}")' in hm,'generic crate placeholder expansion missing')
need('crate-hologram-location' in hm and 'removeAt' in hm,'hologram location marker cleanup missing')
need('cachedPhysicalKeys' in cs and 'physicalKeyCache' in cs,'physical key placeholder cache missing')
need('return crate.isCloudKey()' in cs and 'cachedPhysicalKeys' in cs,'keyCount must use cache and support item keys')
need('meta.setMaxStackSize(1)' in cs,'unstacked key mode missing')
need('refreshPhysicalKeysNow(player)' in cs,'physical key cache refresh missing')
need('plugin.service().keyCount(player, target)' in ps,'placeholders must use unified cached key count')
need('Sound.ENTITY_FISH_SWIM' in el and 'Sound.ENTITY_PLAYER_LEVELUP' in el,'select reward sounds missing')
need('sendTitle' not in el,'select reward title must not be sent')
need('if ((cursor == null || cursor.getType().isAir())' in el,'bottom inventory click can overwrite non-empty cursor')
need('for (int i = crate.rewards().size() - 1; i >= 0; i--) crate.removeReward(i);' in el,'full inventory import should replace all rewards')
need('playerSlot = 9' in el and 'playerSlot = 0' in el,'inventory import main inventory and hotbar mapping missing')
need('InventoryDragEvent' in el and 'importToSlot' in el,'direct drag import missing')
need('Auto Save' in el or 'save(crate)' in el,'auto save implementation missing')
for title in ['§8ZxCrates Editor','§8Crate Preview','§8Open Crate','§8Select Reward','§8Key Settings']:
    need(title in (read('src/main/java/com/zxspeed/zxcrates/gui/CrateEditorMenu.java')+read('src/main/java/com/zxspeed/zxcrates/gui/CratePreviewMenu.java')+am+cl+read('src/main/java/com/zxspeed/zxcrates/gui/KeySettingsMenu.java')),f'title missing: {title}')
need('PREFIX="§8Rewards • "' in read('src/main/java/com/zxspeed/zxcrates/gui/RewardMenu.java'),'Rewards title not prefixed §8')
need('PREFIX="§8Reward Edit • "' in read('src/main/java/com/zxspeed/zxcrates/gui/RewardEditMenu.java'),'Reward Edit title not prefixed §8')
need('case 28 -> new KeySettingsMenu' in el,'Keys editor button missing')
need('case 10 -> {' in read('src/main/java/com/zxspeed/zxcrates/gui/KeySettingsMenu.java') if False else True,'dummy')
ks=read('src/main/java/com/zxspeed/zxcrates/gui/KeySettingsMenu.java')
need('item' in ks and 'cloud' in ks and 'keyDisplayName' in ks and 'keyStacked' in ks,'key settings GUI missing controls')
need('/crate keyall <keyid>' in ka,'direct keyall usage missing')
need('if(section(args[0])!=null)' in ka and 'directGive(crate)' in ka,'KeyAll must support config IDs and direct crate key IDs')
need('interval-minutes' in keyall and 'commands:' in keyall and 'messages:' in keyall,'simple keyall configuration missing')
need('sendTitle' in ka and 'sendMessage' in ka and 'sendActionBar' not in ka and '.playSound' not in ka,'KeyAll messages must stay title/subtitle/chat only')
need('MM:SS' in ka or 'String.format(Locale.ROOT,"%02d:%02d"' in ka,'KeyAll time formatter missing')
need('ZxCrates Editor' in read('src/main/java/com/zxspeed/zxcrates/gui/CrateEditorMenu.java'),'editor title missing')
need('args.length >= 2' in read('src/main/java/com/zxspeed/zxcrates/command/CrateCommand.java'),'editor command arg support missing')
# No Arabic in Java source
arabic=re.compile(r'[\u0600-\u06FF]')
for f in SRC.rglob('*.java'):
    if arabic.search(f.read_text(encoding='utf-8')):
        errors.append(f'Arabic text found in Java: {f.relative_to(ROOT)}')
# GUI title audit: any createInventory string literal must use §8
for f in SRC.rglob('*.java'):
    s=f.read_text(encoding='utf-8')
    for m in re.finditer(r'createInventory\([^\n]*?,\s*[^,]+,\s*([^\n;]+)', s):
        expr=m.group(1)
        if 'PREFIX' not in expr and '"§8' not in expr and 'LEGACY' not in expr:
            errors.append(f'Possible non-§8 GUI title in {f.relative_to(ROOT)}: {expr[:80]}')
# YAML parse
for f in RES.rglob('*.yml'):
    try: yaml.safe_load(f.read_text(encoding='utf-8'))
    except Exception as e: errors.append(f'YAML error {f.relative_to(ROOT)}: {e}')
# crude Java parser balance, ignoring strings/comments
for f in SRC.rglob('*.java'):
    s=f.read_text(encoding='utf-8')
    out=[]; i=0; state='code'; esc=False
    while i<len(s):
        c=s[i]; n=s[i+1] if i+1<len(s) else ''
        if state=='code':
            if c=='/' and n=='/': state='line'; i+=2; continue
            if c=='/' and n=='*': state='block'; i+=2; continue
            if c=='"': state='str'; out.append(' '); i+=1; continue
            if c=="'": state='char'; out.append(' '); i+=1; continue
            out.append(c); i+=1
        elif state=='line':
            if c=='\n': state='code'; out.append('\n')
            else: out.append(' ')
            i+=1
        elif state=='block':
            if c=='*' and n=='/': state='code'; out.append('  '); i+=2
            else: out.append('\n' if c=='\n' else ' '); i+=1
        elif state=='str':
            if esc: esc=False
            elif c=='\\': esc=True
            elif c=='"': state='code'
            out.append(' '); i+=1
        else:
            if esc: esc=False
            elif c=='\\': esc=True
            elif c=="'": state='code'
            out.append(' '); i+=1
    clean=''.join(out)
    if state in ('str','char','block'): errors.append(f'unclosed lexical state {state}: {f.relative_to(ROOT)}')
    pairs={'(':')','[':']','{':'}'}; stack=[]
    for idx,c in enumerate(clean,1):
        if c in pairs: stack.append((c,idx))
        elif c in ')]}':
            if not stack or pairs[stack[-1][0]]!=c: errors.append(f'unbalanced delimiter {c}: {f.relative_to(ROOT)}'); break
            stack.pop()
    if stack: errors.append(f'unclosed delimiters {stack[-5:]}: {f.relative_to(ROOT)}')
if errors:
    print('FAIL')
    for e in errors: print('-',e)
    sys.exit(1)
print('PASS: ZxCrates 1.1.2 static regression')
