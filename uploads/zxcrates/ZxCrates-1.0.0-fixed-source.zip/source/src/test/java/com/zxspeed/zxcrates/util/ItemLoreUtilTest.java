package com.zxspeed.zxcrates.util;

import com.zxspeed.zxcrates.model.Crate;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

final class ItemLoreUtilTest {
    @Test
    void crateLoreDoesNotMutateOriginalRewardItem() {
        Crate crate = new Crate("legend");
        crate.itemLore(List.of("&#FF0000Crate-only", "&7Second line"));

        ItemStack original = new ItemStack(Material.DIAMOND);
        ItemMeta meta = original.getItemMeta();
        meta.lore(List.of(net.kyori.adventure.text.Component.text("Original lore")));
        original.setItemMeta(meta);

        ItemStack preview = ItemLoreUtil.withCrateLore(original, crate);

        assertNotNull(preview);
        assertNotSame(original, preview);
        assertEquals(1, original.getItemMeta().lore().size());
        assertEquals(3, preview.getItemMeta().lore().size());
    }
}
