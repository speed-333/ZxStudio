package com.zxspeed.zxcrates.util;

/**
 * Pure distance policy used by the hologram manager.
 * Squared distance avoids sqrt and keeps the hot-path allocation free.
 */
public final class HologramVisibility {
    private HologramVisibility() {}

    public static boolean isVisible(double dx, double dy, double dz, double viewDistance) {
        if (!Double.isFinite(viewDistance) || viewDistance <= 0.0D) return false;
        if (!Double.isFinite(dx) || !Double.isFinite(dy) || !Double.isFinite(dz)) return false;
        double squaredDistance = dx * dx + dy * dy + dz * dz;
        double squaredRange = viewDistance * viewDistance;
        return squaredDistance <= squaredRange;
    }
}
