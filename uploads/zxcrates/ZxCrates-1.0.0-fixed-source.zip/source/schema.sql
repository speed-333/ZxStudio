-- هذا الملف يطابق migration الأول في MySqlRepository.
CREATE TABLE IF NOT EXISTS crates (
  id VARCHAR(64) PRIMARY KEY,
  display_name VARCHAR(256) NOT NULL,
  type VARCHAR(16) NOT NULL,
  block_material VARCHAR(64) NOT NULL,
  animation VARCHAR(32) NOT NULL,
  config TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS rewards (
  id INT AUTO_INCREMENT PRIMARY KEY,
  crate_id VARCHAR(64) NOT NULL,
  item_json TEXT NULL,
  chance DOUBLE NOT NULL,
  reward_type VARCHAR(32) NOT NULL,
  command_text TEXT NULL,
  amount INT NOT NULL DEFAULT 1,
  position INT NOT NULL,
  INDEX(crate_id)
);

CREATE TABLE IF NOT EXISTS player_keys (
  player_uuid CHAR(36) NOT NULL,
  crate_id VARCHAR(64) NOT NULL,
  amount INT NOT NULL,
  PRIMARY KEY(player_uuid, crate_id)
);

CREATE TABLE IF NOT EXISTS logs (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  player_uuid CHAR(36) NOT NULL,
  crate_id VARCHAR(64) NOT NULL,
  reward_id INT NULL,
  timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX(crate_id),
  INDEX(player_uuid)
);
