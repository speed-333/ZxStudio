package com.zxspeed.zxcrates.service;

import com.zxspeed.zxcrates.ZxCratesPlugin;
import com.zxspeed.zxcrates.model.Crate;
import com.zxspeed.zxcrates.util.HologramVisibility;
import io.papermc.paper.threadedregions.scheduler.ScheduledTask;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Location;
import org.bukkit.Color;
import org.bukkit.World;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.NamespacedKey;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Owns all ZxCrates holograms.
 *
 * Dynamic holograms are keyed by crate location + player UUID and are updated in place.
 * They are never destroyed and recreated just because a player-specific placeholder changed.
 * This prevents duplicate TextDisplay entities when keys, keyall rewards, or other values change.
 */
public final class HologramManager {
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder().character('&').hexColors().build();

    private final ZxCratesPlugin plugin;
    private final NamespacedKey markerKey;
    private final NamespacedKey locationKey;

    private final Map<String, TextDisplay> staticDisplays = new ConcurrentHashMap<>();
    private final Map<String, Location> staticLocations = new ConcurrentHashMap<>();
    private final Map<UUID, Map<Long, Set<String>>> staticChunkIndex = new ConcurrentHashMap<>();
    private final Map<UUID, Set<String>> dynamicKeysByPlayer = new ConcurrentHashMap<>();
    private final Map<UUID, Set<String>> desiredVisible = new ConcurrentHashMap<>();
    private final Map<UUID, Set<String>> appliedVisible = new ConcurrentHashMap<>();
    private final Set<UUID> visibilityApplyScheduled = ConcurrentHashMap.newKeySet();
    private final Map<UUID, Player> onlinePlayers = new ConcurrentHashMap<>();
    private final Map<UUID, Integer> worldMaxStaticChunkRadius = new ConcurrentHashMap<>();
    private final Map<String, TextDisplay> dynamicDisplays = new ConcurrentHashMap<>();
    private final Map<String, Location> dynamicLocations = new ConcurrentHashMap<>();
    private final Map<String, String> lastRendered = new ConcurrentHashMap<>();

    /** Prevents multiple queued region tasks from creating the same dynamic display. */
    private final Set<String> pendingDynamic = ConcurrentHashMap.newKeySet();

    private final ScheduledTask ticker;

    public HologramManager(ZxCratesPlugin plugin) {
        this.plugin = plugin;
        this.markerKey = new NamespacedKey(plugin, "crate-hologram");
        this.locationKey = new NamespacedKey(plugin, "crate-hologram-location");
        for (Player player : plugin.getServer().getOnlinePlayers()) onlinePlayers.put(player.getUniqueId(), player);
        this.ticker = plugin.getServer().getGlobalRegionScheduler().runAtFixedRate(plugin, task -> updateDynamicDisplays(), 10L, 10L);
    }

    public void refreshAll(Collection<Crate> crates) {
        if (crates != null) for (Crate crate : crates) refresh(crate);
    }

    /**
     * Rebuilds a single crate hologram set. This method is intended for structural/configuration
     * changes, not for normal placeholder value changes.
     */
    public void refresh(Crate crate) {
        if (crate == null) return;
        remove(crate);
        if (!crate.hologramEnabled()) return;

        for (String raw : crate.locations()) {
            Location location = parseLocation(raw);
            if (location == null || location.getWorld() == null) continue;

            if (plugin.placeholders().isPlayerSpecific(crate.hologramText())) {
                for (Player player : onlinePlayers.values()) {
                    if (player.getWorld() == location.getWorld()) ensureDynamic(crate, location, player);
                }
            } else {
                plugin.getServer().getRegionScheduler().run(plugin, location, task -> spawnStatic(crate, location));
            }
        }
    }

    /**
     * Refreshes a player's dynamic holograms without deleting/recreating them.
     * Existing TextDisplays are reused and the ticker updates their text in place.
     */
    public void refreshPlayer(Player player) {
        if (player == null || !player.isOnline()) return;
        onlinePlayers.put(player.getUniqueId(), player);
        UUID playerId = player.getUniqueId();

        for (Map.Entry<String, TextDisplay> entry : dynamicDisplays.entrySet()) {
            String key = entry.getKey();
            if (!key.endsWith("#" + playerId)) continue;
            TextDisplay display = entry.getValue();
            if (display == null || !display.isValid() || display.getWorld() != player.getWorld()) {
                removeDynamicEntry(key, display);
            }
        }

        for (Crate crate : plugin.service().all()) {
            if (!crate.hologramEnabled() || !plugin.placeholders().isPlayerSpecific(crate.hologramText())) continue;
            for (String raw : crate.locations()) {
                Location location = parseLocation(raw);
                if (location != null && location.getWorld() == player.getWorld()) ensureDynamic(crate, location, player);
            }
        }
        syncPlayerVisibility(player);
    }

    public void removePlayer(Player player) {
        if (player != null) {
            UUID id = player.getUniqueId();
            onlinePlayers.remove(id, player);
            clearPlayerVisibility(player);
            removeDynamicForPlayer(id);
        }
    }

    /**
     * Called from the player's region thread. Visibility is event-driven instead of globally
     * scanning every hologram against every online player, which is especially important on Folia.
     */
    public void onPlayerMove(Player player) {
        if (player == null || !player.isOnline()) return;
        onlinePlayers.put(player.getUniqueId(), player);
        Location current = player.getLocation();
        syncPlayerVisibility(player);
    }

    /** Forces a visibility refresh for all currently online players without touching entity state
     * from the global scheduler. Each check runs on the player's own Folia region scheduler. */
    public void refreshPlayerVisibilities() {
        for (Player player : onlinePlayers.values()) {
            if (player != null && player.isOnline()) {
                player.getScheduler().run(plugin, task -> syncPlayerVisibility(player), null);
            }
        }
    }

    public void refreshBackground(Crate crate) {
        if (crate == null) return;
        refresh(crate);
    }

    public void remove(Crate crate) {
        if (crate == null) return;
        String prefix = crate.id().toLowerCase(Locale.ROOT) + "@";

        staticDisplays.keySet().removeIf(key -> removeByPrefix(staticDisplays, prefix, key));
        dynamicDisplays.keySet().removeIf(key -> removeByPrefix(dynamicDisplays, prefix, key));
        lastRendered.keySet().removeIf(key -> key.startsWith(prefix));
        pendingDynamic.removeIf(key -> key.startsWith(prefix));
        dynamicLocations.keySet().removeIf(key -> key.startsWith(prefix));
        dynamicKeysByPlayer.values().forEach(set -> set.removeIf(key -> key.startsWith(prefix)));
        removeDesiredVisibilityByPrefix(prefix);
        appliedVisible.values().forEach(set -> set.removeIf(key -> key.startsWith(prefix)));
    }

    public void removeAt(Crate crate, Location location) {
        if (crate == null || location == null || location.getWorld() == null) return;
        String prefix = key(crate, location);

        TextDisplay staticDisplay = staticDisplays.remove(prefix);
        Location staticLocation = staticLocations.remove(prefix);
        if (staticLocation != null) removeStaticIndex(prefix, staticLocation);
        removeEntity(staticDisplay);

        dynamicDisplays.keySet().removeIf(dynamicKey -> {
            if (!dynamicKey.startsWith(prefix + "#")) return false;
            TextDisplay display = dynamicDisplays.remove(dynamicKey);
            removeEntity(display);
            return true;
        });

        lastRendered.keySet().removeIf(renderKey -> renderKey.startsWith(prefix));
        pendingDynamic.removeIf(pendingKey -> pendingKey.startsWith(prefix));
        dynamicLocations.keySet().removeIf(dynamicKey -> dynamicKey.startsWith(prefix + "#"));
        dynamicKeysByPlayer.values().forEach(set -> set.removeIf(key -> key.startsWith(prefix + "#")));
        removeDesiredVisibilityByPrefix(prefix);
        appliedVisible.values().forEach(set -> set.removeIf(key -> key.equals(prefix) || key.startsWith(prefix + "#")));
        removeMarkedAt(location, crate.id());
    }

    private void removeMarkedAt(Location location, String crateId) {
        World world = location.getWorld();
        if (world == null) return;
        Location center = location.clone().add(.5D, 1.5D, .5D);
        for (Entity entity : world.getNearbyEntities(center, 2.5D, 3.5D, 2.5D)) {
            if (!(entity instanceof TextDisplay display)) continue;
            String id = display.getPersistentDataContainer().get(markerKey, PersistentDataType.STRING);
            String at = display.getPersistentDataContainer().get(locationKey, PersistentDataType.STRING);
            if (crateId.equalsIgnoreCase(id) && Crate.locationKey(location).equals(at)) display.remove();
        }
    }

    public void onDisable() {
        if (ticker != null) ticker.cancel();
        staticDisplays.values().forEach(this::removeEntity);
        dynamicDisplays.values().forEach(this::removeEntity);
        staticDisplays.clear();
        staticLocations.clear();
        staticChunkIndex.clear();
        onlinePlayers.clear();
        dynamicDisplays.clear();
        dynamicLocations.clear();
        dynamicKeysByPlayer.clear();
        desiredVisible.clear();
        appliedVisible.clear();
        visibilityApplyScheduled.clear();
        worldMaxStaticChunkRadius.clear();
        lastRendered.clear();
        pendingDynamic.clear();
    }

    private boolean removeByPrefix(Map<String, TextDisplay> map, String prefix, String key) {
        if (!key.startsWith(prefix)) return false;
        TextDisplay display = map.remove(key);
        if (map == staticDisplays) {
            Location location = staticLocations.remove(key);
            if (location != null) removeStaticIndex(key, location);
        }
        removeEntity(display);
        return true;
    }

    private void updateDynamicDisplays() {
        if (dynamicDisplays.isEmpty()) return;

        for (Map.Entry<String, TextDisplay> entry : dynamicDisplays.entrySet()) {
            String key = entry.getKey();
            TextDisplay display = entry.getValue();

            if (display == null || !display.isValid()) {
                dynamicDisplays.remove(key, display);
                lastRendered.remove(key);
                continue;
            }

            int hash = key.lastIndexOf('#');
            int at = key.indexOf('@');
            if (hash <= 0 || at <= 0 || at > hash) continue;

            String crateId = key.substring(0, at);
            UUID playerId;
            try {
                playerId = UUID.fromString(key.substring(hash + 1));
            } catch (IllegalArgumentException ex) {
                removeDynamicEntry(key, display);
                continue;
            }

            Player player = onlinePlayers.get(playerId);
            Crate crate = plugin.service().get(crateId).orElse(null);
            if (player == null || !player.isOnline() || crate == null || !crate.hologramEnabled()) {
                removeDynamicEntry(key, display);
                continue;
            }

            String rendered = render(player, crate);
            if (rendered.equals(lastRendered.get(key))) continue;

            lastRendered.put(key, rendered);
            Component component = parseText(rendered);
            display.getScheduler().run(plugin, task -> {
                if (display.isValid()) display.text(component);
            }, null);
        }
    }

    private String render(Player player, Crate crate) {
        String text = crate.hologramText();
        String id = crate.id();
        text = text.replace("{crate_id}", id)
                .replace("{crate_keys_<crate_id>}", "{crate_keys_" + id + "}")
                .replace("{crate_keys_cloud_<crate_id>}", "{crate_keys_cloud_" + id + "}")
                .replace("{crate_name_<crate_id>}", "{crate_name_" + id + "}")
                .replace("{crate_type_<crate_id>}", "{crate_type_" + id + "}")
                .replace("%zxcrates_crate_keys_<crate_id>%", "%zxcrates_crate_keys_" + id + "%")
                .replace("%zxcrates_crate_keys_crateid%", "%zxcrates_crate_keys_" + id + "%")
                .replace("%zxcrates_crate_keys_cloud_<crate_id>%", "%zxcrates_crate_keys_cloud_" + id + "%");
        return plugin.placeholders().parse(player, text, crate).replace("\\n", "\n");
    }

    private void spawnStatic(Crate crate, Location base) {
        if (!crate.isAt(base) || !crate.hologramEnabled()) return;
        String key = key(crate, base);
        TextDisplay existing = staticDisplays.get(key);
        if (existing != null && existing.isValid()) return;

        TextDisplay display = createDisplay(crate, base);
        String rendered = render(null, crate);
        display.text(parseText(rendered));
        staticDisplays.put(key, display);
        staticLocations.put(key, display.getLocation().clone());
        addStaticIndex(key, display.getLocation());
        lastRendered.put(key, rendered);
        refreshPlayerVisibilities();
    }

    /**
     * Queues at most one creation task per dynamic key. Existing displays are reused.
     */
    private void ensureDynamic(Crate crate, Location base, Player target) {
        if (target == null || !target.isOnline() || base.getWorld() == null || target.getWorld() != base.getWorld()) return;

        String dynamicKey = key(crate, base) + "#" + target.getUniqueId();
        TextDisplay current = dynamicDisplays.get(dynamicKey);
        if (current != null && current.isValid()) return;

        if (!pendingDynamic.add(dynamicKey)) return;

        plugin.getServer().getRegionScheduler().run(plugin, base, task -> {
            try {
                if (!crate.isAt(base) || !crate.hologramEnabled() || !target.isOnline() || target.getWorld() != base.getWorld()) return;

                TextDisplay alreadyCreated = dynamicDisplays.get(dynamicKey);
                if (alreadyCreated != null && alreadyCreated.isValid()) return;

                TextDisplay display = createDisplay(crate, base);
                String rendered = render(target, crate);
                display.text(parseText(rendered));
                dynamicDisplays.put(dynamicKey, display);
                dynamicLocations.put(dynamicKey, display.getLocation().clone());
                dynamicKeysByPlayer.computeIfAbsent(target.getUniqueId(), ignored -> ConcurrentHashMap.newKeySet()).add(dynamicKey);
                lastRendered.put(dynamicKey, rendered);
                target.getScheduler().run(plugin, ignored -> syncPlayerVisibility(target), null);
                // Visibility is event-driven and uses the crate's exact configured range.
                // Do not show dynamic holograms unconditionally here.
            } finally {
                pendingDynamic.remove(dynamicKey);
            }
        });
    }

    private Component parseText(String text) {
        return text == null ? Component.empty() : LEGACY.deserialize(text.replace('§', '&')).decoration(net.kyori.adventure.text.format.TextDecoration.ITALIC, false);
    }

    private TextDisplay createDisplay(Crate crate, Location base) {
        TextDisplay display = (TextDisplay) base.getWorld().spawnEntity(
                base.clone().add(.5D, crate.hologramOffsetY(), .5D),
                org.bukkit.entity.EntityType.TEXT_DISPLAY
        );
        display.setBillboard(Display.Billboard.CENTER);
        display.setAlignment(TextDisplay.TextAlignment.CENTER);
        display.setShadowed(true);
        display.setSeeThrough(false);
        // Explicitly clear the custom background as well as the default flag. This prevents
        // resource packs/client settings from leaving a faint TextDisplay background behind.
        display.setDefaultBackground(crate.hologramBackground());
        display.setBackgroundColor(crate.hologramBackground() ? null : Color.fromARGB(0, 0, 0, 0));
        display.setViewRange((float) crate.hologramViewDistance());
        display.setPersistent(false);
        // Start hidden and explicitly show only players inside the crate's configured range.
        display.setVisibleByDefault(false);
        display.getPersistentDataContainer().set(markerKey, PersistentDataType.STRING, crate.id());
        display.getPersistentDataContainer().set(locationKey, PersistentDataType.STRING, Crate.locationKey(base));
        return display;
    }

    private void syncPlayerVisibility(Player player) {
        if (player == null || !player.isOnline()) return;
        UUID playerId = player.getUniqueId();
        Location playerLocation = player.getLocation();
        UUID worldId = playerLocation.getWorld() == null ? null : playerLocation.getWorld().getUID();
        Set<String> desired = new HashSet<>();

        if (worldId != null) {
            int centerChunkX = playerLocation.getBlockX() >> 4;
            int centerChunkZ = playerLocation.getBlockZ() >> 4;
            int chunkRadius = Math.max(0, worldMaxStaticChunkRadius.getOrDefault(worldId, 0));
            Map<Long, Set<String>> worldIndex = staticChunkIndex.get(worldId);
            if (worldIndex != null) {
                for (int dx = -chunkRadius; dx <= chunkRadius; dx++) {
                    for (int dz = -chunkRadius; dz <= chunkRadius; dz++) {
                        Set<String> keys = worldIndex.get(chunkKey(centerChunkX + dx, centerChunkZ + dz));
                        if (keys != null) desired.addAll(keys);
                    }
                }
            }
        }

        // Narrow the static candidates with the exact squared-distance check.
        desired.removeIf(key -> !isWithinStaticRange(playerLocation, key));

        // Dynamic holograms are indexed per player, so this is O(the player's own dynamic displays),
        // not O(all dynamic displays on the server).
        Set<String> dynamicKeys = dynamicKeysByPlayer.get(playerId);
        if (dynamicKeys != null) {
            for (String key : dynamicKeys) {
                TextDisplay display = dynamicDisplays.get(key);
                Crate crate = crateFromKey(key);
                Location dynamicLocation = dynamicLocations.get(key);
                if (display != null && display.isValid() && crate != null
                        && dynamicLocation != null
                        && dynamicLocation.getWorld() == playerLocation.getWorld()
                        && isWithinRange(playerLocation, dynamicLocation, crate.hologramViewDistance())) {
                    desired.add(key);
                }
            }
        }

        desiredVisible.put(playerId, Set.copyOf(desired));
        scheduleVisibilityApply(player);
    }

    private void scheduleVisibilityApply(Player player) {
        UUID playerId = player.getUniqueId();
        if (!visibilityApplyScheduled.add(playerId)) return;
        player.getScheduler().run(plugin, task -> {
            visibilityApplyScheduled.remove(playerId);
            if (!player.isOnline()) {
                desiredVisible.remove(playerId);
                appliedVisible.remove(playerId);
                return;
            }

            Set<String> desired = desiredVisible.getOrDefault(playerId, Set.of());
            Set<String> applied = appliedVisible.computeIfAbsent(playerId, ignored -> ConcurrentHashMap.newKeySet());

            for (String key : Set.copyOf(applied)) {
                if (desired.contains(key)) continue;
                TextDisplay display = displayForKey(key);
                applied.remove(key);
                if (display != null && display.isValid()) player.hideEntity(plugin, display);
            }
            for (String key : desired) {
                if (applied.contains(key)) continue;
                TextDisplay display = displayForKey(key);
                if (display == null || !display.isValid()) continue;
                applied.add(key);
                player.showEntity(plugin, display);
            }

            // If another movement changed the desired set while this task was queued, reconcile once
            // more without creating a task storm.
            if (!Objects.equals(desired, desiredVisible.getOrDefault(playerId, Set.of()))) {
                scheduleVisibilityApply(player);
            }
        }, null);
    }

    private TextDisplay displayForKey(String key) {
        TextDisplay staticDisplay = staticDisplays.get(key);
        return staticDisplay != null ? staticDisplay : dynamicDisplays.get(key);
    }

    private boolean isWithinStaticRange(Location playerLocation, String key) {
        Location hologram = staticLocations.get(key);
        Crate crate = crateFromKey(key);
        return hologram != null && crate != null && crate.hologramViewDistance() > 0.0D
                && isWithinRange(playerLocation, hologram, crate.hologramViewDistance());
    }

    private void clearPlayerVisibility(Player player) {
        if (player == null) return;
        UUID id = player.getUniqueId();
        desiredVisible.remove(id);
        Set<String> applied = appliedVisible.remove(id);
        visibilityApplyScheduled.remove(id);
        if (applied != null) {
            for (String key : applied) {
                TextDisplay display = displayForKey(key);
                if (display != null && display.isValid()) hide(player, display);
            }
        }
    }

    private void addStaticIndex(String key, Location location) {
        if (location == null || location.getWorld() == null) return;
        staticLocations.put(key, location.clone());
        UUID worldId = location.getWorld().getUID();
        staticChunkIndex.computeIfAbsent(worldId, ignored -> new ConcurrentHashMap<>())
                .computeIfAbsent(chunkKey(location.getBlockX() >> 4, location.getBlockZ() >> 4), ignored -> ConcurrentHashMap.newKeySet())
                .add(key);
        Crate crate = crateFromKey(key);
        if (crate != null) {
            int radius = (int) Math.ceil(crate.hologramViewDistance() / 16.0D);
            worldMaxStaticChunkRadius.merge(worldId, radius, Math::max);
        }
    }

    private void removeStaticIndex(String key, Location location) {
        if (location == null || location.getWorld() == null) return;
        UUID worldId = location.getWorld().getUID();
        Map<Long, Set<String>> worldIndex = staticChunkIndex.get(worldId);
        if (worldIndex == null) return;
        long chunkKey = chunkKey(location.getBlockX() >> 4, location.getBlockZ() >> 4);
        Set<String> keys = worldIndex.get(chunkKey);
        if (keys != null) {
            keys.remove(key);
            if (keys.isEmpty()) worldIndex.remove(chunkKey, keys);
        }
        if (worldIndex.isEmpty()) staticChunkIndex.remove(worldId, worldIndex);
        recomputeWorldMaxStaticChunkRadius(worldId);
    }

    private void recomputeWorldMaxStaticChunkRadius(UUID worldId) {
        int max = 0;
        Map<Long, Set<String>> worldIndex = staticChunkIndex.get(worldId);
        if (worldIndex != null) {
            for (Set<String> keys : worldIndex.values()) {
                for (String key : keys) {
                    Crate crate = crateFromKey(key);
                    if (crate != null) {
                        int radius = (int) Math.ceil(crate.hologramViewDistance() / 16.0D);
                        max = Math.max(max, radius);
                    }
                }
            }
        }
        if (max == 0) worldMaxStaticChunkRadius.remove(worldId);
        else worldMaxStaticChunkRadius.put(worldId, max);
    }

    private long chunkKey(int x, int z) {
        return ((long) x << 32) ^ (z & 0xffffffffL);
    }

    private void show(Player player, TextDisplay display) {
        player.getScheduler().run(plugin, task -> {
            if (player.isOnline() && display.isValid()) player.showEntity(plugin, display);
        }, null);
    }

    private void hide(Player player, TextDisplay display) {
        player.getScheduler().run(plugin, task -> {
            if (player.isOnline() && display.isValid()) player.hideEntity(plugin, display);
        }, null);
    }

    private Crate crateFromKey(String key) {
        int at = key.indexOf('@');
        if (at <= 0) return null;
        return plugin.service().get(key.substring(0, at)).orElse(null);
    }

    private void removeDesiredVisibilityByPrefix(String prefix) {
        desiredVisible.replaceAll((id, set) -> {
            Set<String> filtered = new HashSet<>(set);
            filtered.removeIf(key -> key.startsWith(prefix));
            return Set.copyOf(filtered);
        });
    }

    private void removeDesiredVisibilityKey(String keyToRemove) {
        desiredVisible.replaceAll((id, set) -> {
            Set<String> filtered = new HashSet<>(set);
            filtered.remove(keyToRemove);
            return Set.copyOf(filtered);
        });
    }

    private void removeDesiredVisibilityKeyForPlayer(UUID playerId, String keyToRemove) {
        desiredVisible.computeIfPresent(playerId, (id, set) -> {
            Set<String> filtered = new HashSet<>(set);
            filtered.remove(keyToRemove);
            return Set.copyOf(filtered);
        });
    }

    private void removeDynamicEntry(String key, TextDisplay display) {
        dynamicDisplays.remove(key, display);
        lastRendered.remove(key);
        dynamicKeysByPlayer.values().forEach(set -> set.remove(key));
        removeDesiredVisibilityKey(key);
        appliedVisible.values().forEach(set -> set.remove(key));
        pendingDynamic.remove(key);
        dynamicLocations.remove(key);
        removeEntity(display);
    }

    private void removeDynamicForPlayer(UUID playerId) {
        String suffix = "#" + playerId;
        dynamicDisplays.keySet().removeIf(key -> {
            if (!key.endsWith(suffix)) return false;
            TextDisplay display = dynamicDisplays.remove(key);
            lastRendered.remove(key);
            pendingDynamic.remove(key);
            dynamicLocations.remove(key);
            Set<String> playerDynamicKeys = dynamicKeysByPlayer.get(playerId);
            if (playerDynamicKeys != null) {
                playerDynamicKeys.remove(key);
                if (playerDynamicKeys.isEmpty()) dynamicKeysByPlayer.remove(playerId, playerDynamicKeys);
            }
            removeDesiredVisibilityKeyForPlayer(playerId, key);
            Set<String> playerAppliedVisible = appliedVisible.get(playerId);
            if (playerAppliedVisible != null) {
                playerAppliedVisible.remove(key);
                if (playerAppliedVisible.isEmpty()) appliedVisible.remove(playerId, playerAppliedVisible);
            }
            removeEntity(display);
            return true;
        });
        pendingDynamic.removeIf(key -> key.endsWith(suffix));
    }

    private void removeEntity(TextDisplay display) {
        if (display != null && display.isValid()) display.getScheduler().run(plugin, task -> {
            if (display.isValid()) display.remove();
        }, null);
    }

    private String key(Crate crate, Location location) {
        return crate.id().toLowerCase(Locale.ROOT) + "@" + Crate.locationKey(location);
    }

    private Location parseLocation(String raw) {
        if (raw == null || raw.isBlank()) return null;
        String[] parts = raw.split(":", 4);
        if (parts.length != 4) return null;
        World world = plugin.getServer().getWorld(parts[0]);
        if (world == null) return null;
        try {
            return new Location(world, Integer.parseInt(parts[1]), Integer.parseInt(parts[2]), Integer.parseInt(parts[3]));
        } catch (NumberFormatException ex) {
            return null;
        }
    }
}
