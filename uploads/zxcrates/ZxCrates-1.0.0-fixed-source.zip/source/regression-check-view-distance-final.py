from pathlib import Path
import re, zipfile
ROOT=Path(__file__).parent
cmd=(ROOT/'src/main/java/com/zxspeed/zxcrates/command/CrateCommand.java').read_text()
holo=(ROOT/'src/main/java/com/zxspeed/zxcrates/service/HologramManager.java').read_text()
listener=(ROOT/'src/main/java/com/zxspeed/zxcrates/listener/CrateListener.java').read_text()
plugin=(ROOT/'src/main/resources/plugin.yml').read_text()
README=(ROOT/'README.md').read_text()
checks=[]
def ok(n,c): checks.append((n,bool(c)))
ok('old top-level command removed', 'handleViewDistance(' not in cmd and 'case "view_distance", "view-distance" ->' not in cmd.split('case "hologram" ->',1)[0])
ok('old top-level usage removed', '/crates view_distance <crateid> <value>' not in cmd)
ok('new nested command exists', '/crate hologram <crateid> view_distance <crateid> <value>' in cmd)
ok('duplicate crate id validated', 'args[3].equalsIgnoreCase(crate.id())' in cmd)
ok('fractional distance accepted', 'Double.parseDouble(args[4])' in cmd)
ok('range validation 0..128', 'value < 0.0D || value > 128.0D' in cmd)
ok('immediate hologram refresh after change', 'plugin.holograms().refresh(crate);' in cmd and 'refreshPlayerVisibilities' in cmd)
ok('exact visibility still squared distance', 'squaredDistance <= squaredRange' in (ROOT/'src/main/java/com/zxspeed/zxcrates/util/HologramVisibility.java').read_text())
ok('coalesced desired visibility map', 'desiredVisible' in holo and 'visibilityApplyScheduled' in holo)
ok('per-player applied visibility', 'appliedVisible' in holo)
ok('per-player dynamic index', 'dynamicKeysByPlayer' in holo)
ok('per-world chunk radius index', 'worldMaxStaticChunkRadius' in holo)
ok('no 289 chunk hard scan', 'int chunkRadius = 8' not in holo)
ok('player scheduler used for apply', 'player.getScheduler().run' in holo)
ok('move event remains', 'onPlayerMove(Player player)' in holo and 'hologramMove(PlayerMoveEvent event)' in listener)
ok('no all-online scan in hot path', 'Bukkit.getOnlinePlayers()' not in holo)
ok('old command absent from README', '/crate view_distance <crateid> <value>' not in README)
ok('plugin folia support', 'folia-supported: true' in plugin)
# Simulate repeated enter/exit transitions and coalescing semantics.
def wanted(distance, rng): return 0 < rng and distance*distance <= rng*rng
for i in range(1000):
    rng=32.0
    assert wanted(31.99,rng) and not wanted(32.01,rng)
ok('1000 exact boundary samples', True)
# Syntax balance for modified Java
for f in [ROOT/'src/main/java/com/zxspeed/zxcrates/service/HologramManager.java', ROOT/'src/main/java/com/zxspeed/zxcrates/command/CrateCommand.java']:
    s=f.read_text()
    # lightweight string/comment stripper
    out=[]; i=0; state='c'
    while i<len(s):
        if state=='c':
            if s.startswith('//',i): state='l'; out.extend('  '); i+=2; continue
            if s.startswith('/*',i): state='b'; out.extend('  '); i+=2; continue
            if s[i]=='"': state='s'; out.append(' '); i+=1; continue
            if s[i]=="'": state='q'; out.append(' '); i+=1; continue
            out.append(s[i]); i+=1
        elif state=='l':
            if s[i]=='\n': state='c'; out.append('\n')
            else: out.append(' ')
            i+=1
        elif state=='b':
            if s.startswith('*/',i): state='c'; out.extend('  '); i+=2
            else: out.append('\n' if s[i]=='\n' else ' '); i+=1
        else:
            q='"' if state=='s' else "'"
            if s[i]=='\\': out.extend('  '); i+=2
            elif s[i]==q: state='c'; out.append(' '); i+=1
            else: out.append('\n' if s[i]=='\n' else ' '); i+=1
    ok(f'{f.name} balanced braces', out.count('{')==out.count('}'))
ok('immutable desired state is never mutated directly', 'desiredVisible.getOrDefault(playerId, Set.of()).remove' not in holo and 'desiredVisible.values().forEach(set -> set.remove' not in holo)
ok('dead visibility maps removed', 'playerVisibleStatic' not in holo and 'lastVisibilityCheck' not in holo and 'visiblePlayers' not in holo)
for n,p in checks: print(('PASS' if p else 'FAIL')+' - '+n)
fails=[n for n,p in checks if not p]
print(f'CHECKS={len(checks)} FAILURES={len(fails)}')
if fails: raise SystemExit(1)

ok('immutable desired state is never mutated directly', 'desiredVisible.getOrDefault(playerId, Set.of()).remove' not in holo and 'desiredVisible.values().forEach(set -> set.remove' not in holo)
ok('dead visibility maps removed', 'playerVisibleStatic' not in holo and 'lastVisibilityCheck' not in holo and 'visiblePlayers' not in holo)
