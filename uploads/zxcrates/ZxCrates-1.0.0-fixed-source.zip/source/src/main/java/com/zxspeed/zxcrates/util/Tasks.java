package com.zxspeed.zxcrates.util;

import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

public final class Tasks {
    private Tasks() {}
    public static Executor ioExecutor() { return CompletableFuture.delayedExecutor(0, java.util.concurrent.TimeUnit.MILLISECONDS); }
    public static void player(Player player, Plugin plugin, Runnable run) {
        player.getScheduler().run(plugin, task -> run.run(), null);
    }
    public static void entity(Entity entity, Plugin plugin, Runnable run) {
        entity.getScheduler().run(plugin, task -> run.run(), null);
    }
    public static void global(Plugin plugin, Runnable run) { plugin.getServer().getGlobalRegionScheduler().execute(plugin, run); }
}
