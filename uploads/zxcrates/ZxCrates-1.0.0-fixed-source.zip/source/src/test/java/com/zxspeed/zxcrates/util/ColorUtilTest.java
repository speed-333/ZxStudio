package com.zxspeed.zxcrates.util;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ColorUtilTest {
    @Test void translatesHex() {
        assertEquals("§x§F§F§0§0§0§0Red", ColorUtil.colorize("&#FF0000Red"));
    }
    @Test void translatesLegacy() {
        assertEquals("§fWhite §7Gray §eYellow", ColorUtil.colorize("&fWhite &7Gray &eYellow"));
    }
    @Test void translatesMixed() {
        assertEquals("§x§C§6§0§0§F§FHex §fLegacy", ColorUtil.colorize("&#C600FFHex &fLegacy"));
    }
}
