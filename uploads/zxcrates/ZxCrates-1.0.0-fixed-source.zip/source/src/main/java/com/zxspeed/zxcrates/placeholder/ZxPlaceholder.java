package com.zxspeed.zxcrates.placeholder;

import com.zxspeed.zxcrates.ZxCratesPlugin;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.entity.Player;

public final class ZxPlaceholder extends PlaceholderExpansion {
    private final ZxCratesPlugin plugin;
    private final PlaceholderService service;

    public ZxPlaceholder(ZxCratesPlugin plugin) {
        this.plugin = plugin;
        this.service = new PlaceholderService(plugin);
    }

    @Override public String getIdentifier() { return "zxcrates"; }
    @Override public String getAuthor() { return "zSpeeDx"; }
    @Override public String getVersion() { return plugin.getDescription().getVersion(); }
    @Override public boolean persist() { return true; }
    @Override public boolean canRegister() { return true; }

    @Override
    public String onPlaceholderRequest(Player player, String params) {
        if (params == null || params.isBlank()) return "";
        String value = service.resolve(player, params, null);
        return value == null ? "" : value;
    }
}
