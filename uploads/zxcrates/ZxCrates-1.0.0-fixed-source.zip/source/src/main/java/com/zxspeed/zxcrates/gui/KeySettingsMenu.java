package com.zxspeed.zxcrates.gui;

import com.zxspeed.zxcrates.ZxCratesPlugin;
import com.zxspeed.zxcrates.model.Crate;
import com.zxspeed.zxcrates.util.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

public final class KeySettingsMenu {
    private static final java.util.Map<org.bukkit.inventory.Inventory, Crate> OPEN = java.util.Collections.synchronizedMap(new java.util.WeakHashMap<>());
    public static final String PREFIX="§8Key Settings";
    private final ZxCratesPlugin plugin; private final Player player; private final Crate crate;
    public KeySettingsMenu(ZxCratesPlugin plugin,Player player,Crate crate){this.plugin=plugin;this.player=player;this.crate=crate;}
    public void open(){
        Inventory inv=Bukkit.createInventory(null,54,PREFIX);
        inv.setItem(10,GuiItems.item(crate.isItemKey()?Material.TRIPWIRE_HOOK:Material.ENDER_CHEST, "&bKey Type", "&7Current: &f"+crate.keyDelivery(), "&eClick to switch item/cloud"));
        inv.setItem(12,GuiItems.item(Material.NAME_TAG,"&bKey Name","&7Current: &f"+crate.keyDisplayName(),"&eClick to edit in chat"));
        inv.setItem(14,crate.keyItem()==null?GuiItems.item(Material.BARRIER,"&bKey Item","&7Current: &fNone","&eHold the desired item and click this button") : crate.keyItem());
        inv.setItem(16,GuiItems.item(crate.keyStacked()?Material.CHEST:Material.HOPPER,"&bStacking","&7Current: &f"+(crate.keyStacked()?"stacked":"separate"),"&eClick to toggle"));
        inv.setItem(28,GuiItems.item(Material.PAPER,"&fAuto Save","&7All changes save automatically."));
        inv.setItem(49,GuiItems.item(Material.ARROW,"&eBack","&7Return to editor"));
        OPEN.put(inv,crate);
        player.openInventory(inv);
    }
    public static boolean isTitle(String title){return PREFIX.equals(title);}
    public static Crate crateFor(Inventory inv){return OPEN.get(inv);}
    public Crate crate(){return crate;}
}
