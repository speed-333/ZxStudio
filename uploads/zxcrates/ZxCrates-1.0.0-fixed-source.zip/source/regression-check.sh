#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
python3 regression-check-view-distance-final.py
echo "ZxCrates 1.0.0 view-distance regression check complete"
