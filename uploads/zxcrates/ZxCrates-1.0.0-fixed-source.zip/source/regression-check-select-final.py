from pathlib import Path
import re
src=Path('src/main/java/com/zxspeed/zxcrates/gui/EditorListener.java').read_text()
crate_listener=Path('src/main/java/com/zxspeed/zxcrates/listener/CrateListener.java').read_text()
checks=[]
def ok(name, cond):
    checks.append((name, bool(cond)))

ok('select GUI only', 'SELECT_TITLE.equals(title)' in src)
ok('selected reward tracks UUID', 'ConcurrentHashMap<>()' in src)
ok('confirming is thread-safe', 'ConcurrentHashMap.newKeySet()' in src)
ok('selected reward is replaced by lime pane', 'Material.LIME_STAINED_GLASS_PANE' in src)
ok('confirm button remains lime dye', 'GuiItems.item(Material.LIME_DYE' in src)
ok('confirm grants chosen reward', 'giveSelectedReward(player, crate, reward);' in src)
ok('confirm consumes one key', 'plugin.service().takeKey(player, crate)' in src)
ok('duplicate confirmation blocked', 'if (confirming.contains(player.getUniqueId())) return;' in src)
ok('previous selection restored', 'selectionIcon(player, crate, previous)' in src)
ok('selected pane is not mistaken for reward', 'getPersistentDataContainer().get(new NamespacedKey(plugin, "select-reward-id")' in src)
ok('random crate path unchanged', 'if(crate.type()==CrateType.SELECT){openSelection(player,crate);return;}' in crate_listener)
# exact requested material behavior
m=re.search(r'event\.getView\(\)\.getTopInventory\(\)\.setItem\(raw, GuiItems\.item\(\s*Material\.LIME_STAINED_GLASS_PANE', src)
ok('pane placed in exact clicked slot', m is not None)
for name,good in checks:
    print(('PASS' if good else 'FAIL')+' - '+name)
print(f'CHECKS={len(checks)} FAILURES={sum(not x for _,x in checks)}')
raise SystemExit(1 if any(not x for _,x in checks) else 0)
