package com.zxspeed.zxcrates.gui;

import com.zxspeed.zxcrates.ZxCratesPlugin;
import com.zxspeed.zxcrates.model.Crate;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import java.util.*;

public final class CrateMenu {
    public static final String PREFIX="§8ZxCrates Crates • "; private static final int PAGE_SIZE=45;
    private final ZxCratesPlugin plugin;private final Player player;private final int page;
    public CrateMenu(ZxCratesPlugin plugin,Player player){this(plugin,player,0);} public CrateMenu(ZxCratesPlugin plugin,Player player,int page){this.plugin=plugin;this.player=player;this.page=Math.max(0,page);}
    public void open(){
        List<Crate> crates=new ArrayList<>(plugin.service().all());crates.sort(Comparator.comparing(Crate::id,String.CASE_INSENSITIVE_ORDER));int pages=Math.max(1,(int)Math.ceil(crates.size()/(double)PAGE_SIZE));int current=Math.min(page,pages-1);Inventory inv=Bukkit.createInventory(null,54,PREFIX+(current+1));
        NamespacedKey key=new NamespacedKey(plugin,"crate-id");for(int index=current*PAGE_SIZE,slot=0;index<crates.size()&&slot<PAGE_SIZE;index++,slot++){Crate crate=crates.get(index);ItemStack icon=GuiItems.item(crate.blockMaterial()==null?Material.CHEST:crate.blockMaterial(),"&b"+crate.displayName(),"&7ID: &f"+crate.id(),"&7Type: &f"+crate.type().name().toLowerCase(Locale.ROOT),"&7Rewards: &f"+crate.rewards().size(),"","&eLeft click: Edit","&eRight click: Bind block");var meta=icon.getItemMeta();meta.getPersistentDataContainer().set(key,PersistentDataType.STRING,crate.id());icon.setItemMeta(meta);inv.setItem(slot,icon);}
        if(current>0)inv.setItem(48,GuiItems.item(Material.ARROW,"&ePrevious"));inv.setItem(49,GuiItems.item(Material.PAPER,"&aCreate Crate"));if(current+1<pages)inv.setItem(50,GuiItems.item(Material.ARROW,"&eNext"));player.openInventory(inv);
    }
    public static boolean isTitle(String title){return title.startsWith(PREFIX);} public static int pageFromTitle(String title){try{return Math.max(0,Integer.parseInt(title.substring(PREFIX.length()).trim())-1);}catch(Exception ignored){return 0;}}
}
