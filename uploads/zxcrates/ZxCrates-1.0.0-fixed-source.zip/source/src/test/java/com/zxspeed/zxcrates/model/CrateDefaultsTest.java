package com.zxspeed.zxcrates.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CrateDefaultsTest {
    @Test void hologramBackgroundDefaultsToHidden() {
        Crate crate = new Crate("test");
        assertFalse(crate.hologramBackground());
        crate.hologramBackground(true);
        assertTrue(crate.hologramBackground());
    }

    @Test void displayBlockCanBeChangedFromMaterial() {
        Crate crate = new Crate("test");
        crate.blockMaterial(org.bukkit.Material.DIAMOND_BLOCK);
        assertEquals(org.bukkit.Material.DIAMOND_BLOCK, crate.blockMaterial());
    }
}
