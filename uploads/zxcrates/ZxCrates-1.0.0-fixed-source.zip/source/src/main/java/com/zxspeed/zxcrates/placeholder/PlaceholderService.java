package com.zxspeed.zxcrates.placeholder;

import com.zxspeed.zxcrates.ZxCratesPlugin;
import com.zxspeed.zxcrates.model.Crate;
import com.zxspeed.zxcrates.model.Reward;
import org.bukkit.entity.Player;

import java.util.Locale;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class PlaceholderService {
    private static final Pattern INTERNAL = Pattern.compile("\\{([a-zA-Z0-9_-]+)}");
    private static final Pattern PAPI = Pattern.compile("%zxcrates_([a-zA-Z0-9_-]+)%", Pattern.CASE_INSENSITIVE);
    private static final Pattern BARE_REWARD = Pattern.compile("%(reward_chance|reward_chance_percent)%", Pattern.CASE_INSENSITIVE);

    private final ZxCratesPlugin plugin;

    public PlaceholderService(ZxCratesPlugin plugin) {
        this.plugin = plugin;
    }

    public String parse(Player player, String input, Crate context) {
        return parse(player, input, context, null);
    }

    /** Parses text with an optional reward context. This makes %reward_chance% reward-specific. */
    public String parse(Player player, String input, Crate context, Reward reward) {
        if (input == null || input.isEmpty()) return "";
        String result = replace(player, input, context, reward, INTERNAL);
        result = replace(player, result, context, reward, BARE_REWARD);
        result = replace(player, result, context, reward, PAPI);
        if (player != null && plugin.getServer().getPluginManager().getPlugin("PlaceholderAPI") != null) {
            result = me.clip.placeholderapi.PlaceholderAPI.setPlaceholders(player, result);
        }
        return result;
    }

    public String resolve(Player player, String rawToken, Crate context) {
        return resolve(player, rawToken, context, null);
    }

    public String resolve(Player player, String rawToken, Crate context, Reward reward) {
        if (rawToken == null || rawToken.isBlank()) return null;
        String token = normalize(rawToken);

        String contextValue = resolveContextToken(token, player, context, reward);
        if (contextValue != null) return contextValue;

        String directRewardChance = resolveDirectRewardChance(token);
        if (directRewardChance != null) return directRewardChance;

        if (token.equals("keyall_time")) return plugin.keyAll().timeRemainingDefault();
        if (token.startsWith("keyall_time_")) {
            String id = token.substring("keyall_time_".length());
            return id.isBlank() ? plugin.keyAll().timeRemainingDefault() : plugin.keyAll().timeRemaining(id);
        }
        if (token.equals("keyall_default")) return plugin.keyAll().defaultId();

        if (player == null) return null;

        return resolvePlayerToken(player, token);
    }

    private String resolveContextToken(String token, Player player, Crate context, Reward reward) {
        if (token.equals("crate")) return context == null ? null : context.displayName();
        if (token.equals("crate_id")) return context == null ? null : context.id();
        if (token.equals("crate_type")) return context == null ? null : context.type().name().toLowerCase(Locale.ROOT);
        if (token.equals("crate_rewards")) return context == null ? null : Integer.toString(context.rewards().size());
        if (token.equals("crate_slots")) return context == null ? null : Integer.toString(context.slots());
        if (token.equals("crate_animation")) return context == null ? null : context.animation().name().toLowerCase(Locale.ROOT);
        if (token.equals("crate_keys")) return context == null || player == null ? null : Integer.toString(plugin.service().keyCount(player, context));
        if (token.equals("crate_keys_crateid")) return context == null || player == null ? null : Integer.toString(plugin.service().keyCount(player, context));
        if (token.equals("reward_chance") || token.equals("reward_chance_percent")) {
            return reward == null || context == null ? null : formatChance(context, reward);
        }
        return null;
    }

    private String resolvePlayerToken(Player player, String token) {
        if (token.equals("player")) return player.getName();
        if (token.equals("uuid")) return player.getUniqueId().toString();
        if (token.equals("crate_keys_total")) return Integer.toString(plugin.service().cachedTotalKeys(player.getUniqueId()));
        if (token.equals("last_win")) return plugin.service().lastWin(player);
        if (token.equals("last_win_crate")) return plugin.service().lastWinCrate(player);
        if (token.equals("last_win_amount")) return Integer.toString(plugin.service().lastWinAmount(player));
        if (token.equals("crate_opens_total")) return Integer.toString(plugin.service().opensTotal(player));
        if (token.equals("opening_crate")) return plugin.service().openingCrate(player.getUniqueId());

        if (token.startsWith("crate_keys_cloud_")) {
            String id = token.substring("crate_keys_cloud_".length());
            Crate target = findCrate(id);
            return target == null || !target.isCloudKey() ? "0" : Integer.toString(plugin.service().keyCount(player, target));
        }

        if (token.startsWith("crate_keys_")) {
            String id = token.substring("crate_keys_".length());
            if (id.isBlank()) return "0";
            Crate target = findCrate(id);
            return target == null ? "0" : Integer.toString(plugin.service().keyCount(player, target));
        }

        if (token.startsWith("crate_name_")) {
            String id = token.substring("crate_name_".length());
            Crate target = findCrate(id);
            return target == null ? "" : target.displayName();
        }
        if (token.startsWith("crate_type_")) {
            String id = token.substring("crate_type_".length());
            Crate target = findCrate(id);
            return target == null ? "" : target.type().name().toLowerCase(Locale.ROOT);
        }
        if (token.startsWith("crate_rewards_")) {
            String id = token.substring("crate_rewards_".length());
            Crate target = findCrate(id);
            return target == null ? "0" : Integer.toString(target.rewards().size());
        }
        if (token.startsWith("crate_opens_")) {
            String id = token.substring("crate_opens_".length());
            return id.isBlank() ? Integer.toString(plugin.service().opensTotal(player)) : Integer.toString(plugin.service().opens(player, id));
        }

        return null;
    }

    private Crate findCrate(String id) {
        if (id == null || id.isBlank()) return null;
        return plugin.service().get(id).orElse(null);
    }

    private String replace(Player player, String input, Crate context, Reward reward, Pattern pattern) {
        Matcher matcher = pattern.matcher(input);
        StringBuffer output = new StringBuffer();
        while (matcher.find()) {
            String token = matcher.group(1);
            String value = resolve(player, token, context, reward);
            matcher.appendReplacement(output, Matcher.quoteReplacement(value == null ? matcher.group() : value));
        }
        matcher.appendTail(output);
        return output.toString();
    }

    private String resolveDirectRewardChance(String token) {
        if (!token.startsWith("reward_chance_")) return null;
        String raw = token.substring("reward_chance_".length());
        int split = raw.lastIndexOf('_');
        if (split <= 0 || split == raw.length() - 1) return null;
        String crateId = raw.substring(0, split);
        int rewardId;
        try { rewardId = Integer.parseInt(raw.substring(split + 1)); }
        catch (NumberFormatException ignored) { return null; }
        Crate crate = findCrate(crateId);
        if (crate == null) return null;
        Reward reward = crate.findReward(rewardId).orElse(null);
        return reward == null ? null : formatChance(crate, reward);
    }

    private String formatChance(Crate crate, Reward reward) {
        double percentage = Math.max(0D, Math.min(100D, reward.chance()));
        return String.format(Locale.ROOT, "%.2f%%", percentage);
    }

    private String normalize(String token) {
        String normalized = token.trim();
        if (normalized.startsWith("%") && normalized.endsWith("%")) normalized = normalized.substring(1, normalized.length() - 1);
        if (normalized.startsWith("zxcrates_")) normalized = normalized.substring("zxcrates_".length());
        if (normalized.equalsIgnoreCase("crate_keys_crateid")) return "crate_keys_crateid";
        return normalized.toLowerCase(Locale.ROOT);
    }

    public boolean isPlayerSpecific(String input) {
        if (input == null || input.isEmpty()) return false;
        String lower = input.toLowerCase(Locale.ROOT);
        if (lower.contains("{player}") || lower.contains("{uuid}") || lower.contains("%player%") || lower.contains("%uuid%")) return true;
        if (lower.contains("{crate_keys_total}") || lower.contains("{last_win") || lower.contains("{crate_opens") || lower.contains("{opening_crate}")) return true;
        if (PAPI.matcher(input).find()) {
            Matcher matcher = PAPI.matcher(input);
            while (matcher.find()) {
                String token = matcher.group(1).toLowerCase(Locale.ROOT);
                if (isPlayerSpecificToken(token)) return true;
            }
        }
        return false;
    }

    private boolean isPlayerSpecificToken(String token) {
        return token.equals("crate_keys_total") || token.startsWith("crate_keys_") || token.startsWith("crate_keys_cloud_")
                || token.equals("last_win") || token.startsWith("last_win_") || token.equals("crate_opens_total")
                || token.startsWith("crate_opens_") || token.equals("opening_crate") || token.startsWith("keyall_time")
                || token.equals("player") || token.equals("uuid");
    }
}
