package com.zxspeed.zxcrates.model;

public enum AnimationType {
    GALAXY,
    CELESTIAL_RUSH,
    NEBULA_SPIRAL,
    INFERNO_BLOOM,
    FROST_NOVA,
    THUNDERSTORM,
    OCEAN_TIDE,
    MATRIX_PULSE,
    ROYAL_CROWN,
    DIMENSION_BREAK,
    LEGENDARY_ASCENT
}
