package com.zxspeed.zxcrates.model;

import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

public final class Reward {
    private int id;
    private int slot;
    private double chance;
    private boolean chanceManual;
    private RewardType type;
    private ItemStack item;
    private int amount;
    private final List<String> commands = new ArrayList<>();

    public Reward(int id, double chance, RewardType type, ItemStack item, int amount, List<String> commands) {
        this(id, -1, chance, type, item, amount, commands);
    }

    public Reward(int id, int slot, double chance, RewardType type, ItemStack item, int amount, List<String> commands) {
        this(id, slot, chance, false, type, item, amount, commands);
    }

    public Reward(int id, int slot, double chance, boolean chanceManual, RewardType type, ItemStack item, int amount, List<String> commands) {
        this.id = Math.max(1, id);
        this.slot = slot;
        this.chance = sanitizeChance(chance);
        this.chanceManual = chanceManual;
        this.type = type == null ? RewardType.GIVE_ITEM : type;
        this.item = item == null ? null : item.clone();
        this.amount = Math.max(1, amount);
        if (commands != null) this.commands.addAll(commands);
    }

    public int id() { return id; }
    public int slot() { return slot; }
    public double chance() { return chance; }
    public boolean chanceManual() { return chanceManual; }
    public RewardType type() { return type; }
    public ItemStack item() { return item == null ? null : item.clone(); }
    public int amount() { return amount; }
    public List<String> commands() { return List.copyOf(commands); }

    public void slot(int value) { slot = value < 0 ? -1 : value; }
    public void chance(double value) { chance = sanitizeChance(value); }
    public void manualChance(double value) { chance = sanitizeChance(value); chanceManual = true; }
    public void automaticChance(double value) { chance = sanitizeChance(value); chanceManual = false; }
    public void chanceManual(boolean value) { chanceManual = value; }
    public void type(RewardType value) { type = value == null ? RewardType.GIVE_ITEM : value; }
    public void item(ItemStack value) { item = value == null ? null : value.clone(); }
    public void amount(int value) { amount = Math.max(1, value); }
    public void commands(List<String> value) { commands.clear(); if (value != null) commands.addAll(value); }

    public Reward copy() { return new Reward(id, slot, chance, chanceManual, type, item, amount, commands); }

    private static double sanitizeChance(double value) {
        if (!Double.isFinite(value)) return 0D;
        return Math.max(0D, Math.min(100D, value));
    }
}
