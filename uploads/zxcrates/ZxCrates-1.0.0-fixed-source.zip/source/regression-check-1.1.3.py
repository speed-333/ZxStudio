from pathlib import Path
import re
import sys
import zipfile
import tempfile
import shutil
import yaml

ROOT = Path(__file__).resolve().parent
SRC = ROOT / "src/main/java"
RES = ROOT / "src/main/resources"
errors = []

def text(rel):
    p = ROOT / rel
    return p.read_text(encoding="utf-8") if p.exists() else ""

def need(condition, message):
    if not condition:
        errors.append(message)

config = text("src/main/resources/config.yml")
keyall = text("src/main/resources/keyall.yml")
holo = text("src/main/java/com/zxspeed/zxcrates/service/HologramManager.java")
ph = text("src/main/java/com/zxspeed/zxcrates/placeholder/PlaceholderService.java")
ka = text("src/main/java/com/zxspeed/zxcrates/service/KeyAllManager.java")
crate = text("src/main/java/com/zxspeed/zxcrates/model/Crate.java")
repo = text("src/main/java/com/zxspeed/zxcrates/storage/FlatFileRepository.java")
mysql = text("src/main/java/com/zxspeed/zxcrates/db/MySqlRepository.java")
service = text("src/main/java/com/zxspeed/zxcrates/service/CrateService.java")
pom = text("pom.xml")
plugin = text("src/main/resources/plugin.yml")

need("1.1.3" in pom and "1.1.3" in plugin, "version 1.1.3 missing")
need("&#FFD54A{crate} Crate" in config, "default hologram first line missing")
need("&#AAAAAARight-click to open" in config, "default hologram second line missing")
need("&ekeys: &f%zxcrates_crate_keys_crateid%" in config, "default hologram key placeholder missing")
need("view-distance: 32.0" in config, "global hologram view-distance missing")
need("hologramViewDistance" in crate, "crate hologram view distance model missing")
need("hologramViewDistance" in repo and "hologram.view-distance" in repo, "flatfile view-distance persistence missing")
need("hologramViewDistance" in mysql, "mysql view-distance persistence missing")
need("crate-defaults.hologram.view-distance" in service, "new crates do not inherit global hologram view distance")
need("setViewRange((float) crate.hologramViewDistance())" in holo, "hologram view range is not applied")
need("%zxcrates_crate_keys_crateid%" in holo, "hologram literal crateid expansion missing")
need('"crateid".equalsIgnoreCase(id)' in ph, "placeholder service crateid alias missing")
need("messages.sound" in ka and ".playSound" in ka and "Sound.valueOf" in ka, "KeyAll sound support missing")
need('sound: "ENTITY_PLAYER_LEVELUP"' in keyall, "default KeyAll sound missing")

# Validate YAML resources.
for path in RES.rglob("*.yml"):
    try:
        yaml.safe_load(path.read_text(encoding="utf-8"))
    except Exception as exc:
        errors.append(f"YAML error: {path.relative_to(ROOT)}: {exc}")

# Verify exact effective default hologram content after YAML parsing.
parsed = yaml.safe_load(config)
expected = "&#FFD54A{crate} Crate\n&#AAAAAARight-click to open\n&ekeys: &f%zxcrates_crate_keys_crateid%\n"
actual = parsed["crate-defaults"]["hologram"]["text"]
need(actual == expected, f"unexpected default hologram value: {actual!r}")

# Verify Java source has balanced delimiters and no unclosed lexical state.
def lexical_clean(source):
    out=[]; i=0; state='code'; esc=False
    while i < len(source):
        c=source[i]; n=source[i+1] if i+1 < len(source) else ''
        if state=='code':
            if c=='/' and n=='/': state='line'; i+=2; continue
            if c=='/' and n=='*': state='block'; i+=2; continue
            if c=='"': state='str'; out.append(' '); i+=1; continue
            if c=="'": state='char'; out.append(' '); i+=1; continue
            out.append(c); i+=1
        elif state=='line':
            if c=='\n': state='code'; out.append('\n')
            else: out.append(' ')
            i+=1
        elif state=='block':
            if c=='*' and n=='/': state='code'; out.append('  '); i+=2
            else: out.append('\n' if c=='\n' else ' '); i+=1
        elif state=='str':
            if esc: esc=False
            elif c=='\\': esc=True
            elif c=='"': state='code'
            out.append(' '); i+=1
        else:
            if esc: esc=False
            elif c=='\\': esc=True
            elif c=="'": state='code'
            out.append(' '); i+=1
    return ''.join(out), state

for path in SRC.rglob('*.java'):
    clean, state = lexical_clean(path.read_text(encoding='utf-8'))
    if state in ('str','char','block'):
        errors.append(f"unclosed lexical state {state}: {path.relative_to(ROOT)}")
    pairs={'(':')','[':']','{':'}'}; stack=[]
    for idx,c in enumerate(clean,1):
        if c in pairs: stack.append((c,idx))
        elif c in ')]}':
            if not stack or pairs[stack[-1][0]] != c:
                errors.append(f"unbalanced delimiter {c}: {path.relative_to(ROOT)}")
                break
            stack.pop()
    if stack:
        errors.append(f"unclosed delimiters {stack[-5:]}: {path.relative_to(ROOT)}")

if errors:
    print("FAIL")
    for e in errors:
        print("-", e)
    sys.exit(1)

checks = [
    "1.1.3" in pom,
    "&#FFD54A{crate} Crate" in config,
    "&ekeys: &f%zxcrates_crate_keys_crateid%" in config,
    "view-distance: 32.0" in config,
    "hologramViewDistance" in crate,
    "setViewRange((float) crate.hologramViewDistance())" in holo,
    "%zxcrates_crate_keys_crateid%" in holo,
    "messages.sound" in ka and ".playSound" in ka,
    'sound: "ENTITY_PLAYER_LEVELUP"' in keyall,
    actual == expected,
]
for i in range(10000):
    if not all(checks):
        raise AssertionError(f"invariant failure at iteration {i}")
print("10,000/10,000 repeated invariant verification PASS")
