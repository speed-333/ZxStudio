package com.zxspeed.zxcrates.model;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

import java.util.*;

public final class Crate {
    private final String id;
    private String displayName;
    private CrateType type;
    private Material blockMaterial;
    private AnimationType animation;
    private boolean createKey;
    private String keyDelivery;
    private String keyDisplayName;
    private ItemStack keyItem;
    private boolean keyStacked;
    private String openPermission;
    private long cooldownSeconds;
    private boolean broadcastWin;
    private int slots;
    private boolean hologramEnabled;
    private String hologramText;
    private double hologramOffsetY;
    private double hologramViewDistance;
    private boolean hologramBackground;
    private final List<String> itemLore = new ArrayList<>();
    private final List<Reward> rewards = new ArrayList<>();
    private final Set<String> locations = new LinkedHashSet<>();

    public Crate(String id) {
        this.id = id;
        this.displayName = id;
        this.type = CrateType.RANDOM;
        this.blockMaterial = Material.CHEST;
        this.animation = AnimationType.GALAXY;
        this.createKey = true;
        this.keyDelivery = "cloud";
        this.keyDisplayName = "&#FFD54AZxCrates Key";
        this.keyItem = new ItemStack(Material.TRIPWIRE_HOOK);
        this.keyStacked = true;
        this.openPermission = "";
        this.cooldownSeconds = 0L;
        this.broadcastWin = false;
        this.slots = 45;
        this.hologramEnabled = true;
        this.hologramText = "&a%zxcrates_crate% Crate\n&r\n&a▶ &fHit To &aPreview &a!\n&a▶ &fUse Key To &aOpen &a!\n&fYou Have &a%zxcrates_crate_keys_crateid%\n&f%zxcrates_crate% &aKey!\n&r\n&fSelector Type: &aRandom\n&fBuy Keys! &a/Store";
        this.hologramOffsetY = 1.2D;
        this.hologramViewDistance = 32.0D;
        this.hologramBackground = false;
        this.itemLore.add("");
        this.itemLore.add("&8&m----------------");
        this.itemLore.add("&fᴄʜᴀɴᴄᴇ: &a%reward_chance%");
        this.itemLore.add("&fʏᴏᴜʀ ᴋᴇʏѕ: &a%zxcrates_crate_keys_crateid%");
        this.itemLore.add("&8&m----------------");
    }

    public synchronized String id() { return id; }
    public synchronized String displayName() { return displayName; }
    public synchronized void displayName(String value) { displayName = value == null || value.isBlank() ? id : value; }
    public synchronized CrateType type() { return type; }
    public synchronized void type(CrateType value) { type = value == null ? CrateType.RANDOM : value; }
    public synchronized Material blockMaterial() { return blockMaterial; }
    public synchronized void blockMaterial(Material value) { blockMaterial = value == null ? Material.CHEST : value; }
    public synchronized AnimationType animation() { return animation; }
    public synchronized void animation(AnimationType value) { animation = value == null ? AnimationType.GALAXY : value; }
    public synchronized boolean createKey() { return createKey; }
    public synchronized void createKey(boolean value) { createKey = value; }
    public synchronized String keyDelivery() { return "item".equalsIgnoreCase(keyDelivery) ? "item" : "cloud"; }
    public synchronized void keyDelivery(String value) { keyDelivery = "item".equalsIgnoreCase(value) ? "item" : "cloud"; }
    public synchronized boolean isItemKey() { return "item".equalsIgnoreCase(keyDelivery); }
    public synchronized boolean isCloudKey() { return !isItemKey(); }
    public synchronized String keyDisplayName() { return keyDisplayName; }
    public synchronized void keyDisplayName(String value) { keyDisplayName = value == null || value.isBlank() ? "&#FFD54AZxCrates Key" : value; }
    public synchronized ItemStack keyItem() { return keyItem == null ? null : keyItem.clone(); }
    public synchronized void keyItem(ItemStack value) { keyItem = value == null ? new ItemStack(Material.TRIPWIRE_HOOK) : value.clone(); }
    public synchronized boolean keyStacked() { return keyStacked; }
    public synchronized void keyStacked(boolean value) { keyStacked = value; }
    public synchronized String openPermission() { return openPermission; }
    public synchronized void openPermission(String value) { openPermission = value == null ? "" : value; }
    public synchronized long cooldownSeconds() { return cooldownSeconds; }
    public synchronized void cooldownSeconds(long value) { cooldownSeconds = Math.max(0L, Math.min(86_400L, value)); }
    public synchronized boolean broadcastWin() { return broadcastWin; }
    public synchronized void broadcastWin(boolean value) { broadcastWin = value; }
    public synchronized int slots() { return slots; }
    public synchronized void slots(int value) { slots = normalizeSlots(value); }
    public synchronized boolean hologramEnabled() { return hologramEnabled; }
    public synchronized void hologramEnabled(boolean value) { hologramEnabled = value; }
    public synchronized String hologramText() { return hologramText; }
    public synchronized void hologramText(String value) { hologramText = value == null || value.isBlank() ? "&a%zxcrates_crate% Crate\n&r\n&a▶ &fHit To &aPreview &a!\n&a▶ &fUse Key To &aOpen &a!\n&fYou Have &a%zxcrates_crate_keys_crateid%\n&f%zxcrates_crate% &aKey!\n&r\n&fSelector Type: &aRandom\n&fBuy Keys! &a/Store" : value; }
    public synchronized double hologramOffsetY() { return hologramOffsetY; }
    public synchronized void hologramOffsetY(double value) { hologramOffsetY = Double.isFinite(value) ? Math.max(0.25D, Math.min(8D, value)) : 1.2D; }
    public synchronized double hologramViewDistance() { return hologramViewDistance; }
    public synchronized void hologramViewDistance(double value) {
        hologramViewDistance = Double.isFinite(value) ? Math.max(0.0D, Math.min(128.0D, value)) : 32.0D;
    }
    public synchronized boolean hologramBackground() { return hologramBackground; }
    public synchronized void hologramBackground(boolean value) { hologramBackground = value; }
    public synchronized List<String> itemLore() { return List.copyOf(itemLore); }
    public synchronized void itemLore(Collection<String> values) { itemLore.clear(); if (values != null) values.forEach(value -> { if (value != null) itemLore.add(value); }); }
    public synchronized void addItemLoreLine(String value) { if (value != null) itemLore.add(value); }

    public synchronized List<Reward> rewards() { return Collections.unmodifiableList(new ArrayList<>(rewards)); }
    public synchronized void rewards(Collection<Reward> values) {
        rewards.clear();
        if (values != null) values.forEach(value -> rewards.add(value.copy()));
        rebalanceRewardChances();
    }
    public synchronized void addReward(Reward reward) { rewards.add(Objects.requireNonNull(reward)); rebalanceRewardChances(); }
    public synchronized void removeReward(int index) { if (index >= 0 && index < rewards.size()) { rewards.remove(index); rebalanceRewardChances(); } }
    public synchronized boolean setManualRewardChance(int rewardId, double value) {
        if (!Double.isFinite(value) || value < 0D || value > 100D) return false;
        Reward target = null;
        double manualOther = 0D;
        for (Reward reward : rewards) {
            if (reward.id() == rewardId) target = reward;
            else if (reward.chanceManual()) manualOther += reward.chance();
        }
        if (target == null || manualOther + value > 100.0000000001D) return false;
        target.manualChance(value);
        rebalanceRewardChances();
        return true;
    }
    public synchronized void makeRewardAutomatic(int rewardId) {
        Reward target = findReward(rewardId).orElse(null);
        if (target != null) { target.automaticChance(0D); rebalanceRewardChances(); }
    }
    public synchronized void rebalanceRewardChances() {
        double manualTotal = 0D;
        int automaticCount = 0;
        for (Reward reward : rewards) {
            if (reward.chanceManual()) manualTotal += reward.chance();
            else automaticCount++;
        }
        double remaining = Math.max(0D, 100D - manualTotal);
        double automaticShare = automaticCount == 0 ? 0D : remaining / automaticCount;
        for (Reward reward : rewards) if (!reward.chanceManual()) reward.automaticChance(automaticShare);
    }
    public synchronized Optional<Reward> findReward(int rewardId) { return rewards.stream().filter(reward -> reward.id() == rewardId).findFirst(); }
    public synchronized Optional<Reward> rewardAt(int index) { return index >= 0 && index < rewards.size() ? Optional.of(rewards.get(index)) : Optional.empty(); }

    public synchronized Set<String> locations() { return Collections.unmodifiableSet(new LinkedHashSet<>(locations)); }
    public synchronized boolean isAt(Location location) { return location != null && locations.contains(locationKey(location)); }
    public synchronized void addLocation(Location location) { if (location != null) locations.add(locationKey(location)); }
    public synchronized void addLocationKey(String key) { if (key != null && !key.isBlank()) locations.add(key); }
    public synchronized void removeLocation(Location location) { if (location != null) locations.remove(locationKey(location)); }

    public synchronized Crate snapshot() {
        Crate copy = new Crate(id);
        copy.displayName(displayName); copy.type(type); copy.blockMaterial(blockMaterial); copy.animation(animation);
        copy.createKey(createKey); copy.keyDelivery(keyDelivery); copy.keyDisplayName(keyDisplayName); copy.keyItem(keyItem); copy.keyStacked(keyStacked);
        copy.openPermission(openPermission); copy.cooldownSeconds(cooldownSeconds); copy.broadcastWin(broadcastWin); copy.slots(slots);
        copy.hologramEnabled(hologramEnabled); copy.hologramText(hologramText); copy.hologramOffsetY(hologramOffsetY); copy.hologramViewDistance(hologramViewDistance); copy.hologramBackground(hologramBackground); copy.itemLore(itemLore);
        rewards.forEach(reward -> copy.addReward(reward.copy())); locations.forEach(copy::addLocationKey);
        return copy;
    }

    private static int normalizeSlots(int value) { int clamped = Math.max(9, Math.min(54, value)); int normalized = clamped - (clamped % 9); return Math.max(9, normalized); }
    public static String locationKey(Location location) { return location.getWorld().getName() + ":" + location.getBlockX() + ":" + location.getBlockY() + ":" + location.getBlockZ(); }
}
