package com.zxspeed.zxcrates.gui;

import com.zxspeed.zxcrates.ZxCratesPlugin;
import com.zxspeed.zxcrates.model.Crate;
import com.zxspeed.zxcrates.model.Reward;
import com.zxspeed.zxcrates.util.ColorUtil;
import com.zxspeed.zxcrates.util.ItemLoreUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.Locale;

public final class CratePreviewMenu {
    public static final String PREFIX="§8Crate Preview";
    private CratePreviewMenu(){}
    public static void open(ZxCratesPlugin plugin,Player player,Crate crate){
        int slots=crate.slots();Inventory inv=Bukkit.createInventory(null,slots,PREFIX);
        for(Reward reward:crate.rewards()){
            int slot=reward.slot()>=0?reward.slot():crate.rewards().indexOf(reward);if(slot<0||slot>=slots)continue;
            ItemStack icon=reward.item()==null?new ItemStack(Material.NETHER_STAR):ItemLoreUtil.withCrateLore(reward.item(),crate,reward,player,plugin.placeholders());
            icon.setAmount(Math.min(Math.max(1,reward.amount()),icon.getMaxStackSize()));
            inv.setItem(slot,icon);
        }
        for (int slot = 0; slot < inv.getSize(); slot++) {
            if (inv.getItem(slot) == null || inv.getItem(slot).getType().isAir()) inv.setItem(slot, GuiItems.resetNamePane());
        }
        player.openInventory(inv);
    }
    public static boolean isTitle(String title){return PREFIX.equals(title);}
}
