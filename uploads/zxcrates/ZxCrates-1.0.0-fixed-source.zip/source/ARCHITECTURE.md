# ZxCrates Architecture

## الوحدات

- `model`: نماذج Crate/Reward والأنواع الخاصة بها.
- `service`: منطق الفتح وحساب الاحتمالات والكاش وإدارة المفاتيح.
- `storage`: FlatFile مع `data.yml` وترميز ItemStack بصيغة bytes/Base64.
- `db`: MySQL + HikariCP + migrations.
- `gui`: قائمة الصناديق، محرر الصندوق، قائمة الجوائز، وأحداث الواجهات.
- `listener`: ربط الصندوق بالعالم، فتحه، وكسره.
- `placeholder`: PlaceholderAPI expansion.
- `command`: aliases وtab-completion.
- `util`: جدولة Folia/Paper حسب اللاعب/الكيان/النطاق العام.

## واجهات الاستخدام

1. `/crates editor` يعرض جميع الصناديق.
2. النقر على صندوق يفتح Basic Info.
3. زر Rewards يعرض الجوائز وإضافة reward من الـcursor.
4. زر Animation يغيّر الاستراتيجية الحالية.
5. زر Keys يبدّل delivery بين inventory وcloud.
6. `/zxcrates bind <id>` ثم Right Click لربط block.
7. Shift + Right Click يكسر الصندوق مع `ZxCrates.break`.

## Threading

أي قراءة/تعديل للعالم أو Player/Inventory/Entity يتم على scheduler المرتبط باللاعب أو بالنطاق العام. عمليات DB وFlatFile تعمل على executor مستقل.

## ملاحظات أمان

- كل قيم MySQL تستخدم PreparedStatement.
- يوجد rate-limit أساسي لعمليات الفتح.
- أوامر الجوائز ينبغي أن تمر عبر allow-list/حد طول قبل اعتمادها في بيئة الإنتاج.
- يجب تحديد حدود لحجم ItemStack/NBT قبل التخزين النهائي.
- يجب عدم استدعاء `CompletableFuture.join()` في event thread لعمليات DB؛ Placeholder expansion الحالية تعتمد على الكاش فقط.


## Per-crate files

يستخدم التخزين المحلي الآن مجلد `plugins/ZxCrates/crates/`، وكل معرف Crate له ملف YAML مستقل. هذا يمنع تداخل التعديلات ويجعل النسخ الاحتياطي والتحرير اليدوي أسهل.

## Crate item + hologram

يتم تعليم Item الصندوق بواسطة PDC داخلي. عند `BlockPlaceEvent` يتم التعرف على الـcrate، تسجيل الموقع، ثم جدولة إنشاء `TextDisplay` على Region Scheduler المتوافق مع Folia.
