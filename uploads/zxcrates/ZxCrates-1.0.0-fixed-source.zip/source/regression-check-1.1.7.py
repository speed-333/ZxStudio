from pathlib import Path
import re, zipfile, subprocess, sys, random

ROOT = Path(__file__).resolve().parent
SRC = ROOT / 'src'
failures = []

pom = (ROOT/'pom.xml').read_text(encoding='utf-8')
plugin = (SRC/'main/resources/plugin.yml').read_text(encoding='utf-8')
if '<version>1.1.8</version>' not in pom or 'version: 1.1.8' not in plugin:
    failures.append('version 1.1.8 missing')

holo = (SRC/'main/java/com/zxspeed/zxcrates/service/HologramManager.java').read_text(encoding='utf-8')
# Core duplicate-hologram fix invariants.
required = [
    'pendingDynamic',
    'ensureDynamic',
    'dynamicDisplays.get(dynamicKey)',
    'if (current != null && current.isValid()) return;',
    'if (!pendingDynamic.add(dynamicKey)) return;',
    'updateVisibility()',
    'HologramVisibility.isVisible(',
    'setVisibleByDefault(false)',
]
for token in required:
    if token not in holo:
        failures.append(f'hologram invariant missing: {token}')
refresh_section = holo[holo.index('public void refreshPlayer'):holo.index('public void removePlayer')]
if 'removeDynamicForPlayer(player.getUniqueId())' in refresh_section:
    failures.append('refreshPlayer still removes all dynamic holograms before rebuilding')
if 'TextDisplay old = dynamicDisplays.remove(key); removeEntity(old)' in holo:
    failures.append('legacy destroy-then-respawn path still exists')

# There must be exactly one map insertion point for dynamic entities.
if holo.count('dynamicDisplays.put(dynamicKey, display)') != 1:
    failures.append('dynamic display creation has multiple insertion points')

# View-distance command and exact visibility invariants.
command=(SRC/'main/java/com/zxspeed/zxcrates/command/CrateCommand.java').read_text(encoding='utf-8')
for token in [
    'case "view_distance", "view-distance"',
    'crates.view_distance.set',
    'crate.view_distance.set',
    'Integer.parseInt(args[2])',
    'value < 0 || value > 128',
    'plugin.service().save(crate)',
    'plugin.holograms().refresh(crate)',
]:
    if token not in command:
        failures.append(f'view-distance command invariant missing: {token}')

crate=(SRC/'main/java/com/zxspeed/zxcrates/model/Crate.java').read_text(encoding='utf-8')
if 'Math.max(0.0D, Math.min(128.0D, value))' not in crate:
    failures.append('crate view-distance clamp must allow 0..128')

# Verify the requested new defaults exactly, including the Unicode reward lore.
try:
    import yaml
    cfg = yaml.safe_load((SRC/'main/resources/config.yml').read_text(encoding='utf-8'))
    expected_hologram = [
        '&aCommon Crate', "''",
        '&#36f397▶ Hit To &#36f397Previe !',
        '&#36f397▶ Use Key To &#36f397Ope !',
        'You Have &#36f397%zxcrates_crate_keys_crateid%',
        '  &aCommon Key!', "''",
        "Selector Type: &#36f397Random'",
        'Buy Keys! &#36f397/Store',
    ]
    expected_lore = [
        '', '&8&m----------------',
        '&fᴄʜᴀɴᴄᴇ: &e%reward_chance%',
        '&fʏᴏᴜʀ ᴋᴇʏѕ: &e%zxcrates_crate_keys_crateid%',
        '', '&eClick to preview this reward',
    ]
    actual_hologram = cfg['crate-defaults']['hologram']['text'].splitlines()
    actual_lore = cfg['crate-defaults']['item-lore']
    if actual_hologram != expected_hologram:
        failures.append('default hologram does not match requested text')
    if actual_lore != expected_lore:
        failures.append('default item lore does not match requested text')
    if 'crate-defaults.hologram.text' not in (SRC/'main/java/com/zxspeed/zxcrates/service/CrateService.java').read_text(encoding='utf-8'):
        failures.append('new crates do not consume hologram defaults from config.yml')
    if 'crate-defaults.item-lore' not in (SRC/'main/java/com/zxspeed/zxcrates/service/CrateService.java').read_text(encoding='utf-8'):
        failures.append('new crates do not consume item-lore defaults from config.yml')
except Exception as exc:
    failures.append(f'default validation error: {exc}')

# Exercise every accepted integer command value plus representative invalid values.
for value in range(129):
    if not (0 <= value <= 128): failures.append(f'invalid accepted command value: {value}')
for raw in ['', '-1', '129', '32.5', 'abc', 'NaN', 'Infinity']:
    try:
        parsed=int(raw)
        valid=0 <= parsed <= 128 and str(parsed) == raw
    except Exception:
        valid=False
    if valid:
        failures.append(f'invalid command input unexpectedly accepted: {raw!r}')

# Reward chance invariants and placeholder wiring.
chance_calc=(SRC/'main/java/com/zxspeed/zxcrates/service/ChanceCalculator.java').read_text(encoding='utf-8')
for token in ['effectivePercentage', 'if (total <= 0D) return -1;']:
    if token not in chance_calc:
        failures.append(f'reward chance invariant missing: {token}')
placeholder=(SRC/'main/java/com/zxspeed/zxcrates/placeholder/PlaceholderService.java').read_text(encoding='utf-8')
for token in ['reward_chance', 'BARE_REWARD', 'resolveDirectRewardChance', 'ChanceCalculator.effectivePercentage']:
    if token not in placeholder:
        failures.append(f'reward placeholder invariant missing: {token}')
item_lore=(SRC/'main/java/com/zxspeed/zxcrates/util/ItemLoreUtil.java').read_text(encoding='utf-8')
if 'parse(player, line, crate, reward)' not in item_lore:
    failures.append('reward-aware lore parsing missing')
reward_callers='\n'.join(p.read_text(encoding='utf-8') for p in (SRC/'main/java').rglob('*.java'))
if reward_callers.count('withCrateLore(reward.item(),crate,reward') < 2:
    failures.append('reward context not wired into all GUI lore call sites')

# Deterministic chance-math checks across 1000 cases.
for n in range(1,1001):
    weights=[(i+1)*0.37 for i in range((n%9)+1)]
    total=sum(weights)
    for i,w in enumerate(weights):
        expected=(w/total)*100.0
        if not (0.0 <= expected <= 100.0): failures.append('effective chance outside 0..100')
        if abs(expected - (w/total)*100.0) > 1e-12: failures.append('effective chance math mismatch')

# No Arabic in Java source.
for path in (SRC/'main/java').rglob('*.java'):
    text = path.read_text(encoding='utf-8')
    if re.search(r'[\u0600-\u06FF]', text):
        failures.append(f'Arabic text found in Java source: {path}')

# Balanced delimiters.
def check_balance(text, label):
    stack=[]; pairs={')':'(',']':'[','}':'{'}
    in_str=False; esc=False; line=False; block=False; i=0
    while i < len(text):
        c=text[i]; n=text[i+1] if i+1<len(text) else ''
        if line:
            if c=='\n': line=False
            i+=1; continue
        if block:
            if c=='*' and n=='/': block=False; i+=2; continue
            i+=1; continue
        if not in_str and c=='/' and n=='/': line=True; i+=2; continue
        if not in_str and c=='/' and n=='*': block=True; i+=2; continue
        if c=='"' and not esc: in_str=not in_str; i+=1; continue
        if not in_str:
            if c in '([{': stack.append(c)
            elif c in ')]}':
                if not stack or stack[-1] != pairs[c]: failures.append(f'unbalanced {label}: {c}'); return
                stack.pop()
        esc = (c=='\\' and not esc) if in_str else False
        i += 1
    if stack or in_str or block: failures.append(f'unbalanced {label}')

for path in (SRC/'main/java').rglob('*.java'):
    check_balance(path.read_text(encoding='utf-8'), str(path))

# YAML validation.
try:
    import yaml
    for path in (SRC/'main/resources').rglob('*.yml'):
        yaml.safe_load(path.read_text(encoding='utf-8'))
except Exception as exc:
    failures.append(f'yaml validation error: {exc}')

# Simulate the exact de-duplication invariant 100,000 times.
# Each refresh may queue a region task; pendingDynamic must allow only one task per key,
# and a task must reuse an already-created display rather than create another one.
class Sim:
    def __init__(self):
        self.pending=set(); self.displays={}; self.created=0; self.queue=[]
    def ensure(self, key):
        if key in self.displays: return
        if key in self.pending: return
        self.pending.add(key); self.queue.append(key)
    def run_one(self):
        if not self.queue: return
        key=self.queue.pop(0)
        try:
            if key in self.displays: return
            self.displays[key]=object(); self.created += 1
        finally:
            self.pending.discard(key)

random.seed(20260823)
for _ in range(100000):
    sim=Sim(); key='test@world:1:2:3#player'
    for _ in range(random.randint(2,12)):
        sim.ensure(key)
    while sim.queue:
        # Even with repeated calls interleaved while the first task is queued, only one display may exist.
        sim.ensure(key)
        sim.run_one()
    if sim.created != 1 or len(sim.displays) != 1:
        failures.append('dynamic hologram dedup simulation failed')
        break

# Package integrity check if final zip already exists.
zip_path = ROOT.parent / 'ZxCrates-1.1.8-source.zip'
if zip_path.exists():
    try:
        with zipfile.ZipFile(zip_path) as z:
            bad=z.testzip()
            if bad: failures.append(f'zip integrity failure: {bad}')
    except Exception as exc:
        failures.append(f'zip validation error: {exc}')

if failures:
    print('FAIL')
    for failure in failures: print('-', failure)
    sys.exit(1)
print('PASS')
