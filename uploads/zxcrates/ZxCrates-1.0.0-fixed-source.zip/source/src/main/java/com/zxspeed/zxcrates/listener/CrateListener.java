package com.zxspeed.zxcrates.listener;

import com.zxspeed.zxcrates.ZxCratesPlugin;
import com.zxspeed.zxcrates.gui.CratePreviewMenu;
import com.zxspeed.zxcrates.model.*;
import com.zxspeed.zxcrates.service.CrateService;
import com.zxspeed.zxcrates.util.ColorUtil;
import com.zxspeed.zxcrates.util.ItemLoreUtil;
import com.zxspeed.zxcrates.util.Tasks;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.block.*;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.*;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

import java.util.*;

public final class CrateListener implements Listener {
    private final ZxCratesPlugin plugin;
    public CrateListener(ZxCratesPlugin plugin){this.plugin=plugin;}

    @EventHandler public void cratePlace(BlockPlaceEvent event){
        ItemStack item=event.getItemInHand();if(item==null||item.getItemMeta()==null)return;String crateId=item.getItemMeta().getPersistentDataContainer().get(new org.bukkit.NamespacedKey(plugin,"crate-item"),PersistentDataType.STRING);if(crateId==null)return;
        Optional<Crate> optional=plugin.service().get(crateId);if(optional.isEmpty()){event.setCancelled(true);return;}Crate crate=optional.get();crate.addLocation(event.getBlock().getLocation());crate.blockMaterial(event.getBlock().getType());plugin.service().save(crate);if(plugin.holograms()!=null)plugin.holograms().refresh(crate);
    }
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true) public void crateBroken(BlockBreakEvent event){Location loc=event.getBlock().getLocation();Optional<Crate> optional=plugin.service().findAt(loc);if(optional.isEmpty())return;Crate crate=optional.get();crate.removeLocation(loc);if(plugin.holograms()!=null)plugin.holograms().removeAt(crate,loc);plugin.service().save(crate);}
    @EventHandler public void openingClick(InventoryClickEvent event){if(com.zxspeed.zxcrates.service.AnimationManager.PREFIX.equals(event.getView().getTitle()))event.setCancelled(true);}
    @EventHandler public void join(PlayerJoinEvent event){plugin.service().warmKeys(event.getPlayer().getUniqueId()).whenComplete((ignored,error)->Tasks.player(event.getPlayer(),plugin,()->{plugin.service().refreshPhysicalKeys(event.getPlayer());if(plugin.holograms()!=null)plugin.holograms().refreshPlayer(event.getPlayer());}));}
    @EventHandler public void quit(PlayerQuitEvent event){plugin.service().endOpening(event.getPlayer().getUniqueId());if(plugin.holograms()!=null)plugin.holograms().removePlayer(event.getPlayer());}
    @EventHandler public void inventoryChanged(InventoryClickEvent event){if(event.getWhoClicked() instanceof Player player)plugin.service().refreshPhysicalKeys(player);}
    @EventHandler public void inventoryDragged(InventoryDragEvent event){if(event.getWhoClicked() instanceof Player player)plugin.service().refreshPhysicalKeys(player);}
    @EventHandler public void dropped(PlayerDropItemEvent event){plugin.service().refreshPhysicalKeys(event.getPlayer());}
    @EventHandler public void pickedUp(EntityPickupItemEvent event){if(event.getEntity() instanceof Player player)plugin.service().refreshPhysicalKeys(player);}
    @EventHandler public void changedWorld(PlayerChangedWorldEvent event){plugin.service().refreshPhysicalKeys(event.getPlayer());if(plugin.holograms()!=null)plugin.holograms().refreshPlayer(event.getPlayer());}
    @EventHandler(ignoreCancelled=true) public void hologramMove(PlayerMoveEvent event){ if(event.getTo()!=null && plugin.holograms()!=null) plugin.holograms().onPlayerMove(event.getPlayer()); }
    @EventHandler public void interact(PlayerInteractEvent event){
        if(event.getClickedBlock()==null|| (event.getAction()!=Action.RIGHT_CLICK_BLOCK&&event.getAction()!=Action.LEFT_CLICK_BLOCK))return;Player player=event.getPlayer();Location location=event.getClickedBlock().getLocation();
        if(event.getAction()==Action.RIGHT_CLICK_BLOCK){String pending=plugin.bindRequests().remove(player.getUniqueId());if(pending!=null){event.setCancelled(true);plugin.service().get(pending).ifPresent(crate->{crate.addLocation(location);crate.blockMaterial(event.getClickedBlock().getType());plugin.service().save(crate);if(plugin.holograms()!=null)plugin.holograms().refresh(crate);});return;}}
        Optional<Crate> optional=plugin.service().findAt(location);if(optional.isEmpty())return;event.setCancelled(true);Crate crate=optional.get();
        if(event.getAction()==Action.LEFT_CLICK_BLOCK){if(player.isSneaking()&&(player.hasPermission("ZxCrates.break")||player.hasPermission("ZxCrates.admin"))){event.getClickedBlock().setType(Material.AIR,false);crate.removeLocation(location);if(plugin.holograms()!=null)plugin.holograms().removeAt(crate,location);plugin.service().save(crate);}else CratePreviewMenu.open(plugin,player,crate);return;}
        if(player.isSneaking()){if(!player.hasPermission("ZxCrates.break")&&!player.hasPermission("ZxCrates.admin")){player.sendMessage(ColorUtil.colorize("&#FF5555You do not have permission to break crates."));return;}event.getClickedBlock().setType(Material.AIR,false);crate.removeLocation(location);if(plugin.holograms()!=null)plugin.holograms().removeAt(crate,location);plugin.service().save(crate);return;}
        open(player,crate);
    }
    @EventHandler public void previewHologram(PlayerInteractEntityEvent event){if(!(event.getRightClicked() instanceof org.bukkit.entity.TextDisplay display))return;String id=display.getPersistentDataContainer().get(new org.bukkit.NamespacedKey(plugin,"crate-hologram"),PersistentDataType.STRING);if(id==null)return;event.setCancelled(true);plugin.service().get(id).ifPresent(crate->open(event.getPlayer(),crate));}

    private void open(Player player,Crate crate){
        if(!player.hasPermission("ZxCrates.open")&&!player.hasPermission("ZxCrates.admin"))return;
        if(!crate.openPermission().isBlank()&&!player.hasPermission(crate.openPermission()))return;
        if(crate.rewards().isEmpty()){player.sendMessage(ColorUtil.colorize("&#FF5555This crate has no rewards."));return;}
        if(plugin.service().rateLimitedNow(player)||plugin.service().cooldownActive(player,crate))return;
        if(!plugin.service().tryBeginOpening(player.getUniqueId()))return;
        if(crate.type()==CrateType.SELECT){openSelection(player,crate);return;}
        Optional<CrateService.Win> win=plugin.service().roll(crate);if(win.isEmpty()){plugin.service().endOpening(player.getUniqueId());return;}
        plugin.service().takeKey(player,crate).whenComplete((ok,error)->Tasks.player(player,plugin,()->{if(error!=null||!Boolean.TRUE.equals(ok)){plugin.service().endOpening(player.getUniqueId());return;}plugin.service().markOpened(player,crate);plugin.animations().play(player,crate,win.get().reward(),()->finishWin(player,crate,win.get().reward()));}));
    }

    private void openSelection(Player player,Crate crate){
        plugin.service().setOpeningCrate(player.getUniqueId(), crate.id());
        int confirmSlot=Math.max(0,crate.slots()-1);Inventory inv=Bukkit.createInventory(null,crate.slots(),"§8Select Reward");org.bukkit.NamespacedKey rewardKey=new org.bukkit.NamespacedKey(plugin,"select-reward-id");
        for(int i=0;i<confirmSlot;i++)inv.setItem(i,new ItemStack(Material.BLACK_STAINED_GLASS_PANE));
        for(Reward reward:crate.rewards()){int slot=reward.slot()>=0?reward.slot():crate.rewards().indexOf(reward);if(slot<0||slot>=confirmSlot)continue;ItemStack item=reward.item()==null?new ItemStack(Material.NETHER_STAR):ItemLoreUtil.withCrateLore(reward.item(),crate,reward,player,plugin.placeholders());var meta=item.getItemMeta();if(meta!=null){meta.getPersistentDataContainer().set(rewardKey,PersistentDataType.INTEGER,reward.id());item.setItemMeta(meta);}inv.setItem(slot,item);}
        inv.setItem(confirmSlot,org.bukkit.inventory.ItemStack.of(Material.RED_DYE));player.openInventory(inv);
    }
    private void finishWin(Player player,Crate crate,Reward reward){try{give(player,crate,reward);if(com.zxspeed.zxcrates.service.AnimationManager.PREFIX.equals(player.getOpenInventory().getTitle()))player.closeInventory();}finally{plugin.service().endOpening(player.getUniqueId());if(plugin.holograms()!=null&&player.isOnline())plugin.holograms().refreshPlayer(player);}}
    private void give(Player player,Crate crate,Reward reward){if(reward.type()==RewardType.GIVE_ITEM||reward.type()==RewardType.MIXED)plugin.service().giveItem(player,reward.item(),reward.amount());else if(reward.type()==RewardType.GIVE_CLOUD&&reward.item()!=null&&!reward.item().getType().isAir())player.getWorld().dropItemNaturally(player.getLocation().add(0,1,0),reward.item().clone());if(reward.type()==RewardType.EXECUTE_COMMAND||reward.type()==RewardType.MIXED)for(String raw:reward.commands()){String command=raw.replace("{player}",player.getName()).replace("{uuid}",player.getUniqueId().toString()).replace("{crate}",crate.id());String lower=command.toLowerCase(Locale.ROOT);if(lower.startsWith("[player]")){String actual=command.substring(8).trim();Tasks.player(player,plugin,()->player.performCommand(actual));}else{String actual=lower.startsWith("[console]")?command.substring(9).trim():command;Tasks.global(plugin,()->Bukkit.dispatchCommand(Bukkit.getConsoleSender(),actual));}}plugin.service().recordWin(player,crate,reward);}
}
