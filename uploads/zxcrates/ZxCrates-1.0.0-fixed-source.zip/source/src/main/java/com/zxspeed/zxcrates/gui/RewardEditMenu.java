package com.zxspeed.zxcrates.gui;

import com.zxspeed.zxcrates.ZxCratesPlugin;
import com.zxspeed.zxcrates.model.Crate;
import com.zxspeed.zxcrates.model.Reward;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

public final class RewardEditMenu {
    public static final String PREFIX="§8Reward Edit • ";
    private final ZxCratesPlugin plugin; private final Player player; private final Crate crate; private final Reward reward;
    public RewardEditMenu(ZxCratesPlugin plugin,Player player,Crate crate,Reward reward){this.plugin=plugin;this.player=player;this.crate=crate;this.reward=reward;}
    public void open(){
        Inventory inv=Bukkit.createInventory(null,54,PREFIX+crate.id()+" • "+reward.id());
        inv.setItem(10,GuiItems.item(Material.NETHER_STAR,"&bChance","&7Chance: &f"+String.format(java.util.Locale.ROOT,"%.2f%%",reward.chance()),"&7Mode: &f"+(reward.chanceManual()?"Manual":"Automatic"),"&eClick to set manual chance","&eShift + right click: automatic distribution"));
        inv.setItem(8,GuiItems.item(Material.BOOK,"&bGUI Slot","&7Current: &f"+(reward.slot()+1),"&7Set the slot in Rewards GUI."));
        inv.setItem(12,GuiItems.item(Material.CHEST,"&bAmount","&7Current: &f"+reward.amount(),"&eClick to enter value"));
        inv.setItem(14,GuiItems.item(Material.COMMAND_BLOCK,"&bReward Type","&7Current: &f"+reward.type().name().toLowerCase(),"&eClick to cycle"));
        inv.setItem(16,reward.item()==null?GuiItems.item(Material.BARRIER,"&7Item: None"):reward.item());
        inv.setItem(28,GuiItems.item(Material.PAPER,"&bCommand","&7Commands: &f"+reward.commands().size(),"&eClick to enter command"));
        inv.setItem(30,GuiItems.item(Material.PAPER,"&fAuto Save","&7Changes save automatically."));
        inv.setItem(32,GuiItems.item(Material.RED_DYE,"&cDelete Reward","&7Delete this reward"));
        inv.setItem(49,GuiItems.item(Material.ARROW,"&eBack"));
        player.openInventory(inv);
    }
    public static boolean isTitle(String title){return title.startsWith(PREFIX);}
    public Reward reward(){return reward;} public Crate crate(){return crate;}
}
