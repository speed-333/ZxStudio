# ZxCrates 1.0.4 — Deep Regression Audit

## الحالة
**Needs Live Server Verification / Static audit passed.**

هذه النسخة تعالج مشكلتين ظهرتا في التشغيل الفعلي الذي أرسله المستخدم:

1. رسائل الدردشة كانت تعرض `&#RRGGBB` كنص خام في بعض مسارات الأوامر.
2. حالة `opening-in-progress` كانت يمكن أن تبقى عالقة بعد استثناء/فشل Async أو بعد بعض مسارات الـGUI، ما يمنع فتح Crate أخرى.
3. الـAnimation كان يستخدم `getOpenInventory()` في كل خطوة؛ إغلاق الـGUI أو تغييره أثناء الحركة كان قد يسبب كتابة على Inventory غير متوقعة أو استثناء، ومع عدم وجود completion guard قد يبقى القفل فعالًا.

## الإصلاحات الرئيسية

### 1. نظام الـAnimation
تم إعادة بناء `AnimationManager` ليستخدم Session مستقلة لكل عملية فتح:

- Inventory ثابت لكل Animation بدل إعادة أخذ Top Inventory من اللاعب في كل tick.
- `AtomicBoolean` لمنع تنفيذ `finish` أكثر من مرة.
- Watchdog لمدة 30 ثانية كحل أخير لتحرير حالة الفتح.
- جميع مراحل Animation محمية بـ `try/catch`؛ الفشل ينتقل إلى إنهاء العملية بدل ترك اللاعب مقفولًا.
- عند إغلاق/تغيير Inventory لا يحدث indexing على Inventory اللاعب الحالي.
- الأنواع المدعومة فعليًا:
  - roulette
  - spinning_items
  - progress_bar
  - item_fly_out
  - hologram_sequence
- عند انتهاء Animation يتم تشغيل صوت، ActionBar، والجائزة ثم تحرير الحالة.

### 2. سبب رسالة `already have a crate opening in progress`
تم إصلاح جميع المسارات الحساسة:

- `takeKey()` يستخدم `whenComplete` بدل `thenAccept`؛ الخطأ في قاعدة البيانات الآن يحرر الحالة.
- `PlayerQuitEvent` يحرر حالة الفتح.
- `SELECT` يحرر الحالة عند إغلاق GUI دون اختيار.
- `finishOnce()` يضمن تحرير الحالة حتى عند وجود exception.
- فشل Animation لا يترك الحالة عالقة.
- التحقق من rate-limit/cooldown أصبح قبل قفل العملية.

### 3. الألوان
`ColorUtil` يدعم:

- `&#FF0000`
- `&#C600FF`
- `&f`
- `&7`
- `&e`
- وبقية legacy codes.

تمت إزالة الاستخدامات القديمة لـ MiniMessage color syntax من ملفات المشروع.

تم أيضًا إصلاح الـGUI components التي كانت تستخدم `Component.text(...)` مع legacy section codes؛ أصبحت تستخدم `LegacyComponentSerializer.legacySection()` حتى لا يظهر النص الخام.

تمت مراجعة رسائل الأوامر التي كانت ترسل `&#RRGGBB` مباشرة إلى `sendMessage` بدون `ColorUtil`.

### 4. random / select
- `random` يستخدم weighted chance.
- `select` لا يمر عبر `roll()` إطلاقًا.
- `select` يفتح GUI اختيار الجائزة.
- المفتاح يُستهلك عند اختيار الجائزة.
- cooldown/rate-limit مطبقان أيضًا لمسار select.
- إغلاق select GUI يحرر حالة الفتح.

## الاختبارات

### Static regression
تم تشغيل فحص آلي **1000 مرة متكررة** شمل:

- توازن الأقواس/السلاسل في كل ملفات Java.
- عدم وجود `<#RRGGBB>`.
- وجود جميع أنواع Animation الخمسة.
- وجود completion guard وwatchdog.
- وجود `whenComplete` لمسار استهلاك المفتاح.
- وجود `isOpening` و`endOpening`.
- وجود الأوامر الأساسية.
- وجود `folia-supported: true`.
- وجود `offset-y: 1.2`.

**النتيجة: 1000/1000 PASS.**

### Unit smoke tests
تم تجميع وتشغيل `ColorUtil` و`ChanceCalculator` مباشرة بواسطة `javac` بدون الحاجة إلى Paper API:

- `ColorUtil`: PASS.
- `ChanceCalculator`: 100000 عملية اختيار ضمن النطاق الصحيح، PASS.

### YAML
تم تحميل كل ملفات YAML الأربعة باستخدام PyYAML بدون أخطاء:

- `config.yml`
- `lang/en.yml`
- `placeholder.yml`
- `plugin.yml`

**4/4 PASS.**

## فحص المصدر

عدد ملفات Java المفحوصة: **28**.

تم فحص:

- Animation lifecycle
- opening state
- key consumption failure path
- GUI select close path
- reward command execution
- color conversion paths
- command message paths
- Folia scheduler usage
- PDC crate item marker
- rate limit / cooldown ordering
- YAML parsing of `type`, `animation`, `slots`, hologram settings
- source packaging metadata

## تشغيل فعلي غير مثبت من داخل هذه البيئة

لا أعتبر compile/package/runtime على Paper أو Folia مثبتًا من هذه الجلسة لأن بيئة التنفيذ لا تحتوي dependencies الخاصة بـ Paper API بشكل محلي ولا تستطيع تنفيذ Maven dependency resolution خارجيًا.

لذلك لم يتم الادعاء باختبار Live Server.

## اختبار الانحدار المطلوب على السيرفر

1. `/crate edit legend` والتأكد من ظهور `Type: random` أو `select` الصحيح.
2. فتح random مرة أولى.
3. انتظار Animation حتى النهاية.
4. فتح نفس Crate مرة ثانية مباشرة بعد النهاية.
5. فتح Crate مختلفة مباشرة بعدها.
6. إغلاق Animation GUI يدويًا ثم إعادة فتح Crate.
7. فقدان/عدم وجود Key والتأكد من عدم تسجيل cooldown وعدم بقاء opening state.
8. اختبار كل Animation الخمسة.
9. اختبار Paper وFolia.
10. اختبار الرسائل التي تحتوي `&#FF0000` و`&f` و`&7` وعدم ظهور النص الخام.

## الحكم
**النسخة 1.0.4 تعالج الأسباب البرمجية التي فسرت المشاكل المبلغ عنها، ونجحت في 1000/1000 static regression iterations.**

**لا توجد شهادة production-clean قبل اختبار Paper/Folia حيًا.**


## 1.0.5 إضافة Item Lore
- `item-lore` أصبح خاصية لكل Crate ويتم حفظه في YAML وMySQL.
- يتم تطبيقه على نسخ عرض الـRewards فقط في Preview/Select/Animations/Reward menu.
- لا يتم تعديل ItemStack الأصلي المحفوظ داخل Reward.
- عند منح Reward لا يتم تمرير `item-lore` إلى اللاعب.
- تمت إضافة اختبارات isolation للتأكد من عدم تلوث ItemStack الأصلي.
