package com.zxspeed.zxcrates.util;

import org.bukkit.inventory.ItemStack;

public final class ItemSafety {
    private ItemSafety() {}

    public static boolean valid(ItemStack item, int maxBytes, int maxLoreLines) {
        if (item == null || item.getType().isAir()) return false;
        try {
            if (item.serializeAsBytes().length > maxBytes) return false;
        } catch (Throwable ignored) {
            return false;
        }
        if (item.getItemMeta() != null && item.getItemMeta().hasLore() && item.getItemMeta().getLore().size() > maxLoreLines) return false;
        return true;
    }
}
