package com.zxspeed.zxcrates.service;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public final class ChanceCalculator {
    private ChanceCalculator() {}

    /**
     * Returns the configured direct probability for a reward.
     * A chance value of 4.5 means exactly 4.5%, not a weight.
     */
    public static double effectivePercentage(List<Double> chances, int index) {
        if (chances == null || chances.isEmpty() || index < 0 || index >= chances.size()) return 0D;
        double value = chances.get(index) == null ? 0D : chances.get(index);
        if (!Double.isFinite(value)) return 0D;
        return Math.max(0D, Math.min(100D, value));
    }

    /**
     * Selects a reward using its direct percentage over a 0..100 roll.
     * Any unused percentage intentionally means that no reward is selected.
     */
    public static int pickIndex(List<Double> chances) {
        if (chances == null || chances.isEmpty() || total(chances) <= 0D) return -1;
        double roll = ThreadLocalRandom.current().nextDouble(100D);
        double cumulative = 0D;
        for (int i = 0; i < chances.size(); i++) {
            double chance = chances.get(i) == null ? 0D : chances.get(i);
            if (!Double.isFinite(chance) || chance <= 0D) continue;
            cumulative += Math.min(100D, chance);
            if (roll < cumulative) return i;
        }
        return -1;
    }

    public static double total(List<Double> chances) {
        if (chances == null) return 0D;
        double total = 0D;
        for (Double value : chances) {
            if (value != null && Double.isFinite(value)) total += Math.max(0D, Math.min(100D, value));
        }
        return total;
    }

    public static boolean validDistribution(List<Double> chances) {
        double total = total(chances);
        return total <= 100.0000000001D;
    }
}
