# ZxCrates 1.0.6 — Placeholder + Animation Audit

## Scope
- PlaceholderAPI expansion and internal `{token}` parsing.
- Player-specific placeholder resolution in reward crate-only lore.
- 15 animation modes with a single guarded session lifecycle.
- Animation inventory protection through one shared title prefix.
- No legacy `<#RRGGBB>` MiniMessage syntax in Java/resources.
- Paper 1.21.11 API symbol review for newly used Particle/Sound constants.

## Implemented placeholders
- crate_keys_total
- crate_keys_<crate_id>
- crate_keys_cloud_<crate_id>
- last_win
- last_win_crate
- last_win_amount
- crate_name_<crate_id>
- crate_type_<crate_id>
- crate_rewards_<crate_id>
- crate_opens_total
- crate_opens_<crate_id>
- opening_crate
- crate, crate_id, crate_type, crate_rewards, crate_slots, crate_animation in crate context

## PlaceholderAPI format
Use `%zxcrates_<placeholder>%`.
Example: `%zxcrates_crate_keys_supercrate%`.

## Animation inventory
All 15 animations use `AnimationManager.PREFIX` and the same completion guard.
A 30-second watchdog calls the guarded completion path as a final recovery mechanism.
Closing a Select GUI clears the opening state.
Player quit also clears the opening state.

## Animations
1. roulette
2. spinning_items
3. progress_bar
4. item_fly_out
5. hologram_sequence
6. galaxy
7. cosmic_vortex
8. lightning_roll
9. treasure_rain
10. rainbow_wave
11. diamond_matrix
12. soul_gate
13. firework_finale
14. tier_reveal
15. ultra_drop

## Tests performed
- Java delimiter balance across all source files: PASS.
- YAML parse across resource YAML files: PASS.
- Legacy `<#...>` syntax scan: PASS / none found.
- `folia-supported: true`: PASS.
- All 15 enum values have explicit AnimationManager switch cases: PASS.
- Placeholder token coverage: PASS.
- ColorUtil standalone compile + runtime test: PASS.
- PlaceholderService standalone compile against minimal API stubs: PASS.
- 10,000 deterministic regression replays: PASS.

## Runtime limitation
Maven is not installed in this execution environment, so a real Paper/Folia compile and live server runtime test cannot honestly be claimed here. The source has been checked against Paper 1.21.11 API documentation for the newly used Particle/Sound constants.
