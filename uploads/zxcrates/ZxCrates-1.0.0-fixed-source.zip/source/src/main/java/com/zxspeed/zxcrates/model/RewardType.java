package com.zxspeed.zxcrates.model;

public enum RewardType { GIVE_ITEM, GIVE_CLOUD, EXECUTE_COMMAND, MIXED }
