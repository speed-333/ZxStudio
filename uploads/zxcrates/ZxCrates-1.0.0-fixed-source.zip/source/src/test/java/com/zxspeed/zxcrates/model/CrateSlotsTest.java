package com.zxspeed.zxcrates.model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class CrateSlotsTest {
    @Test void acceptsValidRows() { Crate c = new Crate("x"); for (int n : new int[]{9,18,27,36,45,54}) { c.slots(n); assertEquals(n, c.slots()); } }
    @Test void normalizesInvalidRows() { Crate c = new Crate("x"); c.slots(10); assertEquals(9,c.slots()); c.slots(53); assertEquals(54,c.slots()); }
    @Test void defaultsHologramOffsetToTwelve() { assertEquals(1.2D, new Crate("x").hologramOffsetY(), 0.0001D); }
}
