package com.zxspeed.zxcrates;

import com.zxspeed.zxcrates.command.CrateCommand;
import com.zxspeed.zxcrates.db.MySqlRepository;
import com.zxspeed.zxcrates.gui.EditorListener;
import com.zxspeed.zxcrates.listener.CrateListener;
import com.zxspeed.zxcrates.listener.ChatInputListener;
import com.zxspeed.zxcrates.placeholder.ZxPlaceholder;
import com.zxspeed.zxcrates.placeholder.PlaceholderService;
import com.zxspeed.zxcrates.service.CrateRepository;
import com.zxspeed.zxcrates.service.CrateService;
import com.zxspeed.zxcrates.service.HologramManager;
import com.zxspeed.zxcrates.service.KeyAllManager;
import com.zxspeed.zxcrates.storage.FlatFileRepository;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class ZxCratesPlugin extends JavaPlugin {
    public enum InputType {
        CRATE_DISPLAY_NAME, OPEN_PERMISSION, COOLDOWN, CRATE_SLOTS, REWARD_CHANCE, REWARD_AMOUNT, REWARD_COMMAND, KEY_DISPLAY_NAME
    }

    public record InputRequest(InputType type, String crateId, int rewardId) {}

    private ExecutorService io;
    private CrateRepository repository;
    private CrateService service;
    private MySqlRepository mysql;
    private HologramManager holograms;
    private com.zxspeed.zxcrates.service.AnimationManager animations;
    private KeyAllManager keyAll;
    private PlaceholderService placeholders;
    private final Map<UUID, String> bindRequests = new ConcurrentHashMap<>();
    private final Map<UUID, InputRequest> inputRequests = new ConcurrentHashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        saveResource("placeholder.yml", false);
        saveResource("lang/en.yml", false);
        saveResource("keyall.yml", false);

        int poolSize = Math.max(2, getConfig().getInt("storage.mysql.pool-size", 10));
        io = Executors.newFixedThreadPool(poolSize, r -> {
            Thread thread = new Thread(r, "ZxCrates-IO");
            thread.setDaemon(true);
            return thread;
        });

        try {
            if (getConfig().getString("storage.type", "flatfile").equalsIgnoreCase("mysql")) {
                mysql = new MySqlRepository(
                        getConfig().getString("storage.mysql.host", "localhost"),
                        getConfig().getInt("storage.mysql.port", 3306),
                        getConfig().getString("storage.mysql.database", "zxcrates"),
                        getConfig().getString("storage.mysql.username", "root"),
                        getConfig().getString("storage.mysql.password", ""),
                        getConfig().getInt("storage.mysql.pool-size", 10),
                        getConfig().getLong("storage.mysql.connection-timeout-ms", 5000),
                        io);
                mysql.migrate();
                repository = mysql;
            } else {
                repository = new FlatFileRepository(getDataFolder(), io);
            }
            service = new CrateService(this, repository, getConfig().getLong("security.open-rate-limit-ms", 250));
            service.load().join();
            holograms = new HologramManager(this);
            animations = new com.zxspeed.zxcrates.service.AnimationManager(this);
            placeholders = new PlaceholderService(this);
            keyAll = new KeyAllManager(this);
            keyAll.loadAndStart();
            holograms.refreshAll(service.all());
        } catch (Throwable throwable) {
            getLogger().severe("Failed to initialize ZxCrates storage: " + throwable.getMessage());
            throw throwable;
        }

        CrateCommand command = new CrateCommand(this);
        getCommand("crates").setExecutor(command);
        getCommand("crates").setTabCompleter(command);
        getCommand("zxcrates").setExecutor(command);
        getCommand("zxcrates").setTabCompleter(command);

        getServer().getPluginManager().registerEvents(new CrateListener(this), this);
        getServer().getPluginManager().registerEvents(new ChatInputListener(this), this);
        getServer().getPluginManager().registerEvents(new EditorListener(this), this);
        if (getServer().getPluginManager().getPlugin("PlaceholderAPI") != null &&
                getConfig().getBoolean("placeholders.enabled", true)) {
            new ZxPlaceholder(this).register();
        }

        getLogger().info("ZxCrates enabled successfully.");
    }

    @Override
    public void onDisable() {
        if (keyAll != null) keyAll.stop();
        if (holograms != null) holograms.onDisable();
        if (mysql != null) mysql.close();
        if (io != null) io.shutdownNow();
    }

    public CrateService service() { return service; }
    public Map<UUID, String> bindRequests() { return bindRequests; }
    public HologramManager holograms() { return holograms; }
    public com.zxspeed.zxcrates.service.AnimationManager animations() { return animations; }
    public PlaceholderService placeholders() { return placeholders; }
    public KeyAllManager keyAll() { return keyAll; }

    public void requestInput(org.bukkit.entity.Player player, InputType type, String crateId, int rewardId) {
        inputRequests.put(player.getUniqueId(), new InputRequest(type, crateId, rewardId));
    }

    public InputRequest consumeInput(UUID uuid) {
        return inputRequests.remove(uuid);
    }

    public void clearInput(UUID uuid) {
        inputRequests.remove(uuid);
    }
}
