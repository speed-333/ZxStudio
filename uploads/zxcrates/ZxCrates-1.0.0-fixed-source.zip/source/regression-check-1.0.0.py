from pathlib import Path
import yaml, re

ROOT=Path(__file__).parent
fail=[]

def require(cond,msg):
    if not cond: fail.append(msg)

config=yaml.safe_load((ROOT/'src/main/resources/config.yml').read_text(encoding='utf-8'))
defaults=config['crate-defaults']
require(defaults['slots']==45, 'crate-defaults.slots must be 45')
expected_holo='''&a%zxcrates_crate% Crate
&r
&a▶ &fHit To &aPreview &a!
&a▶ &fUse Key To &aOpen &a!
&fYou Have &a%zxcrates_crate_keys_crateid%
&f%zxcrates_crate% &aKey!
&r
&fSelector Type: &aRandom
&fBuy Keys! &a/Store'''
require(defaults['hologram']['text'].rstrip('\n')==expected_holo, 'default hologram text mismatch')
require(defaults['item-lore']==['','&8&m----------------','&fᴄʜᴀɴᴄᴇ: &e%reward_chance%','&fʏᴏᴜʀ ᴋᴇʏѕ: &e%zxcrates_crate_keys_crateid%','&8&m----------------'], 'default item lore mismatch')

chance=(ROOT/'src/main/java/com/zxspeed/zxcrates/service/ChanceCalculator.java').read_text(encoding='utf-8')
require('not a weight' in chance, 'direct-chance documentation missing')
require('nextDouble(100D)' in chance, 'direct 0..100 roll missing')
require('weight / total' not in chance, 'weight normalization remains')

placeholder=(ROOT/'src/main/java/com/zxspeed/zxcrates/placeholder/PlaceholderService.java').read_text(encoding='utf-8')
require('reward.chance()' in placeholder and 'effectivePercentage' not in placeholder, 'reward placeholder still normalizes chance')

def strip_java_literals_comments(text):
    out=[]; i=0; state='code'
    while i < len(text):
        c=text[i]; n=text[i+1] if i+1<len(text) else ''
        if state=='code':
            if c=='/' and n=='/': state='line'; out.extend('  '); i+=2; continue
            if c=='/' and n=='*': state='block'; out.extend('  '); i+=2; continue
            if c=='\"': state='string'; out.append(' '); i+=1; continue
            if c=="'": state='char'; out.append(' '); i+=1; continue
            out.append(c); i+=1
        elif state=='string':
            if c=='\\': out.extend('  '); i+=2
            elif c=='\"': state='code'; out.append(' '); i+=1
            else: out.append(' '); i+=1
        elif state=='char':
            if c=='\\': out.extend('  '); i+=2
            elif c=="'": state='code'; out.append(' '); i+=1
            else: out.append(' '); i+=1
        elif state=='line':
            if c=='\n': state='code'; out.append('\n')
            else: out.append(' ')
            i+=1
        else:
            if c=='*' and n=='/': state='code'; out.extend('  '); i+=2
            else:
                out.append('\n' if c=='\n' else ' '); i+=1
    return ''.join(out)

for p in ROOT.joinpath('src/main/java').rglob('*.java'):
    s=strip_java_literals_comments(p.read_text(encoding='utf-8'))
    require(s.count('{')==s.count('}'), f'brace-count mismatch: {p}')
    require(s.count('(')==s.count(')'), f'paren-count mismatch: {p}')
    require(s.count('[')==s.count(']'), f'bracket-count mismatch: {p}')

reward_gui=(ROOT/'src/main/java/com/zxspeed/zxcrates/gui/RewardEditMenu.java').read_text(encoding='utf-8')
reward_menu=(ROOT/'src/main/java/com/zxspeed/zxcrates/gui/RewardMenu.java').read_text(encoding='utf-8')
require('&7Weight:' not in reward_gui+reward_menu, 'weight label remains in reward UI')
require('&7Chance:' in reward_gui+reward_menu, 'chance label missing from reward UI')

# Check italic prevention exists on every direct Adventure component construction in plugin GUIs.
alljava='\n'.join(p.read_text(encoding='utf-8') for p in ROOT.joinpath('src/main/java').rglob('*.java'))
require('TextDecoration.ITALIC, false' in alljava, 'italic=false safeguard missing')

# Verify version metadata.
pom=(ROOT/'pom.xml').read_text(encoding='utf-8')
plugin=(ROOT/'src/main/resources/plugin.yml').read_text(encoding='utf-8')
require('<version>1.0.0</version>' in pom.split('<dependencies>',1)[0], 'pom project version is not 1.0.0')
require('<finalName>ZxCrates-1.0.0</finalName>' in pom, 'finalName is not 1.0.0')
require('version: 1.0.0' in plugin, 'plugin.yml version is not 1.0.0')

if fail:
    print('FAIL')
    for x in fail: print(x)
    raise SystemExit(1)
print('PASS: current release regression checks')
