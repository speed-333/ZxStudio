package com.zxspeed.zxcrates.service;

import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class ChanceCalculatorTest {
    @Test void automaticChancesSplitRemainder() {
        com.zxspeed.zxcrates.model.Crate crate = new com.zxspeed.zxcrates.model.Crate("test");
        crate.addReward(new com.zxspeed.zxcrates.model.Reward(1, 0D, com.zxspeed.zxcrates.model.RewardType.GIVE_ITEM, null, 1, java.util.List.of()));
        crate.addReward(new com.zxspeed.zxcrates.model.Reward(2, 0D, com.zxspeed.zxcrates.model.RewardType.GIVE_ITEM, null, 1, java.util.List.of()));
        crate.addReward(new com.zxspeed.zxcrates.model.Reward(3, 0D, com.zxspeed.zxcrates.model.RewardType.GIVE_ITEM, null, 1, java.util.List.of()));
        assertEquals(100D / 3D, crate.rewards().get(0).chance(), 1e-12);
        assertEquals(100D / 3D, crate.rewards().get(1).chance(), 1e-12);
        assertEquals(100D / 3D, crate.rewards().get(2).chance(), 1e-12);
        assertTrue(crate.setManualRewardChance(1, 10D));
        assertEquals(10D, crate.findReward(1).orElseThrow().chance(), 1e-12);
        assertEquals(45D, crate.findReward(2).orElseThrow().chance(), 1e-12);
        assertEquals(45D, crate.findReward(3).orElseThrow().chance(), 1e-12);
        crate.makeRewardAutomatic(1);
        assertEquals(100D / 3D, crate.findReward(1).orElseThrow().chance(), 1e-12);
    }

    @Test void invalidInput(){ assertEquals(-1, ChanceCalculator.pickIndex(List.of())); }
    @Test void chanceIsDirectPercentage(){ assertEquals(4.5D, ChanceCalculator.effectivePercentage(List.of(4.5D, 95.5D), 0), 1e-12); }
    @Test void zeroChanceIsNeverSelected(){ for(int i=0;i<1000;i++) assertNotEquals(0, ChanceCalculator.pickIndex(List.of(0D,100D))); }
    @Test void directDistributionAcceptsPartialTotal(){ assertTrue(ChanceCalculator.validDistribution(List.of(4.5D, 5.5D))); }
    @Test void overHundredDistributionIsRejected(){ assertFalse(ChanceCalculator.validDistribution(List.of(60D,50D))); }
}
