package com.zxspeed.zxcrates.util;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class HologramVisibilityTest {
    @Test
    void exactBoundaryAndOutsideAreStable() {
        double[] distances = {
                0, 1, 2, 3, 4, 5, 8, 15, 16, 16.5, 24, 31, 31.999, 32, 32.001,
                40, 48, 49.999, 50, 63.999, 64, 64.001, 70, 96, 127.999, 128, 128.001
        };
        for (double distance : distances) {
            assertEquals(distance <= 32.0, HologramVisibility.isVisible(distance, 0, 0, 32), "x=" + distance);
            assertEquals(distance <= 64.0, HologramVisibility.isVisible(distance, 0, 0, 64), "x64=" + distance);
        }
    }

    @Test
    void threeDimensionsUseSquaredDistanceWithoutSqrt() {
        assertTrue(HologramVisibility.isVisible(16, 24, 0, 32)); // exactly 28.844...
        assertFalse(HologramVisibility.isVisible(19.2, 19.2, 19.2, 32)); // exactly 33.255..., outside
        assertFalse(HologramVisibility.isVisible(19.2, 19.2, 19.2, 33));
        assertTrue(HologramVisibility.isVisible(19.05255888325765, 19.05255888325765, 19.05255888325765, 33));
    }

    @Test
    void zeroAndInvalidRangesAreHidden() {
        assertFalse(HologramVisibility.isVisible(0, 0, 0, 0));
        assertFalse(HologramVisibility.isVisible(1, 0, 0, -1));
        assertFalse(HologramVisibility.isVisible(1, 0, 0, Double.NaN));
        assertFalse(HologramVisibility.isVisible(1, 0, 0, Double.POSITIVE_INFINITY));
        assertFalse(HologramVisibility.isVisible(Double.NaN, 0, 0, 32));
    }

    @Test
    void stress1000BoundarySamples() {
        for (int i = 0; i < 1000; i++) {
            double offset = (i + 1) / 1001.0;
            double inside = 32.0 - offset;
            double outside = 32.0 + offset;
            assertTrue(HologramVisibility.isVisible(inside, 0, 0, 32), "inside=" + inside);
            assertFalse(HologramVisibility.isVisible(outside, 0, 0, 32), "outside=" + outside);
        }
    }
}
