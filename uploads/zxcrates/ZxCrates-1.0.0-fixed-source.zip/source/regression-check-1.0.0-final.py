from pathlib import Path
import re, zipfile, hashlib, yaml

ROOT = Path(__file__).parent
src = ROOT / 'src/main/java'
config = yaml.safe_load((ROOT/'src/main/resources/config.yml').read_text(encoding='utf-8'))
holo = (src/'com/zxspeed/zxcrates/service/HologramManager.java').read_text(encoding='utf-8')
cmd = (src/'com/zxspeed/zxcrates/command/CrateCommand.java').read_text(encoding='utf-8')
listener = (src/'com/zxspeed/zxcrates/listener/CrateListener.java').read_text(encoding='utf-8')
plugin = (ROOT/'src/main/resources/plugin.yml').read_text(encoding='utf-8')
pom = (ROOT/'pom.xml').read_text(encoding='utf-8')

checks = []
def ok(name, condition):
    checks.append((name, bool(condition)))

ok('version pom 1.0.0', '<version>1.0.0</version>' in pom)
ok('plugin version 1.0.0', re.search(r'^version:\s*1\.0\.0\s*$', plugin, re.M))
ok('transparent default configured', config['crate-defaults']['hologram']['background'] is False)
ok('transparent background uses alpha zero', 'Color.fromARGB(0, 0, 0, 0)' in holo)
ok('default background clears custom override', 'setBackgroundColor(crate.hologramBackground() ? null :' in holo)
ok('default background flag still preserved', 'setDefaultBackground(crate.hologramBackground())' in holo)
ok('command hologram exists', 'case "hologram" ->' in cmd)
ok('default mode accepted', 'mode.equals("default")' in cmd)
ok('transparent mode accepted', 'mode.equals("transparent")' in cmd)
ok('tab complete background', 'List.of("background", "view_distance")' in cmd)
ok('tab complete modes', 'List.of("default", "transparent")' in cmd)
ok('player move hook exists', 'onPlayerMove(Player player)' in holo and 'hologramMove(PlayerMoveEvent event)' in listener)
ok('event-driven visibility', 'private void updateVisibility()' not in holo)
ok('static chunk index', 'staticChunkIndex' in holo and 'chunkKey(' in holo)
ok('no global player x hologram visibility scan', 'Bukkit.getOnlinePlayers()' not in holo)
ok('Folia player scheduler used', 'player.getScheduler().run' in holo)
ok('dynamic update remains bounded', 'runAtFixedRate(plugin, task -> updateDynamicDisplays(), 10L, 10L)' in holo)
ok('hologram command is registered through crates command', 'commands:\n  crates:' in plugin)

# Validate that the command syntax is exactly the requested shape.
ok('command syntax present', '/crate hologram <crateid> background <default|transparent>' in cmd)

# Lightweight Java delimiter check ignoring strings/comments.
def strip_java(text):
    out=[]; i=0; state='code'
    while i < len(text):
        if state=='code':
            if text.startswith('//', i): state='line'; out.extend('  '); i+=2; continue
            if text.startswith('/*', i): state='block'; out.extend('  '); i+=2; continue
            if text[i] == '"': state='string'; out.append(' '); i+=1; continue
            if text[i] == "'": state='char'; out.append(' '); i+=1; continue
            out.append(text[i]); i+=1
        elif state=='line':
            if text[i]=='\n': state='code'; out.append('\n')
            else: out.append(' ')
            i+=1
        elif state=='block':
            if text.startswith('*/', i): state='code'; out.extend('  '); i+=2
            else:
                out.append('\n' if text[i]=='\n' else ' '); i+=1
        elif state in ('string','char'):
            quote='"' if state=='string' else "'"
            if text[i]=='\\': out.extend('  '); i+=2
            elif text[i]==quote: state='code'; out.append(' '); i+=1
            else: out.append('\n' if text[i]=='\n' else ' '); i+=1
    return ''.join(out)

for f in [src/'com/zxspeed/zxcrates/service/HologramManager.java', src/'com/zxspeed/zxcrates/command/CrateCommand.java', src/'com/zxspeed/zxcrates/listener/CrateListener.java']:
    cleaned = strip_java(f.read_text(encoding='utf-8'))
    ok(f'{f.name} balanced braces', cleaned.count('{') == cleaned.count('}'))

for name, passed in checks:
    print(('PASS' if passed else 'FAIL') + ' - ' + name)

fails = [n for n,p in checks if not p]
print(f'CHECKS={len(checks)} FAILURES={len(fails)}')
if fails:
    raise SystemExit(1)
