package com.zxspeed.zxcrates.gui;

import com.zxspeed.zxcrates.ZxCratesPlugin;
import com.zxspeed.zxcrates.model.*;
import com.zxspeed.zxcrates.util.ItemSafety;
import com.zxspeed.zxcrates.util.Tasks;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

import java.util.*;

public final class EditorListener implements Listener {
    private static final String SELECT_TITLE = "§8Select Reward";
    private final ZxCratesPlugin plugin;
    private final Map<UUID, Integer> selectedReward = new java.util.concurrent.ConcurrentHashMap<>();
    private final Set<UUID> confirming = java.util.concurrent.ConcurrentHashMap.newKeySet();

    public EditorListener(ZxCratesPlugin plugin) { this.plugin = plugin; }

    @EventHandler
    public void click(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        String title = event.getView().getTitle();
        int raw = event.getRawSlot();
        int topSize = event.getView().getTopInventory().getSize();

        if (CratePreviewMenu.isTitle(title)) { event.setCancelled(true); return; }
        if (SELECT_TITLE.equals(title)) { handleSelect(event, player, raw, topSize); return; }
        if (CrateMenu.isTitle(title)) { event.setCancelled(true); handleCrates(player, event, raw); return; }
        if (CrateEditorMenu.PREFIX.equals(title)) {
            event.setCancelled(true);
            if (raw >= topSize) {
                Crate crate = CrateEditorMenu.crateFor(event.getView().getTopInventory());
                if (crate != null && event.getCurrentItem() != null && event.getCurrentItem().getType().isBlock()) {
                    setDisplayBlockFromItem(player, crate, event.getCurrentItem());
                }
                return;
            }
            handleEditor(player, event, raw);
            return;
        }
        if (KeySettingsMenu.isTitle(title)) { event.setCancelled(true); handleKeys(player, event, raw); return; }
        if (RewardMenu.isTitle(title)) { handleRewards(event, player, raw, topSize); return; }
        if (RewardEditMenu.isTitle(title)) { event.setCancelled(true); handleRewardEdit(player, event, raw, title); }
    }

    private void handleSelect(InventoryClickEvent event, Player player, int raw, int topSize) {
        event.setCancelled(true);
        String crateId = plugin.service().openingCrate(player.getUniqueId());
        Crate crate = plugin.service().get(crateId).orElse(null);
        if (crate == null) { player.closeInventory(); plugin.service().endOpening(player.getUniqueId()); return; }
        int confirmSlot = Math.max(0, topSize - 1);
        if (raw < 0 || raw >= topSize) return;

        if (raw == confirmSlot) {
            if (confirming.contains(player.getUniqueId())) return;
            Integer rewardId = selectedReward.get(player.getUniqueId());
            Reward reward = rewardId == null ? null : crate.findReward(rewardId).orElse(null);
            if (reward == null) return;
            confirming.add(player.getUniqueId());
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.75f, 1.15f);
            player.closeInventory();
            plugin.service().takeKey(player, crate).whenComplete((ok, error) -> Tasks.player(player, plugin, () -> {
                if (error != null || !Boolean.TRUE.equals(ok)) {
                    confirming.remove(player.getUniqueId());
                    selectedReward.remove(player.getUniqueId());
                    plugin.service().endOpening(player.getUniqueId());
                    return;
                }
                plugin.service().markOpened(player, crate);
                giveSelectedReward(player, crate, reward);
                selectedReward.remove(player.getUniqueId());
                confirming.remove(player.getUniqueId());
                plugin.service().endOpening(player.getUniqueId());
                if (plugin.holograms() != null) plugin.holograms().refreshPlayer(player);
            }));
            return;
        }

        if (raw >= confirmSlot) return;
        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getType().isAir() || clicked.getType() == Material.BLACK_STAINED_GLASS_PANE) return;
        var meta = clicked.getItemMeta();
        if (meta == null) return;
        Integer rewardId = meta.getPersistentDataContainer().get(new NamespacedKey(plugin, "select-reward-id"), PersistentDataType.INTEGER);
        if (rewardId == null) return;
        Reward reward = crate.findReward(rewardId).orElse(null);
        if (reward == null) return;

        UUID uuid = player.getUniqueId();
        Integer previousId = selectedReward.put(uuid, reward.id());
        if (previousId != null && previousId != reward.id()) {
            Reward previous = crate.findReward(previousId).orElse(null);
            if (previous != null) {
                int previousSlot = rewardSlot(crate, previous, confirmSlot);
                if (previousSlot >= 0) event.getView().getTopInventory().setItem(previousSlot, selectionIcon(player, crate, previous));
            }
        }

        event.getView().getTopInventory().setItem(raw, GuiItems.item(
                Material.LIME_STAINED_GLASS_PANE,
                "&aSelected Reward",
                "&7Reward: &f" + reward.id(),
                "&ePress the green button below to claim it."));
        event.getView().getTopInventory().setItem(confirmSlot,
                GuiItems.item(Material.LIME_DYE, "&aConfirm Reward", "&7Selected: &f" + reward.id(), "&eClick to receive it."));
        player.playSound(player.getLocation(), Sound.ENTITY_FISH_SWIM, 0.55f, 1.55f);
    }


    private ItemStack selectionIcon(Player player, Crate crate, Reward reward) {
        ItemStack item = reward.item() == null ? new ItemStack(Material.NETHER_STAR)
                : ItemLoreUtil.withCrateLore(reward.item(), crate, reward, player, plugin.placeholders());
        item.setAmount(Math.min(Math.max(1, reward.amount()), item.getMaxStackSize()));
        var meta = item.getItemMeta();
        if (meta != null) {
            meta.getPersistentDataContainer().set(new NamespacedKey(plugin, "select-reward-id"),
                    PersistentDataType.INTEGER, reward.id());
            item.setItemMeta(meta);
        }
        return item;
    }

    private int rewardSlot(Crate crate, Reward reward, int confirmSlot) {
        int slot = reward.slot() >= 0 ? reward.slot() : crate.rewards().indexOf(reward);
        return slot >= 0 && slot < confirmSlot ? slot : -1;
    }

    private void handleCrates(Player player, InventoryClickEvent event, int raw) {
        int page = CrateMenu.pageFromTitle(event.getView().getTitle());
        if (raw == 48) { new CrateMenu(plugin, player, Math.max(0, page - 1)).open(); return; }
        if (raw == 50) { new CrateMenu(plugin, player, page + 1).open(); return; }
        if (raw < 0 || raw >= 45) return;
        ItemStack item = event.getCurrentItem();
        if (item == null || item.getType().isAir() || item.getItemMeta() == null) return;
        String id = item.getItemMeta().getPersistentDataContainer().get(new NamespacedKey(plugin, "crate-id"), PersistentDataType.STRING);
        if (id == null) return;
        plugin.service().get(id).ifPresent(crate -> {
            if (event.isRightClick()) plugin.bindRequests().put(player.getUniqueId(), crate.id());
            else new CrateEditorMenu(plugin, player, crate).open();
        });
    }

    private void handleEditor(Player player, InventoryClickEvent event, int raw) {
        Crate crate = CrateEditorMenu.crateFor(event.getView().getTopInventory());
        if (crate == null) return;
        switch (raw) {
            case 10 -> {
                if (event.isRightClick()) {
                    crate.type(crate.type() == CrateType.RANDOM ? CrateType.SELECT : CrateType.RANDOM);
                    saveAndOpen(player, crate);
                } else {
                    plugin.requestInput(player, ZxCratesPlugin.InputType.CRATE_DISPLAY_NAME, crate.id(), -1);
                    player.closeInventory();
                    player.sendMessage("§eType the new display name in chat.");
                }
            }
            case 12 -> setDisplayBlockFromItem(player, crate, event.getCursor());
            case 14 -> new RewardMenu(plugin, player, crate).open();
            case 16 -> {
                AnimationType[] values = AnimationType.values();
                crate.animation(values[(crate.animation().ordinal() + 1) % values.length]);
                saveAndOpen(player, crate);
            }
            case 28 -> new KeySettingsMenu(plugin, player, crate).open();
            case 30 -> {
                plugin.requestInput(player, ZxCratesPlugin.InputType.OPEN_PERMISSION, crate.id(), -1);
                player.closeInventory();
                player.sendMessage("§eType permission or none.");
            }
            case 32 -> {
                plugin.requestInput(player, ZxCratesPlugin.InputType.COOLDOWN, crate.id(), -1);
                player.closeInventory();
                player.sendMessage("§eType cooldown seconds.");
            }
            case 36 -> {
                plugin.requestInput(player, ZxCratesPlugin.InputType.CRATE_SLOTS, crate.id(), -1);
                player.closeInventory();
                player.sendMessage("§eType GUI slots: 9, 18, 27, 36, 45 or 54.");
            }
            case 38 -> {
                crate.hologramEnabled(!crate.hologramEnabled());
                plugin.service().save(crate);
                if (plugin.holograms() != null) plugin.holograms().refresh(crate);
                new CrateEditorMenu(plugin, player, crate).open();
            }
            case 39 -> {
                crate.hologramBackground(!crate.hologramBackground());
                plugin.service().save(crate);
                if (plugin.holograms() != null) plugin.holograms().refresh(crate);
                new CrateEditorMenu(plugin, player, crate).open();
            }
            case 49 -> new CrateMenu(plugin, player).open();
            default -> { }
        }
    }

    private void saveAndOpen(Player player, Crate crate) { plugin.service().save(crate); new CrateEditorMenu(plugin, player, crate).open(); }

    private void setDisplayBlockFromItem(Player player, Crate crate, ItemStack source) {
        if (source == null || source.getType().isAir() || !source.getType().isBlock()) {
            source = player.getInventory().getItemInMainHand();
        }
        if (source == null || source.getType().isAir() || !source.getType().isBlock()) {
            player.sendMessage("§cSelect a block from your inventory or hold one in your hand.");
            return;
        }
        crate.blockMaterial(source.getType());
        saveAndOpen(player, crate);
        player.sendMessage("§aDisplay Block changed to §f" + source.getType().name() + "§a.");
    }

    private void handleKeys(Player player, InventoryClickEvent event, int raw) {
        Crate crate = KeySettingsMenu.crateFor(event.getView().getTopInventory());
        if (crate == null) return;
        switch (raw) {
            case 10 -> {
                crate.keyDelivery(crate.isItemKey() ? "cloud" : "item");
                plugin.service().save(crate);
                new KeySettingsMenu(plugin, player, crate).open();
            }
            case 12 -> {
                plugin.requestInput(player, ZxCratesPlugin.InputType.KEY_DISPLAY_NAME, crate.id(), -1);
                player.closeInventory();
                player.sendMessage("§eType the new key name in chat.");
            }
            case 14 -> {
                ItemStack source = player.getItemOnCursor();
                if (source == null || source.getType().isAir()) source = player.getInventory().getItemInMainHand();
                if (source == null || source.getType().isAir()) { player.sendMessage("§cHold the desired key item in your cursor or main hand."); return; }
                if (!ItemSafety.valid(source, plugin.getConfig().getInt("security.max-item-bytes", 16384), plugin.getConfig().getInt("security.max-lore-lines", 64))) { player.sendMessage("§cThis item cannot be used as a key."); return; }
                crate.keyItem(source.clone());
                plugin.service().save(crate);
                new KeySettingsMenu(plugin, player, crate).open();
            }
            case 16 -> {
                crate.keyStacked(!crate.keyStacked());
                plugin.service().save(crate);
                new KeySettingsMenu(plugin, player, crate).open();
            }
            case 49 -> new CrateEditorMenu(plugin, player, crate).open();
            default -> { }
        }
    }

    private void handleRewards(InventoryClickEvent event, Player player, int raw, int topSize) {
        Crate crate = plugin.service().get(RewardMenu.pageFromTitle(event.getView().getTitle()).crateId()).orElse(null);
        if (crate == null) { event.setCancelled(true); return; }
        if (raw == 46) { event.setCancelled(true); importEntireInventory(player, crate); return; }
        if (raw == 49) { event.setCancelled(true); if (event.isRightClick()) { while (!crate.rewards().isEmpty()) crate.removeReward(crate.rewards().size() - 1); plugin.service().save(crate); new RewardMenu(plugin, player, crate).open(); } return; }
        if (raw == 53) { event.setCancelled(true); new CrateEditorMenu(plugin, player, crate).open(); return; }

        if (raw >= topSize) {
            event.setCancelled(true);
            ItemStack clicked = event.getCurrentItem();
            ItemStack cursor = event.getCursor();
            if ((cursor == null || cursor.getType().isAir()) && clicked != null && !clicked.getType().isAir()) player.setItemOnCursor(clicked.clone());
            return;
        }
        if (raw < 0 || raw >= 45) { event.setCancelled(true); return; }

        event.setCancelled(true);
        if (crate.type() == CrateType.SELECT && raw == crate.slots() - 1) return;
        ItemStack cursor = event.getCursor();
        if (cursor != null && !cursor.getType().isAir()) {
            importToSlot(player, cursor, crate, raw);
            player.setItemOnCursor(null);
            return;
        }
        Reward reward = findRewardAtSlot(crate, raw);
        if (reward == null) return;
        if (event.isShiftClick() && event.isRightClick()) removeReward(player, crate, reward);
        else new RewardEditMenu(plugin, player, crate, reward).open();
    }

    private void importEntireInventory(Player player, Crate crate) {
        int limit = Math.min(45, crate.slots());
        List<Reward> backup = new ArrayList<>(crate.rewards());
        for (int i = crate.rewards().size() - 1; i >= 0; i--) crate.removeReward(i);
        for (int playerSlot = 9; playerSlot < 36; playerSlot++) {
            int slot = playerSlot - 9;
            if (slot >= limit) break;
            copyInventorySlot(crate, slot, player.getInventory().getItem(playerSlot));
        }
        for (int playerSlot = 0; playerSlot < 9; playerSlot++) {
            int slot = 36 + playerSlot;
            if (slot >= limit) break;
            copyInventorySlot(crate, slot, player.getInventory().getItem(playerSlot));
        }
        plugin.service().save(crate).whenComplete((v, error) -> Tasks.player(player, plugin, () -> {
            if (error != null) {
                while (!crate.rewards().isEmpty()) crate.removeReward(crate.rewards().size() - 1);
                backup.forEach(crate::addReward);
            }
            new RewardMenu(plugin, player, crate).open();
        }));
    }

    private void copyInventorySlot(Crate crate, int slot, ItemStack item) {
        if (item == null || item.getType().isAir()) return;
        if (crate.type() == CrateType.SELECT && slot == crate.slots() - 1) return;
        if (!ItemSafety.valid(item, plugin.getConfig().getInt("security.max-item-bytes", 16384), plugin.getConfig().getInt("security.max-lore-lines", 64))) return;
        crate.addReward(new Reward(nextRewardId(crate), slot, 1.0D, RewardType.GIVE_ITEM, item.clone(), item.getAmount(), List.of()));
    }

    private void importToSlot(Player player, ItemStack source, Crate crate, int slot) {
        if (crate.type() == CrateType.SELECT && slot == crate.slots() - 1) return;
        Reward existing = findRewardAtSlot(crate, slot);
        if (existing != null) removeRewardNoSave(crate, existing);
        Reward reward = new Reward(nextRewardId(crate), slot, 1.0D, RewardType.GIVE_ITEM, source.clone(), source.getAmount(), List.of());
        crate.addReward(reward);
        plugin.service().save(crate).whenComplete((v, error) -> Tasks.player(player, plugin, () -> {
            if (error != null) { removeRewardNoSave(crate, reward); if (existing != null) crate.addReward(existing); }
            new RewardMenu(plugin, player, crate).open();
        }));
    }

    private Reward findRewardAtSlot(Crate crate, int slot) {
        return crate.rewards().stream().filter(r -> (r.slot() >= 0 ? r.slot() : crate.rewards().indexOf(r)) == slot).findFirst().orElse(null);
    }
    private void removeReward(Player player, Crate crate, Reward reward) { removeRewardNoSave(crate, reward); plugin.service().save(crate); new RewardMenu(plugin, player, crate).open(); }
    private void removeRewardNoSave(Crate crate, Reward reward) { for (int i = 0; i < crate.rewards().size(); i++) if (crate.rewards().get(i).id() == reward.id()) { crate.removeReward(i); break; } }
    private int nextRewardId(Crate crate) { return crate.rewards().stream().mapToInt(Reward::id).max().orElse(0) + 1; }

    private void handleRewardEdit(Player player, InventoryClickEvent event, int raw, String title) {
        String rest = title.substring(RewardEditMenu.PREFIX.length());
        int split = rest.lastIndexOf(" • "); if (split <= 0) return;
        String crateId = rest.substring(0, split); int rewardId;
        try { rewardId = Integer.parseInt(rest.substring(split + 3)); } catch (NumberFormatException ex) { return; }
        Crate crate = plugin.service().get(crateId).orElse(null); if (crate == null) return;
        Reward reward = crate.findReward(rewardId).orElse(null); if (reward == null) return;
        switch (raw) {
            case 10 -> {
                if (event.isRightClick() && event.isShiftClick()) {
                    crate.makeRewardAutomatic(reward.id());
                    plugin.service().save(crate);
                    new RewardEditMenu(plugin, player, crate, reward).open();
                    player.sendMessage("§aReward Chance returned to automatic distribution.");
                    return;
                }
                plugin.requestInput(player, ZxCratesPlugin.InputType.REWARD_CHANCE, crateId, rewardId);
                player.closeInventory();
                player.sendMessage("§eType manual chance 0-100.");
            }
            case 12 -> { plugin.requestInput(player, ZxCratesPlugin.InputType.REWARD_AMOUNT, crateId, rewardId); player.closeInventory(); player.sendMessage("§eType amount."); }
            case 14 -> { RewardType[] types = RewardType.values(); reward.type(types[(reward.type().ordinal() + 1) % types.length]); plugin.service().save(crate); new RewardEditMenu(plugin, player, crate, reward).open(); }
            case 28 -> { plugin.requestInput(player, ZxCratesPlugin.InputType.REWARD_COMMAND, crateId, rewardId); player.closeInventory(); player.sendMessage("§eType command or none."); }
            case 32 -> { removeRewardNoSave(crate, reward); plugin.service().save(crate); new RewardMenu(plugin, player, crate).open(); }
            case 49 -> new RewardMenu(plugin, player, crate).open();
            default -> { }
        }
    }

    @EventHandler
    public void drag(InventoryDragEvent event) {
        String title = event.getView().getTitle();
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (CratePreviewMenu.isTitle(title) || CrateMenu.isTitle(title) || KeySettingsMenu.isTitle(title) || RewardEditMenu.isTitle(title)) { event.setCancelled(true); return; }
        if (CrateEditorMenu.PREFIX.equals(title)) {
            event.setCancelled(true);
            Crate crate = CrateEditorMenu.crateFor(event.getView().getTopInventory());
            if (crate != null && event.getRawSlots().contains(12)) setDisplayBlockFromItem(player, crate, event.getOldCursor());
            return;
        }
        if (!RewardMenu.isTitle(title)) return;
        event.setCancelled(true);
        int target = event.getRawSlots().stream().filter(slot -> slot >= 0 && slot < Math.min(45, event.getView().getTopInventory().getSize())).findFirst().orElse(-1);
        if (target < 0) return;
        ItemStack cursor = event.getOldCursor(); if (cursor == null || cursor.getType().isAir()) return;
        Crate crate = plugin.service().get(RewardMenu.pageFromTitle(title).crateId()).orElse(null); if (crate == null) return;
        importToSlot(player, cursor, crate, target);
    }

    @EventHandler
    public void close(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;
        if (SELECT_TITLE.equals(event.getView().getTitle())) {
            selectedReward.remove(player.getUniqueId());
            if (!confirming.remove(player.getUniqueId())) plugin.service().endOpening(player.getUniqueId());
        }
    }

    private void giveSelectedReward(Player player, Crate crate, Reward reward) {
        if (reward.type() == RewardType.GIVE_ITEM || reward.type() == RewardType.MIXED) plugin.service().giveItem(player, reward.item(), reward.amount());
        if (reward.type() == RewardType.GIVE_CLOUD && reward.item() != null && !reward.item().getType().isAir()) player.getWorld().dropItemNaturally(player.getLocation().add(0, 1, 0), reward.item().clone());
        if (reward.type() == RewardType.EXECUTE_COMMAND || reward.type() == RewardType.MIXED) for (String raw : reward.commands()) {
            String command = raw.replace("{player}", player.getName()).replace("{uuid}", player.getUniqueId().toString()).replace("{crate}", crate.id());
            String lower = command.toLowerCase(Locale.ROOT);
            if (lower.startsWith("[player]")) player.performCommand(command.substring(8).trim());
            else { String actual = lower.startsWith("[console]") ? command.substring(9).trim() : command; Tasks.global(plugin, () -> Bukkit.dispatchCommand(Bukkit.getConsoleSender(), actual)); }
        }
    }
}
