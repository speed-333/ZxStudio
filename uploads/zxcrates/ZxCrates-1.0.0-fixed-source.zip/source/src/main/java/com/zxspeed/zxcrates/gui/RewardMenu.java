package com.zxspeed.zxcrates.gui;

import com.zxspeed.zxcrates.ZxCratesPlugin;
import com.zxspeed.zxcrates.model.Crate;
import com.zxspeed.zxcrates.model.CrateType;
import com.zxspeed.zxcrates.model.Reward;
import com.zxspeed.zxcrates.util.ItemLoreUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;

import java.util.Locale;

public final class RewardMenu {
    public static final String PREFIX="§8Rewards • ";
    private final ZxCratesPlugin plugin; private final org.bukkit.entity.Player player; private final Crate crate;
    public RewardMenu(ZxCratesPlugin plugin,org.bukkit.entity.Player player,Crate crate){this.plugin=plugin;this.player=player;this.crate=crate;}
    public void open(){
        Inventory inv=Bukkit.createInventory(null,54,PREFIX+crate.id());
        for(int slot=0;slot<45;slot++)inv.setItem(slot,GuiItems.blankPane());
        for(Reward reward:crate.rewards()){
            int slot=reward.slot()>=0?reward.slot():crate.rewards().indexOf(reward);if(slot<0||slot>=Math.min(45,crate.slots()))continue;
            if(crate.type()==CrateType.SELECT&&slot==crate.slots()-1)continue;
            ItemStack icon=reward.item()==null?new ItemStack(Material.NETHER_STAR):ItemLoreUtil.withCrateLore(reward.item(),crate,reward,player,plugin.placeholders());
            icon.setAmount(Math.min(Math.max(1,reward.amount()),icon.getMaxStackSize()));
            var meta=icon.getItemMeta();
            if(meta!=null){
                meta.lore(java.util.List.of(
                        straight("§7Reward ID: §f"+reward.id()),
                        straight("§7Slot: §f"+(slot+1)),
                        straight("§7Chance: §f"+String.format(Locale.ROOT,"%.2f%%",reward.chance())),
                        straight("§7Type: §f"+reward.type().name().toLowerCase(Locale.ROOT)),
                        straight(""),
                        straight("§eClick: Edit"),
                        straight("§cShift + right click: Delete")));
                icon.setItemMeta(meta);
            }
            inv.setItem(slot,icon);
        }
        inv.setItem(46,GuiItems.item(Material.HOPPER,"&aImport Inventory","&7Copy your full player inventory","&7in the same order, except armor/off-hand."));
        inv.setItem(49,GuiItems.item(Material.BARRIER,"&cClear Rewards","&7Right click to clear."));
        inv.setItem(53,GuiItems.item(Material.ARROW,"&eBack"));
        player.openInventory(inv);
    }

    private static Component straight(String text) {
        return Component.text(text).decoration(TextDecoration.ITALIC, false);
    }
    public static boolean isTitle(String title){return title.startsWith(PREFIX);}
    public static Page pageFromTitle(String title){return new Page(title.substring(PREFIX.length()));}
    public record Page(String crateId){}
}
