package com.zxspeed.zxcrates.service;

import com.zxspeed.zxcrates.model.Crate;

import java.util.Collection;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

public interface CrateRepository {
    CompletableFuture<Collection<Crate>> loadAll();
    CompletableFuture<Void> save(Crate crate);
    CompletableFuture<Void> delete(String id);
    CompletableFuture<Integer> getKeys(UUID player, String crateId);
    CompletableFuture<Void> setKeys(UUID player, String crateId, int amount);

    default CompletableFuture<Boolean> takeKey(UUID player, String crateId) {
        return getKeys(player, crateId).thenCompose(current -> {
            if (current <= 0) return CompletableFuture.completedFuture(false);
            return setKeys(player, crateId, current - 1).thenApply(v -> true);
        });
    }
}
