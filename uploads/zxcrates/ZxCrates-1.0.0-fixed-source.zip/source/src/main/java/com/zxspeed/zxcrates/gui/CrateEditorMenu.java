package com.zxspeed.zxcrates.gui;

import com.zxspeed.zxcrates.ZxCratesPlugin;
import com.zxspeed.zxcrates.model.*;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import java.util.Locale;

public final class CrateEditorMenu {
    private static final java.util.Map<org.bukkit.inventory.Inventory, Crate> OPEN = java.util.Collections.synchronizedMap(new java.util.WeakHashMap<>());
    public static final String PREFIX="§8ZxCrates Editor";
    private final ZxCratesPlugin plugin; private final Player player; private final Crate crate;
    public CrateEditorMenu(ZxCratesPlugin plugin,Player player,Crate crate){this.plugin=plugin;this.player=player;this.crate=crate;}
    public void open(){
        Inventory inv=Bukkit.createInventory(null,54,PREFIX);
        inv.setItem(10,GuiItems.item(Material.NAME_TAG,"&bBasic Info","&7Crate: &f"+crate.id(),"&7Display: &f"+crate.displayName(),"&7Type: &f"+crate.type().name().toLowerCase(Locale.ROOT),"&eLeft click: display name","&eRight click: type"));
        inv.setItem(12,GuiItems.item(crate.blockMaterial()==null?Material.CHEST:crate.blockMaterial(),"&bDisplay Block","&7Current: &f"+crate.blockMaterial(),"&eClick with a block in your hand/cursor","&eOr click a block from your inventory"));
        inv.setItem(14,GuiItems.item(Material.CHEST,"&bRewards","&7Rewards: &f"+crate.rewards().size(),"&eClick to manage"));
        inv.setItem(16,GuiItems.item(Material.NETHER_STAR,"&bAnimation","&7Current: &f"+crate.animation().name().toLowerCase(Locale.ROOT),"&eClick to cycle"));
        inv.setItem(28,GuiItems.item(Material.TRIPWIRE_HOOK,"&bKeys","&7Type: &f"+crate.keyDelivery(),"&7Name: &f"+crate.keyDisplayName(),"&7Stacked: &f"+crate.keyStacked(),"&eClick to open key editor"));
        inv.setItem(30,GuiItems.item(Material.OAK_SIGN,"&bOpen Permission","&7Current: &f"+(crate.openPermission().isBlank()?"none":crate.openPermission()),"&eClick to edit"));
        inv.setItem(32,GuiItems.item(Material.CLOCK,"&bCooldown","&7Current: &f"+crate.cooldownSeconds()+"s","&eClick to edit"));
        inv.setItem(36,GuiItems.item(Material.CHEST_MINECART,"&bCrate Slots","&7Current: &f"+crate.slots(),"&eClick to edit"));
        inv.setItem(38,GuiItems.item(Material.ARMOR_STAND,"&bHologram","&7Enabled: &f"+crate.hologramEnabled(),"&7Offset: &f"+crate.hologramOffsetY(),"&7View distance: &f"+crate.hologramViewDistance(),"&eClick to toggle"));
        inv.setItem(39,GuiItems.item(Material.GLASS,"&bHologram Background","&7Current: &f"+crate.hologramBackground(),"&eClick to toggle background"));
        inv.setItem(40,GuiItems.item(Material.PAPER,"&fAuto Save","&7All editor changes save automatically."));
        inv.setItem(49,GuiItems.item(Material.ARROW,"&eBack"));
        inv.setItem(53,GuiItems.item(Material.BARRIER,"&cDelete Crate","&7Use &f/zxcrates delete "+crate.id()));
        OPEN.put(inv,crate);
        player.openInventory(inv);
    }
    public static Crate crateFor(Inventory inv){return OPEN.get(inv);}
    public Crate crate(){return crate;}
}
