package com.zxspeed.zxcrates.listener;

import com.zxspeed.zxcrates.ZxCratesPlugin;
import com.zxspeed.zxcrates.model.Crate;
import com.zxspeed.zxcrates.model.Reward;
import com.zxspeed.zxcrates.util.Tasks;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

import java.util.Optional;

public final class ChatInputListener implements Listener {
    private final ZxCratesPlugin plugin;
    public ChatInputListener(ZxCratesPlugin plugin){this.plugin=plugin;}
    @EventHandler public void chat(AsyncPlayerChatEvent event){
        Player player=event.getPlayer();ZxCratesPlugin.InputRequest request=plugin.consumeInput(player.getUniqueId());if(request==null)return;
        event.setCancelled(true);String input=event.getMessage().trim();Tasks.player(player,plugin,()->apply(player,request,input));
    }
    private void apply(Player player,ZxCratesPlugin.InputRequest request,String input){
        Optional<Crate> optional=plugin.service().get(request.crateId());if(optional.isEmpty()){player.sendMessage("§cCrate no longer exists.");return;}Crate crate=optional.get();
        if(input.equalsIgnoreCase("cancel")){player.sendMessage("§eInput cancelled.");new com.zxspeed.zxcrates.gui.CrateEditorMenu(plugin,player,crate).open();return;}
        switch(request.type()){
            case CRATE_DISPLAY_NAME -> {if(input.isBlank()||input.length()>80){player.sendMessage("§cDisplay name must be between 1 and 80 characters.");return;}crate.displayName(input.replace("<","").replace(">",""));saveEditor(player,crate);}
            case KEY_DISPLAY_NAME -> {if(input.isBlank()||input.length()>80){player.sendMessage("§cKey name must be between 1 and 80 characters.");return;}crate.keyDisplayName(input.replace("<","").replace(">",""));plugin.service().save(crate);new com.zxspeed.zxcrates.gui.KeySettingsMenu(plugin,player,crate).open();}
            case OPEN_PERMISSION -> {crate.openPermission(input.equalsIgnoreCase("none")?"":input);saveEditor(player,crate);}
            case CRATE_SLOTS -> {try{int value=Integer.parseInt(input);if(value<9||value>54||value%9!=0)throw new NumberFormatException();crate.slots(value);saveEditor(player,crate);}catch(NumberFormatException ex){player.sendMessage("§cSlots must be one of: 9, 18, 27, 36, 45, 54.");}}
            case COOLDOWN -> {try{long value=Long.parseLong(input);if(value<0||value>86_400L)throw new NumberFormatException();crate.cooldownSeconds(value);saveEditor(player,crate);}catch(NumberFormatException ex){player.sendMessage("§cCooldown must be a number from 0 to 86400 seconds.");}}
            case REWARD_CHANCE,REWARD_AMOUNT,REWARD_COMMAND -> {
                Reward reward=crate.findReward(request.rewardId()).orElse(null);
                if(reward==null){player.sendMessage("§cReward no longer exists.");return;}
                if(request.type()==ZxCratesPlugin.InputType.REWARD_CHANCE){
                    try{
                        double v=Double.parseDouble(input);
                        if(!crate.setManualRewardChance(reward.id(),v)){player.sendMessage("§cThis manual Chance would make the total exceed 100%.");return;}
                    }catch(NumberFormatException ex){player.sendMessage("§cChance must be a number from 0 to 100.");return;}
                }else if(request.type()==ZxCratesPlugin.InputType.REWARD_AMOUNT){try{int v=Integer.parseInt(input);if(v<1)throw new NumberFormatException();reward.amount(v);}catch(NumberFormatException ex){player.sendMessage("§cAmount must be a positive integer.");return;}}
                else reward.commands(input.equalsIgnoreCase("none")?java.util.List.of():java.util.List.of(input));
                plugin.service().save(crate);
                new com.zxspeed.zxcrates.gui.RewardEditMenu(plugin,player,crate,reward).open();
            }
        }
    }
    private void saveEditor(Player player,Crate crate){plugin.service().save(crate);new com.zxspeed.zxcrates.gui.CrateEditorMenu(plugin,player,crate).open();}
}
