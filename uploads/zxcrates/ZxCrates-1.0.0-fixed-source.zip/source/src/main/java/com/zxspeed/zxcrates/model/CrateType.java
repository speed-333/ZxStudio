package com.zxspeed.zxcrates.model;

public enum CrateType { SELECT, RANDOM }
