package com.zxspeed.zxcrates.gui;

import com.zxspeed.zxcrates.util.ColorUtil;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;
import java.util.List;

final class GuiItems {
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacySection();

    private GuiItems() {}

    static ItemStack item(Material material, String name, String... lore) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) return stack;
        if (name != null && !name.isEmpty()) meta.displayName(straight(LEGACY.deserialize(ColorUtil.colorize(name))));
        if (lore.length > 0) {
            meta.lore(Arrays.stream(lore)
                    .map(line -> straight(LEGACY.deserialize(ColorUtil.colorize(line))))
                    .toList());
        }
        stack.setItemMeta(meta);
        return stack;
    }

    private static Component straight(Component component) {
        return component.decoration(TextDecoration.ITALIC, false);
    }

    static ItemStack item(Material material, String name, List<String> lore) {
        return item(material, name, lore.toArray(String[]::new));
    }

    static ItemStack blankPane() {
        return new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
    }

    static ItemStack resetNamePane() {
        return item(Material.BLACK_STAINED_GLASS_PANE, "&r");
    }

    static void fillEmpty(Inventory inventory) {
        for (int slot = 0; slot < inventory.getSize(); slot++) {
            ItemStack current = inventory.getItem(slot);
            if (current == null || current.getType().isAir()) inventory.setItem(slot, blankPane());
        }
    }
}
