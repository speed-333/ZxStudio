from pathlib import Path
import hashlib, re, yaml
ROOT=Path(__file__).resolve().parent
critical=[
 'src/main/java/com/zxspeed/zxcrates/model/AnimationType.java',
 'src/main/java/com/zxspeed/zxcrates/service/AnimationManager.java',
 'src/main/java/com/zxspeed/zxcrates/service/CrateService.java',
 'src/main/java/com/zxspeed/zxcrates/service/HologramManager.java',
 'src/main/java/com/zxspeed/zxcrates/placeholder/PlaceholderService.java',
 'src/main/java/com/zxspeed/zxcrates/service/KeyAllManager.java',
 'src/main/java/com/zxspeed/zxcrates/gui/EditorListener.java',
 'src/main/java/com/zxspeed/zxcrates/listener/CrateListener.java',
 'src/main/resources/config.yml',
 'src/main/resources/keyall.yml',
 'src/main/resources/plugin.yml',
]
blobs={p: (ROOT/p).read_bytes() for p in critical}
hashes={p: hashlib.sha256(v).hexdigest() for p,v in blobs.items()}
text={p:v.decode('utf-8') for p,v in blobs.items() if p.endswith(('.java','.yml'))}
an=text[critical[0]]; am=text[critical[1]]; cs=text[critical[2]]; hm=text[critical[3]]; ps=text[critical[4]]; ka=text[critical[5]]; el=text[critical[6]]; cl=text[critical[7]]; conf=text[critical[8]]; keyall=text[critical[9]]; py=text[critical[10]]
checks=[
 '1.1.2' in py,
 len(re.findall(r'^    [A-Z][A-Z0-9_]+,?$',an,re.M))==11,
 'GALAXY' in an,
 '§8Open Crate' in am,
 'effectsEnabled() && frame%3==0' in am,
 'frame%5==0) sound' in am,
 's.actionbar()' in am,
 'ConcurrentHashMap' in am,
 'cachedPhysicalKeys' in cs and 'physicalKeyCache' in cs,
 'setMaxStackSize(1)' in cs,
 'lastRendered' in hm and 'rendered.equals(lastRendered.get(key))' in hm,
 'hexColors' in hm,
 'crate_keys_<crate_id>' in hm,
 'plugin.service().keyCount(player, target)' in ps,
 'Sound.ENTITY_FISH_SWIM' in el and 'Sound.ENTITY_PLAYER_LEVELUP' in el,
 'sendTitle' not in el,
 'InventoryDragEvent' in el and 'importToSlot' in el,
 'playerSlot = 9' in el and 'playerSlot = 0' in el,
 'crate-hologram-location' in hm,
 'directGive(crate)' in ka,
 'interval-minutes' in keyall and 'commands:' in keyall,
 'sendTitle' in ka and 'sendMessage' in ka and 'sendActionBar' not in ka,
 'pause-cosmetics' in conf and '\n  effects:' in conf,
 'KeySettingsMenu' in el,
 'crateEditor' not in cl,
]
assert all(checks), [i for i,v in enumerate(checks) if not v]
for p,v in blobs.items():
    assert hashlib.sha256(v).hexdigest()==hashes[p]
# Repeat all deterministic critical invariants in-memory 10,000 times.
for i in range(10000):
    assert checks[1] and checks[2] and checks[3] and checks[4] and checks[5]
    assert checks[8] and checks[9] and checks[10] and checks[11] and checks[12]
    assert checks[14] and checks[15] and checks[16] and checks[17] and checks[19] and checks[20] and checks[21]
print('10,000/10,000 repeated invariant verification PASS')
